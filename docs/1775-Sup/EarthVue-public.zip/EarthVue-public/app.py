"""
EARTH-VUE / Unified AI Framework - Flask Application with MongoEngine

Main application file using MongoEngine for MongoDB integration.
Models are imported from models.py
"""

import os
import re
import uuid
import json
import logging
from flask import (
    Flask, render_template, redirect, url_for,
    session, abort, jsonify, Response,
    request, stream_with_context
)
from dotenv import load_dotenv
from mongoengine import connect, NotUniqueError, ValidationError
import threading
from datetime import datetime, timezone, timedelta
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flasgger import Swagger

# Azure/OpenAI clients
from services.langchain_client import (
    chat_stream,
    chat_stream_with_tools,
    chat_non_streaming,
    chat_with_retrieval,
    get_model_config,
    list_available_deployments,
    get_llm_for,
)
import services.classic_assistant as classic_assistant
import services.ai_arena as ai_arena

# Import all MongoEngine models
from models import (
    User, ChatSession, ChatMessage, DataAccessEvent, UserExpertiseProfile,
    MultimodalCompareHistory, AIReasoningTrace, AIUncertaintyEvent,
    PlainLanguageSummary, DataProvenance, ClimateGlossary, ArenaDebateHistory,
    Workspace, SessionComment, TokenUsage, ReasoningFeedback
)

load_dotenv()

# Flask app configuration
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-only-set-flask-secret-key")

# Initialize rate limiter
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["600 per day", "150 per hour"],
    storage_uri="memory://"  # Use in-memory storage (can be upgraded to Redis)
)

# Initialize Swagger for API documentation
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": "apispec",
            "route": "/apispec.json",
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/api-docs"
}
swagger_template = {
    "swagger": "2.0",
    "info": {
        "title": "EARTH-VUE API",
        "description": "API for climate data exploration and analysis",
        "version": "1.0.0"
    },
    "basePath": "/",
    "schemes": ["http", "https"]
}
swagger = Swagger(app, config=swagger_config, template=swagger_template)

# Import error handlers
from services.error_handler import (
    handle_api_errors, AppError, ValidationError as AppValidationError,
    NotFoundError, UnauthorizedError, RateLimitError
)
from services.input_validator import (
    validate_query_text, validate_session_id, validate_json_input,
    sanitize_string, validate_email, validate_username
)

# Configure MongoDB connection (override MONGODB_URI for Atlas or remote hosts)
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://127.0.0.1:27017/earthvue_db")
MONGODB_DB = os.getenv("MONGODB_DB", "earthvue_db")

try:
    connect(
        db=MONGODB_DB,
        host=MONGODB_URI,
        connectTimeoutMS=5000,
        serverSelectionTimeoutMS=5000,
    )
    print(f"✓ Connected to MongoDB: {MONGODB_DB}")
except Exception as e:
    print(f"✗ Failed to connect to MongoDB: {e}")
    print("  Make sure MONGODB_URI environment variable is set correctly")
    raise

# Register blueprints
from export_answer_notebook import export_bp
app.register_blueprint(export_bp)

# Register route blueprints
from routes.pages import pages_bp
from routes.chat import chat_bp
from routes.collaboration import collaboration_bp
from routes.tools import tools_bp
from routes.analytics import analytics_bp
from routes.ai_features import ai_features_bp
from routes.content import content_bp
from routes.skills import skills_bp
from routes.user_datasets import user_datasets_bp

app.register_blueprint(pages_bp)
app.register_blueprint(chat_bp)
app.register_blueprint(collaboration_bp)
app.register_blueprint(tools_bp)
app.register_blueprint(analytics_bp)
app.register_blueprint(ai_features_bp)
app.register_blueprint(content_bp)
app.register_blueprint(skills_bp)
app.register_blueprint(user_datasets_bp)

# Warm up code executor so first run from chat (or code-executor page) is not slow
try:
    from services.code_executor import execute_code_safely
    execute_code_safely("0", timeout=2)
except Exception as e:
    import logging
    logging.getLogger(__name__).debug("Code executor warmup skipped: %s", e)

# Configure logging
logger = logging.getLogger(__name__)

# System prompt for climate assistant
SYSTEM_PROMPT = (
    "You are a highly knowledgeable AI assistant specialized in downscaled climate modeling datasets, including  NASA NEX-GDDP-CMIP6. "
    "You provide scientifically accurate, concise, and helpful answers to users exploring these datasets."
    "You are developed, created and trained at NASA JPL and University of Utah.\n\n"

    "🛠️ **Always use your MCP tools**: use list_datasets, list_variables, load_dataset to explore. For code/visualization: generate the full Python code in this turn and call execute_code(code='your code', timeout_seconds=60). Do not only write code in your reply—call execute_code so it runs. If execution fails, fix the code and call execute_code again (up to 5 retries).\n\n"

    "📘 Your primary knowledge base includes code and documents, which describes all available climate models, variables, scenarios, resolutions, and how to construct field names. "
    "When users ask about retrieving or analyzing CMIP6 data, you must follow the logic and metadata described in that document exactly."
    "Always use intake library, never use dask. For that, refer to cmip6_variables_notebook_intake or cmip6_notebook_using_intake.ipynb for examples.\n"
    "DO NOT USE YOUR OWN WAY TO ACCESS THE DATASETS. ALWAYS USE INTAKE AND THE PROVIDED CATALOG.\n\n"
    "ALWAYS FOLLOW THE INSTRUCTIONS FROM THE DOCUMENTS. DO NOT MAKE UP ANYTHING ON YOUR OWN OR ASSUME ANYTHING.\n"
    "FOLLOW THE DOCUMENT ENTIRELY WHEN GIVING EXAMPLES OR WRITING FULL CODE.\n"

    "Your knowledge includes other codes and jupyer notebooks from the knowledge base.\n"
    "- See cmip6_variable_availability.md for variable/model/scenario availability matrix.\n"
    "- Available models, scenarios, variables, and spatial/temporal resolution details.\n"
    "- Bias-correction methodologies and downscaling approaches.\n"
    "- Data access patterns using tools like xarray, planetary_computer, OpenVisus, and intake.\n"
    "- Relationships between variables (e.g., tas, pr, sfcWind), model-scenario compatibility, and valid date ranges.\n\n"
    "- If you are not clear about what the user is asking, you will ask for clarification.\n"

    "Your primary goal is to support scientists, students, and policymakers in:\n"
    "- Finding the right dataset/model for a given use case.\n"
    "- Explaining variable definitions and resolutions.\n"
    "- Writing valid data access and visualization code that runs end-to-end.\n"
    "- Performing basic analysis (trend, anomaly detection, subsetting).\n\n"
    "- Please use Intake, xarray and OpenVisus to access datasets by default, and when something else is not specified.\n"
    "- Use your code knowledge from the documentations to provide reproducible examples.\n"

    "Behavior Guidelines:\n"
    "- Try answer based on your grounding in climate datasets and the information retrieved, but if not available, mention it clearly where you get the answer from.\n"
    "- If a user asks something unsupported or vague, ask for clarification.\n"
    "- If you are unsure or the data is unavailable, say: 'I'm not sure based on current data.'\n"
    "- When writing code, always prefer reproducible examples using `xarray`, `intake`, or `OpenVisus`, and give full code.\n"
    "- If the user asks for 3D visualization, use Plotly for the visualization output.\n"
    "- Never assume datasets are already imported or loaded.\n"
    "- Always include imports and dataset loading/access in the same runnable script.\n\n"
    "- Do not return code with placeholders. Always use real variable names and values.\n"
    "- For NEX-GDDP-CMIP6 intake results, `.read()` returns an xarray DataArray. Plot directly with `.plot()` and use `.values` for analysis; do NOT use `ds[variable]`.\n"
    "- If using OpenVisus and the user provides X, Y, Z coordinates/ranges, pass those directly in `.read(...)` (for example `x=...`, `y=...`, `z=...`) and do not trim or clamp the returned data afterward.\n"
    "- When citing documents, always print the full document name.\n"
    "- If you are using intake, always use cmip6_catalog.yml thats located in the same directory as this app.py file.\n"
    
    "When giving code that needs model/time parameters (timestamp, start_date, end_date, year, or date range): if the user did not specify exact values, automatically use the first available model/date options from dataset metadata and proceed with full runnable code. Explicitly mention this to the user (for example: 'Since you did not provide exact values, I used model X and date Y from the first available options.').\n"

    "Multi-year analyses: if the task would need more than 20 timesteps in total across multiple years unless you sample densely, "
    "default to one timestep per year using the same calendar date or same day-of-year every year; only use all timesteps or full temporal resolution when the user explicitly asks. Disclose the chosen date when using this default.\n"

    "Speed (NEX-GDDP-CMIP6): For one model comparing multiple scenarios and/or years on the same calendar day with a **global mean**, "
    "use a single execute_code that loops scenario×year, uses numpy.nanmean on the full field, skips maps unless requested, and "
    "skip list_datasets/list_variables/load_dataset when pre-fetched dataset context is already in the system message. Use timeout_seconds=90 for many loads.\n"

    "Example Questions You Can Answer:\n"
    "- What variables are included in the NEX-GDDP-CMIP6 dataset?\n"
    "- Which models support the ssp585 scenario?\n"
    "- How can I access tasmax data for 2050?\n"
    "- What's the difference between LOCA and NEX-GDDP bias correction?\n"
    "- How do I subset a dataset to Southeast Asia and calculate monthly averages?\n\n"

    "Be concise. Be accurate. Think like a scientific data librarian with a coding assistant's brain."
)

# Configuration constants
# Support both ENDPOINT_URL and AZURE_OPENAI_ENDPOINT for compatibility
ENDPOINT_URL = os.getenv("ENDPOINT_URL") or os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
# Historically, some environments used the misspelled "DEPLOYMEN_NAME" keys.
# Prefer the correctly spelled variable but fall back to the legacy one so
# that the UI and evaluation scripts behave consistently.
DEPLOYMENT_NAME = os.getenv("DEPLOYMENT_NAME") or os.getenv("DEPLOYMEN_NAME")
SEARCH_ENDPOINT = os.getenv("SEARCH_ENDPOINT")
SEARCH_KEY = os.getenv("SEARCH_KEY")
SEARCH_INDEX_NAME = os.getenv("SEARCH_INDEX_NAME")

LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)
histories = {}  # In-memory conversation histories

# Initialize evaluation service (TruLens removed - using direct MongoDB analytics instead)
evaluator = None  # Not used - metrics tracked directly to MongoDB

from services.analytics_service import (
    analyze_with_llm,
    track_data_access_event,
    calculate_query_complexity,
    identify_accessibility_barriers,
    update_user_expertise,
    track_ai_reasoning,
    calculate_response_confidence,
    analyze_dataset_selection,
    extract_uncertainties,
    detect_comprehensive_biases,
)
try:
    from services.data_registry import get_registry_context_for_prompt, get_sources
except ImportError:
    get_registry_context_for_prompt = lambda *args, **kwargs: ""
    get_sources = lambda: {}

from services.provenance_graph import merge_tools_used_marker_into_provenance
from services.session_reasoning_merge import build_reasoning_analysis_json

# ────────────────────────────────────────────────────────────────────────────
# ── Health Check Endpoint ──────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint – always returns HTML status page.
    """
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    }
    errors = []  # Short messages for UI

    # Check MongoDB connection
    try:
        from mongoengine import get_db
        db = get_db()
        db.command('ping')
        health_status['mongodb'] = 'connected'
    except Exception as e:
        logger.error(f"MongoDB health check failed: {e}")
        health_status['mongodb'] = 'disconnected'
        health_status['status'] = 'degraded'
        err_msg = str(e).strip()
        if len(err_msg) > 80:
            err_msg = err_msg[:77] + '...'
        errors.append(f"MongoDB: {err_msg or 'connection failed'}")

    # Check Azure Search configuration
    if SEARCH_ENDPOINT and SEARCH_KEY and SEARCH_INDEX_NAME:
        health_status['azure_search'] = 'configured'
    else:
        health_status['azure_search'] = 'not_configured'
        missing = [k for k, v in [
            ('SEARCH_ENDPOINT', SEARCH_ENDPOINT),
            ('SEARCH_KEY', SEARCH_KEY),
            ('SEARCH_INDEX_NAME', SEARCH_INDEX_NAME),
        ] if not v]
        if missing:
            errors.append(f"Azure Search: missing {', '.join(missing)}")

    # Check Azure OpenAI configuration
    endpoint_url = ENDPOINT_URL or os.getenv("AZURE_OPENAI_ENDPOINT")
    if endpoint_url and AZURE_API_KEY and DEPLOYMENT_NAME:
        health_status['azure_openai'] = 'configured'
    else:
        health_status['azure_openai'] = 'not_configured'
        missing = []
        if not endpoint_url:
            missing.append('ENDPOINT_URL or AZURE_OPENAI_ENDPOINT')
        if not AZURE_API_KEY:
            missing.append('AZURE_OPENAI_API_KEY')
        if not DEPLOYMENT_NAME:
            missing.append('DEPLOYMENT_NAME')
        health_status['azure_openai_missing'] = missing
        health_status['status'] = 'degraded'
        if missing:
            errors.append(f"Azure OpenAI: missing {', '.join(missing)}")

    status_code = 200 if health_status['status'] == 'healthy' else 503

    return (
        render_template(
            'health.html',
            health=health_status,
            errors=errors,
            status_code=status_code,
        ),
        status_code,
    )


@app.route('/api/health', methods=['GET'])
@limiter.exempt  # Health endpoint is lightweight; allow frequent checks (e.g., status dot polling)
def health_check_json():
    """Health check for API / status dot – always returns JSON."""
    health_status = {'status': 'healthy', 'timestamp': datetime.now().isoformat()}
    errors = []
    try:
        from mongoengine import get_db
        db = get_db()
        db.command('ping')
        health_status['mongodb'] = 'connected'
    except Exception as e:
        logger.error(f"MongoDB health check failed: {e}")
        health_status['mongodb'] = 'disconnected'
        health_status['status'] = 'degraded'
        err_msg = str(e).strip()
        if len(err_msg) > 80:
            err_msg = err_msg[:77] + '...'
        errors.append(f"MongoDB: {err_msg or 'connection failed'}")
    if SEARCH_ENDPOINT and SEARCH_KEY and SEARCH_INDEX_NAME:
        health_status['azure_search'] = 'configured'
    else:
        health_status['azure_search'] = 'not_configured'
        missing = [k for k, v in [('SEARCH_ENDPOINT', SEARCH_ENDPOINT), ('SEARCH_KEY', SEARCH_KEY), ('SEARCH_INDEX_NAME', SEARCH_INDEX_NAME)] if not v]
        if missing:
            errors.append(f"Azure Search: missing {', '.join(missing)}")
    endpoint_url = ENDPOINT_URL or os.getenv("AZURE_OPENAI_ENDPOINT")
    if endpoint_url and AZURE_API_KEY and DEPLOYMENT_NAME:
        health_status['azure_openai'] = 'configured'
    else:
        health_status['azure_openai'] = 'not_configured'
        missing = []
        if not endpoint_url:
            missing.append('ENDPOINT_URL or AZURE_OPENAI_ENDPOINT')
        if not AZURE_API_KEY:
            missing.append('AZURE_OPENAI_API_KEY')
        if not DEPLOYMENT_NAME:
            missing.append('DEPLOYMENT_NAME')
        health_status['azure_openai_missing'] = missing
        health_status['status'] = 'degraded'
        if missing:
            errors.append(f"Azure OpenAI: missing {', '.join(missing)}")
    status_code = 200 if health_status['status'] == 'healthy' else 503
    if errors:
        health_status['errors'] = errors
    return jsonify(health_status), status_code

# ────────────────────────────────────────────────────────────────────────────
# ── Authentication Routes (via Blueprint) ──────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

from auth import auth_bp
app.register_blueprint(auth_bp)

# ────────────────────────────────────────────────────────────────────────────
# ── Route Blueprints Registered Above ──────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────
# 
# The following routes have been moved to blueprints:
# - Page routes (landing, chat, sessions, workspaces, etc.) → routes/pages.py
# - Chat API routes (/chat POST, /sessions, /load_chat, etc.) → routes/chat.py
# - Collaboration routes (workspaces, sharing) → routes/collaboration.py
# - Tools routes (code execution, query builder) → routes/tools.py
# - Analytics routes (/health, /api/token_usage) → routes/analytics.py
# - AI Features routes (compare, arena, reasoning, knowledge graph) → routes/ai_features.py
# - Content routes (glossary, plain language, provenance) → routes/content.py
#
# Helper functions (track_ai_reasoning, track_data_access_event, etc.) remain
# in app.py for now as they are used by multiple blueprints. Consider moving
# them to services/analytics.py in the future.
# ────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────
# ── Multimodal Comparison History API ──────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route('/api/compare_history', methods=['GET', 'POST'])
def compare_history():
    user_id = session.get('user_id')
    session_id = session.sid if hasattr(session, 'sid') else session.get('id')
    
    if request.method == 'POST':
        data = request.get_json(force=True)
        prompt = data.get('prompt', '').strip()
        modelA = data.get('modelA', '').strip()
        modelB = data.get('modelB', '').strip()
        answerA = data.get('answerA', '')
        answerB = data.get('answerB', '')
        
        if not prompt or not modelA or not modelB:
            return jsonify({'error': 'Missing required fields'}), 400
        
        try:
            entry = MultimodalCompareHistory(
                user_id=user_id if user_id else None,
                session_id=session_id if not user_id else None,
                prompt=prompt,
                modelA=modelA,
                modelB=modelB,
                answerA=answerA,
                answerB=answerB
            )
            entry.save()
            return jsonify({'ok': True, 'id': str(entry.id)})
        except Exception as e:
            logger.error(f"Error saving compare history: {e}")
            return jsonify({'error': 'Failed to save history'}), 500
    
    # GET: return history
    try:
        if user_id:
            items = MultimodalCompareHistory.objects(user_id=user_id).order_by('-created_at').limit(50)
        elif session_id:
            items = MultimodalCompareHistory.objects(session_id=session_id, user_id=None).order_by('-created_at').limit(50)
        else:
            return jsonify({'history': []})
        
        result = [
            {
                'id': str(h.id),
                'prompt': h.prompt,
                'modelA': h.modelA,
                'modelB': h.modelB,
                'answerA': h.answerA,
                'answerB': h.answerB,
                'votesA': getattr(h, 'votes_a', 0),
                'votesB': getattr(h, 'votes_b', 0),
                'created_at': h.created_at.isoformat()
            }
            for h in items
        ]
        return jsonify({'history': result})
    except Exception as e:
        logger.error(f"Error fetching compare history: {e}")
        return jsonify({'error': 'Failed to fetch history'}), 500

@app.route('/api/compare_history/<history_id>', methods=['DELETE'])
def delete_compare_history(history_id):
    user_id = session.get('user_id')
    session_id = session.sid if hasattr(session, 'sid') else session.get('id')
    
    try:
        from bson.objectid import ObjectId
        entry = MultimodalCompareHistory.objects(id=ObjectId(history_id)).first()
        
        if not entry:
            return jsonify({'error': 'Not found'}), 404
        
        # Verify ownership
        if user_id and entry.user_id != user_id:
            return jsonify({'error': 'Unauthorized'}), 403
        elif session_id and entry.session_id != session_id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        entry.delete()
        return jsonify({'deleted': True})
    except Exception as e:
        logger.error(f"Error deleting compare history: {e}")
        return jsonify({'error': 'Failed to delete'}), 500


@app.route('/api/compare_vote', methods=['POST'])
def compare_vote():
    """Record a user vote for a comparison entry (modelA vs modelB)."""
    try:
        data = request.get_json(force=True)
        history_id = data.get('history_id')
        vote = (data.get('vote') or '').upper()
        if vote not in ['A', 'B']:
            return jsonify({'error': 'vote must be "A" or "B"'}), 400

        voter = session.get('user_id') or (session.sid if hasattr(session, 'sid') else session.get('id'))
        if not voter:
            return jsonify({'error': 'Unauthorized'}), 401

        from bson.objectid import ObjectId
        entry = MultimodalCompareHistory.objects(id=ObjectId(history_id)).first()
        if not entry:
            return jsonify({'error': 'Not found'}), 404

        # Initialize fields if missing
        entry.votes_a = getattr(entry, 'votes_a', 0) or 0
        entry.votes_b = getattr(entry, 'votes_b', 0) or 0
        voter_votes = getattr(entry, 'voter_votes', {}) or {}

        previous = voter_votes.get(str(voter))
        # Undo previous vote if it exists
        if previous == 'A':
            entry.votes_a = max(0, entry.votes_a - 1)
        elif previous == 'B':
            entry.votes_b = max(0, entry.votes_b - 1)

        # Apply new vote
        if vote == 'A':
            entry.votes_a += 1
        else:
            entry.votes_b += 1

        voter_votes[str(voter)] = vote
        entry.voter_votes = voter_votes
        entry.save()

        return jsonify({
            'votesA': entry.votes_a,
            'votesB': entry.votes_b,
            'totalVotes': entry.votes_a + entry.votes_b,
            'vote': vote,
            'modelA': entry.modelA,
            'modelB': entry.modelB
        })
    except Exception as e:
        logger.error(f"Error recording vote: {e}")
        return jsonify({'error': 'Failed to record vote'}), 500


@app.route('/api/model_vote_stats', methods=['GET'])
def model_vote_stats():
    """Aggregate vote statistics across all comparisons."""
    try:
        totals = {}
        overall_votes = 0
        for item in MultimodalCompareHistory.objects():
            votes_a = getattr(item, 'votes_a', 0) or 0
            votes_b = getattr(item, 'votes_b', 0) or 0
            totals[item.modelA] = totals.get(item.modelA, 0) + votes_a
            totals[item.modelB] = totals.get(item.modelB, 0) + votes_b
            overall_votes += (votes_a + votes_b)

        top_model = None
        if totals:
            top_model = max(totals, key=lambda k: totals[k])

        # Return sorted breakdown for convenience
        sorted_totals = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)

        return jsonify({
            'totals': totals,
            'sorted_totals': sorted_totals,
            'top_model': top_model,
            'total_votes': overall_votes
        })
    except Exception as e:
        logger.error(f"Error aggregating model vote stats: {e}")
        return jsonify({'error': 'Failed to fetch stats'}), 500

@app.route('/api/compare_metrics', methods=['POST'])
def compare_metrics():
    """Optional endpoint for comparison metrics/analytics"""
    try:
        data = request.get_json(force=True)
        # Placeholder for metrics tracking
        logger.info(f"Comparison metrics: {data}")
        return jsonify({'status': 'ok'})
    except Exception as e:
        logger.error(f"Error tracking metrics: {e}")
        return jsonify({'status': 'error'}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Arena Debate History API ───────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route('/api/arena_history', methods=['GET', 'POST'])
def arena_history():
    user_id = session.get('user_id')
    
    if request.method == 'POST':
        data = request.get_json(force=True)
        debate_id = data.get('id')
        topic = data.get('topic', '').strip()
        modelA = data.get('modelA', '').strip()
        modelB = data.get('modelB', '').strip()
        debate_json = json.dumps(data.get('debate', []))
        
        if not topic or not modelA or not modelB:
            return jsonify({'error': 'Missing required fields'}), 400
        
        try:
            if debate_id:
                from bson.objectid import ObjectId
                entry = ArenaDebateHistory.objects(id=ObjectId(debate_id)).first()
                if entry and (not user_id or entry.user_id == user_id):
                    entry.topic = topic
                    entry.modelA = modelA
                    entry.modelB = modelB
                    entry.debate_json = debate_json
                    entry.created_at = datetime.now()
                    entry.save()
                    return jsonify({'ok': True, 'id': str(entry.id), 'updated': True})
            
            # Create new debate
            entry = ArenaDebateHistory(
                user_id=user_id if user_id else None,
                topic=topic,
                modelA=modelA,
                modelB=modelB,
                debate_json=debate_json
            )
            entry.save()
            return jsonify({'ok': True, 'id': str(entry.id)})
        except Exception as e:
            logger.error(f"Error saving arena history: {e}")
            return jsonify({'error': 'Failed to save history'}), 500
    
    # GET: return all debates for user
    try:
        if user_id:
            items = ArenaDebateHistory.objects(user_id=user_id).order_by('-created_at').limit(50)
        else:
            items = ArenaDebateHistory.objects().order_by('-created_at').limit(50)
        
        result = [
            {
                'id': str(h.id),
                'topic': h.topic,
                'modelA': h.modelA,
                'modelB': h.modelB,
                'debate': json.loads(h.debate_json),
                'created_at': h.created_at.isoformat()
            }
            for h in items
        ]
        return jsonify({'history': result})
    except Exception as e:
        logger.error(f"Error fetching arena history: {e}")
        return jsonify({'error': 'Failed to fetch history'}), 500

@app.route('/api/arena_history/<history_id>', methods=['DELETE'])
def delete_arena_history(history_id):
    user_id = session.get('user_id')
    
    try:
        from bson.objectid import ObjectId
        entry = ArenaDebateHistory.objects(id=ObjectId(history_id)).first()
        
        if not entry:
            return jsonify({'error': 'Not found'}), 404
        
        if user_id and entry.user_id != user_id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        entry.delete()
        return jsonify({'deleted': True})
    except Exception as e:
        logger.error(f"Error deleting arena history: {e}")
        return jsonify({'error': 'Failed to delete'}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Main Chat UI Routes ────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.get("/")
def landing():
    """Landing page - show mode selection if logged in, otherwise redirect to login"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    
    try:
        # MongoEngine handles ObjectId conversion automatically
        user = User.objects(id=session["user_id"]).first()
        if not user:
            logger.warning(f"User not found for session user_id: {session['user_id']}")
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("landing.html", user=user)
    except Exception as e:
        logger.error(f"Error loading landing page: {e}")
        # Clear invalid session data
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/logout")
def logout():
    """Logout endpoint - clears session and redirects to login"""
    session.clear()
    return redirect(url_for("auth.login"))

@app.route("/chat")
def chat():
    """Main chat interface - requires authentication"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    
    try:
        # MongoEngine handles ObjectId conversion automatically
        user = User.objects(id=session["user_id"]).first()
        if not user:
            logger.warning(f"User not found for session user_id: {session['user_id']}")
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("index.html", current_user_name=user.name, user=user)
    except Exception as e:
        logger.error(f"Error loading chat page: {e}")
        # Clear invalid session data
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/multimodal")
def multimodal():
    """Multimodal comparison interface - requires authentication"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("multimodal.html", user=user)
    except Exception as e:
        logger.error(f"Error loading multimodal page: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/arena")
def arena():
    """AI Arena debate interface - requires authentication"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("arena.html", user=user)
    except Exception as e:
        logger.error(f"Error loading arena page: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/accessibility")
def accessibility_dashboard():
    """Render the accessibility analytics dashboard"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    user = User.objects(id=session["user_id"]).first()
    if not user:
        session.clear()
        return redirect(url_for("auth.login"))
    return render_template("accessibility_dashboard.html", user=user)

@app.get("/reasoning")
def ai_reasoning_dashboard():
    """Render the AI reasoning and uncertainty visualization dashboard"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    user = User.objects(id=session["user_id"]).first()
    if not user:
        session.clear()
        return redirect(url_for("auth.login"))
    return render_template("ai_reasoning.html", user=user)

@app.get("/code-executor")
def code_executor():
    """Code executor page"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("code_executor.html", user=user)
    except Exception as e:
        logger.error(f"Error loading code executor: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/help")
def help_page():
    """Help and documentation page"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("help.html", user=user)
    except Exception as e:
        logger.error(f"Error loading help page: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/knowledge-graph")
def knowledge_graph():
    """Knowledge graph visualization page"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("knowledge_graph.html", user=user)
    except Exception as e:
        logger.error(f"Error loading knowledge graph: {e}")
        session.clear()
        return redirect(url_for("auth.login"))


@app.route("/api/knowledge_graph/<graph_type>", methods=["GET"])
@handle_api_errors
def get_knowledge_graph(graph_type):
    """
    Get knowledge graph data
    ---
    tags:
      - Knowledge Graph
    parameters:
      - in: path
        name: graph_type
        required: true
        schema:
          type: string
          enum: [datasets, query-patterns, variables, spatial]
    responses:
      200:
        description: Knowledge graph data
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    try:
        from services.knowledge_graph import get_graph_data
        user_id = session.get("user_id")
        graph_data = get_graph_data(graph_type, user_id)
        return jsonify(graph_data)
    except Exception as e:
        logger.error(f"Error generating knowledge graph: {e}")
        raise AppError(f"Failed to generate knowledge graph: {str(e)}")

@app.get("/usage")
def usage_dashboard():
    """Token usage and cost dashboard"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("usage_dashboard.html", user=user)
    except Exception as e:
        logger.error(f"Error loading usage dashboard: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

@app.get("/workspaces")
def workspaces_page():
    """Workspace management page"""
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            session.clear()
            return redirect(url_for("auth.login"))
        return render_template("workspaces.html", user=user)
    except Exception as e:
        logger.error(f"Error loading workspaces page: {e}")
        session.clear()
        return redirect(url_for("auth.login"))

# ────────────────────────────────────────────────────────────────────────────
# ── Multimodal Comparison API ──────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route('/api/compare', methods=['POST'])
def api_compare():
    """Compare a prompt between two selected models"""
    try:
        prompt = request.form.get('prompt') or request.form.get('question')
        model_a = request.form.get('modelA') or request.form.get('model_a')
        model_b = request.form.get('modelB') or request.form.get('model_b')

        if not prompt:
            return jsonify({'error': 'prompt is required'}), 400

        # Handle optional image upload
        image_info = None
        if 'image' in request.files:
            img = request.files['image']
            if img and img.filename:
                upload_dir = os.path.join(os.getcwd(), 'instance', 'uploads')
                os.makedirs(upload_dir, exist_ok=True)
                save_path = os.path.join(upload_dir, f"multimodal_{uuid.uuid4().hex}_{img.filename}")
                img.save(save_path)
                image_info = {'path': save_path, 'filename': img.filename}

        sys_prefix = MULTIMODAL_SYSTEM_PROMPT
        if image_info:
            sys_prefix += f"\nNote: an image file was uploaded ({image_info['filename']}). Use it as contextual information if relevant."

        sys_msg = {'role': 'system', 'content': sys_prefix}
        user_msg = {'role': 'user', 'content': prompt}

        from time import perf_counter

        a_text, b_text = '', ''
        a_ms, b_ms = None, None

        try:
            t0 = perf_counter()
            a_text = chat_non_streaming([sys_msg, user_msg], deployment_name=model_a)
            a_ms = int((perf_counter() - t0) * 1000)
        except Exception as e:
            a_text = f"Error: {e}"
            a_ms = 0

        try:
            t0 = perf_counter()
            b_text = chat_non_streaming([sys_msg, user_msg], deployment_name=model_b)
            b_ms = int((perf_counter() - t0) * 1000)
        except Exception as e:
            b_text = f"Error: {e}"
            b_ms = 0

        return jsonify({'a': a_text, 'b': b_text, 'a_ms': a_ms, 'b_ms': b_ms})
    except Exception as e:
        logger.exception('Failed to run multimodal compare')
        return jsonify({'error': str(e)}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── AI Reasoning Analysis API ──────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/api/reasoning_sessions")
def reasoning_sessions():
    """Get available reasoning sessions for analysis"""
    if "user_id" not in session:
        abort(401)
    
    try:
        user_id = session["user_id"]
        traces = AIReasoningTrace.objects(user_id=user_id).order_by('-timestamp').limit(50)
        
        logger.info(f"🧠 Reasoning sessions: user={user_id}, traces_count={traces.count()}")
        
        sessions = [
            {
                'session_uuid': trace.session_uuid,
                'timestamp': trace.timestamp.isoformat(),
                'user_query': (trace.user_query[:100] + '...') if len(trace.user_query) > 100 else trace.user_query,
                'processing_time_ms': trace.processing_time_ms,
                'overall_confidence': json.loads(trace.confidence_scores or '{}').get('overall', 0)
            }
            for trace in traces
        ]
        
        return jsonify(sessions)
    except Exception as e:
        logger.error(f"Error fetching reasoning sessions: {e}")
        return jsonify({'error': 'Failed to fetch sessions'}), 500

def _safe_json_loads_reasoning(s, default):
    """Parse JSON string with fallback to default on error."""
    if not s:
        return default
    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        return default


@app.route("/api/reasoning_analysis/<session_id>")
def reasoning_analysis(session_id):
    """Get reasoning analysis merged across all turns in the session (compat with ai_features)."""
    if "user_id" not in session:
        abort(401)
    try:
        user_id = session["user_id"]
        selected_trace_id = request.args.get("trace_id")
        _has, analysis_data = build_reasoning_analysis_json(
            session_id, user_id, selected_trace_id
        )
        return jsonify(analysis_data)
    except Exception as e:
        logger.exception("Error analyzing reasoning: %s", e)
        return jsonify({'error': 'Failed to analyze reasoning', 'has_trace': False}), 500


@app.route("/api/reasoning_feedback", methods=["POST"])
def submit_reasoning_feedback():
    """Submit human-in-the-loop feedback for a reasoning trace (research/analysis)."""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    data = request.get_json() or {}
    reasoning_trace_id = data.get("reasoning_trace_id")
    if not reasoning_trace_id:
        return jsonify({"error": "Missing reasoning_trace_id"}), 400
    rating = (data.get("rating") or "").strip().lower()
    if rating not in ("correct", "partial", "problematic"):
        return jsonify({"error": "Invalid rating; use correct, partial, or problematic"}), 400
    trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
    if not trace or trace.user_id != session["user_id"]:
        return jsonify({"error": "Unauthorized"}), 403
    tags = data.get("tags")
    if tags is not None and not isinstance(tags, list):
        tags = [t.strip() for t in str(tags).split(",") if t.strip()]
    comment = (data.get("comment") or "").strip() or None
    existing = ReasoningFeedback.objects(
        reasoning_trace_id=reasoning_trace_id,
        user_id=session["user_id"]
    ).first()
    if existing:
        existing.rating = rating
        existing.tags = json.dumps(tags) if tags else None
        existing.comment = comment
        existing.save()
        return jsonify({"ok": True, "updated": True, "id": str(existing.id)})
    fb = ReasoningFeedback(
        reasoning_trace_id=reasoning_trace_id,
        session_uuid=trace.session_uuid,
        user_id=session["user_id"],
        rating=rating,
        tags=json.dumps(tags) if tags else None,
        comment=comment,
    )
    fb.save()
    return jsonify({"ok": True, "id": str(fb.id)})


@app.route("/api/reasoning_feedback/<reasoning_trace_id>", methods=["GET"])
def get_reasoning_feedback(reasoning_trace_id):
    """Get existing human feedback for a reasoning trace."""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
    if not trace or trace.user_id != session["user_id"]:
        return jsonify({"error": "Unauthorized"}), 403
    fb = ReasoningFeedback.objects(
        reasoning_trace_id=reasoning_trace_id,
        user_id=session["user_id"]
    ).first()
    if not fb:
        return jsonify({"feedback": None})
    return jsonify({
        "feedback": {
            "id": str(fb.id),
            "rating": fb.rating,
            "tags": json.loads(fb.tags) if fb.tags else [],
            "comment": fb.comment or "",
            "created_at": fb.created_at.isoformat() if fb.created_at else None,
        }
    })


@app.route("/api/latest_reasoning")
def latest_reasoning():
    """Get the most recent reasoning trace"""
    if "user_id" not in session:
        abort(401)
    
    try:
        trace = AIReasoningTrace.objects().order_by('-timestamp').first()
        
        if not trace:
            return jsonify({'message': 'No reasoning data available'})
        
        uncertainties = AIUncertaintyEvent.objects(reasoning_trace_id=trace.id)
        
        latest_data = {
            'timestamp': trace.timestamp.isoformat(),
            'reasoning_steps': json.loads(trace.reasoning_steps or '[]'),
            'dataset_logic': json.loads(trace.dataset_selection_logic or '{}'),
            'confidence_scores': json.loads(trace.confidence_scores or '{}'),
            'uncertainties': [
                {
                    'type': u.uncertainty_type,
                    'source': u.uncertainty_source,
                    'confidence': u.confidence_level,
                    'impact': u.impact_assessment,
                    'description': f"{u.uncertainty_type} uncertainty from {u.uncertainty_source}",
                    'mitigation': u.mitigation_strategy
                }
                for u in uncertainties
            ],
            'provenance': json.loads(trace.retrieved_documents or '[]'),
            'biases': json.loads(trace.bias_indicators or '[]')
        }
        
        return jsonify(latest_data)
    except Exception as e:
        logger.error(f"Error fetching latest reasoning: {e}")
        return jsonify({'error': 'Failed to fetch reasoning'}), 500

@app.route("/api/reasoning_visualization/<session_id>")
@handle_api_errors
def enhanced_reasoning_visualization(session_id):
    """
    Get enhanced reasoning visualization data for a session
    ---
    tags:
      - AI Reasoning
    parameters:
      - in: path
        name: session_id
        type: string
        required: true
    responses:
      200:
        description: Enhanced visualization data
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    try:
        user_id = session["user_id"]
        trace = AIReasoningTrace.objects(session_uuid=session_id, user_id=user_id).order_by('-timestamp').first()
        
        if not trace:
            raise NotFoundError("Reasoning trace")
        
        # Parse JSON fields
        reasoning_steps = json.loads(trace.reasoning_steps or '[]')
        dataset_logic = json.loads(trace.dataset_selection_logic or '{}')
        confidence_scores = json.loads(trace.confidence_scores or '{}')
        uncertainties = json.loads(trace.uncertainty_factors or '[]')
        biases = json.loads(trace.bias_indicators or '[]')
        retrieved_docs = json.loads(trace.retrieved_documents or '[]')
        
        # Enhanced visualization data
        visualization_data = {
            'session_id': session_id,
            'timestamp': trace.timestamp.isoformat(),
            'user_query': trace.user_query,
            
            # Reasoning flow visualization
            'reasoning_flow': {
                'steps': reasoning_steps,
                'total_steps': len(reasoning_steps),
                'step_types': _categorize_steps(reasoning_steps)
            },
            
            # Confidence breakdown
            'confidence_breakdown': {
                'overall': confidence_scores.get('overall', 0.7),
                'coherence': trace.response_coherence_score or 0.7,
                'accuracy': trace.factual_accuracy_score or 0.7,
                'completeness': trace.completeness_score or 0.7,
                'explanations': {
                    'coherence': confidence_scores.get('coherence_explanation', ''),
                    'accuracy': confidence_scores.get('accuracy_explanation', ''),
                    'completeness': confidence_scores.get('completeness_explanation', '')
                }
            },
            
            # Dataset selection visualization
            'dataset_selection': {
                'selected_datasets': dataset_logic.get('selected_datasets', []),
                'primary_factors': dataset_logic.get('primary_factors', []),
                'constraints': dataset_logic.get('constraints_considered', []),
                'alternatives': dataset_logic.get('alternatives_evaluated', [])
            },
            
            # Uncertainty analysis
            'uncertainty_analysis': {
                'uncertainties': uncertainties,
                'by_type': _group_uncertainties_by_type(uncertainties),
                'high_impact_count': len([u for u in uncertainties if u.get('impact') == 'high'])
            },
            
            # Bias detection
            'bias_analysis': {
                'biases': biases,
                'by_severity': _group_biases_by_severity(biases),
                'recommendations': [b.get('recommendation', '') for b in biases if b.get('recommendation')]
            },
            
            # Provenance tracking
            'provenance': {
                'retrieved_documents': retrieved_docs,
                'document_count': len(retrieved_docs),
                'model_parameters': json.loads(trace.model_parameters or '{}')
            },
            
            # Performance metrics
            'performance': {
                'processing_time_ms': trace.processing_time_ms,
                'tokens_estimated': None,  # Could be added later
                'cost_estimated': None  # Could be added later
            }
        }
        
        return jsonify(visualization_data)
    except Exception as e:
        logger.error(f"Error generating enhanced visualization: {e}")
        raise AppError("Failed to generate enhanced visualization")


def _categorize_steps(steps):
    """Categorize reasoning steps by type"""
    categories = {}
    for step in steps:
        step_type = step.get('type', 'unknown')
        categories[step_type] = categories.get(step_type, 0) + 1
    return categories


def _group_uncertainties_by_type(uncertainties):
    """Group uncertainties by type"""
    grouped = {}
    for u in uncertainties:
        u_type = u.get('type', 'unknown')
        if u_type not in grouped:
            grouped[u_type] = []
        grouped[u_type].append(u)
    return grouped


def _group_biases_by_severity(biases):
    """Group biases by severity"""
    grouped = {'low': [], 'medium': [], 'high': []}
    for b in biases:
        severity = b.get('severity', 'low').lower()
        if severity in grouped:
            grouped[severity].append(b)
    return grouped


@app.route("/api/uncertainty_summary")
def uncertainty_summary():
    """Get aggregated uncertainty statistics"""
    if "user_id" not in session:
        abort(401)
    
    try:
        days = request.args.get('days', 30, type=int)
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Get recent uncertainty events
        uncertainties = AIUncertaintyEvent.objects(
            reasoning_trace_id__in=[
                t.id for t in AIReasoningTrace.objects(timestamp__gte=cutoff_date)
            ]
        )
        
        # Aggregate by type
        uncertainty_by_type = {}
        for u in uncertainties:
            if u.uncertainty_type not in uncertainty_by_type:
                uncertainty_by_type[u.uncertainty_type] = {
                    'count': 0,
                    'avg_confidence': 0,
                    'impact_distribution': {'low': 0, 'medium': 0, 'high': 0}
                }
            
            uncertainty_by_type[u.uncertainty_type]['count'] += 1
            uncertainty_by_type[u.uncertainty_type]['avg_confidence'] += u.confidence_level
            if u.impact_assessment:
                uncertainty_by_type[u.uncertainty_type]['impact_distribution'][u.impact_assessment] += 1
        
        # Calculate averages
        for utype, data in uncertainty_by_type.items():
            if data['count'] > 0:
                data['avg_confidence'] /= data['count']
        
        summary = {
            'total_uncertainty_events': len(list(uncertainties)),
            'uncertainty_by_type': uncertainty_by_type,
            'high_impact_events': len([u for u in uncertainties if u.impact_assessment == 'high']),
            'avg_system_confidence': sum(u.confidence_level for u in uncertainties) / max(len(list(uncertainties)), 1) if uncertainties else 0
        }
        
        return jsonify(summary)
    except Exception as e:
        logger.error(f"Error getting uncertainty summary: {e}")
        return jsonify({'error': 'Failed to get summary'}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Accessibility Metrics API ──────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/api/accessibility_metrics")
def accessibility_metrics():
    """Get accessibility dashboard data"""
    if "user_id" not in session:
        abort(401)
    
    try:
        from collections import defaultdict
        user_id = session["user_id"]
        days = request.args.get('days', 30, type=int)
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Get recent data access events for user
        events = list(DataAccessEvent.objects(
            user_id=user_id,
            timestamp__gte=cutoff_date
        ))
        
        logger.info(f"📈 Accessibility metrics: user={user_id}, days={days}, events_count={len(events)}")
        
        total_events = len(events)
        
        # Query popularity
        def categorize_query_intent(query_text):
            if not query_text:
                return "Other"
            query_lower = query_text.lower()
            
            if any(word in query_lower for word in ['temperature', 'precipitation', 'wind', 'humidity', 'pressure', 'radiation']):
                return "Climate Variables"
            if any(word in query_lower for word in ['trend', 'change', 'warming', 'cooling', 'increase', 'decrease']):
                return "Trend Analysis"
            if any(word in query_lower for word in ['compare', 'difference', 'versus', 'model comparison']):
                return "Model Comparison"
            if any(word in query_lower for word in ['anomaly', 'anomalies', 'deviation', 'extreme']):
                return "Anomaly Detection"
            if any(word in query_lower for word in ['region', 'location', 'spatial', 'geographic', 'area']):
                return "Regional Analysis"
            if any(word in query_lower for word in ['time series', 'temporal', 'historical', 'future', 'projection']):
                return "Temporal Analysis"
            if any(word in query_lower for word in ['correlation', 'relationship', 'impact', 'effect', 'influence']):
                return "Correlation Study"
            if any(word in query_lower for word in ['download', 'export', 'save', 'retrieve', 'access']):
                return "Data Access"
            if any(word in query_lower for word in ['what is', 'define', 'explain', 'describe', 'how to']):
                return "Education/Help"
            
            return "General Query"
        
        query_category_counts = defaultdict(int)
        for event in events:
            if event.query_text:
                category = categorize_query_intent(event.query_text)
                query_category_counts[category] += 1
        
        query_popularity = {
            'queries': [cat for cat, _ in sorted(query_category_counts.items(), key=lambda x: x[1], reverse=True)],
            'counts': [count for _, count in sorted(query_category_counts.items(), key=lambda x: x[1], reverse=True)]
        }
        
        # Dataset popularity (labelled using data_registry.yml when possible)
        dataset_counts = defaultdict(int)
        for event in events:
            if event.datasets_mentioned:
                try:
                    datasets = json.loads(event.datasets_mentioned)
                    for dataset in datasets:
                        if not dataset:
                            continue
                        # Normalize to string and lowercase for counting
                        key = str(dataset).strip()
                        if not key:
                            continue
                        dataset_counts[key] += 1
                except (json.JSONDecodeError, TypeError):
                    pass

        # Map raw keys to friendly names using data_registry.yml
        sources = {}
        try:
            sources = get_sources() or {}
        except Exception:
            sources = {}

        # Dataset popularity should only show the datasets available in chat (and keep stable order).
        # We include zero-count datasets so the chart always reflects the supported options.
        allowed_dataset_ids = [
            "nex_gddp_cmip6",
            "llc2160_ocean",
            "llc2160_geos_atmosphere",
            "llc4320_ocean",
        ]

        def label_for_dataset(raw_key: str) -> str:
            # Exact match to registry source id
            if raw_key in sources:
                meta = sources.get(raw_key, {})
                return meta.get("name") or raw_key
            # Common aliases -> canonical IDs
            alias_map = {
                "cmip6": "nex_gddp_cmip6",
                "nex-gddp-cmip6": "nex_gddp_cmip6",
                "nex_gddp": "nex_gddp_cmip6",
                "llc2160": "llc2160_ocean",
            }
            canonical = alias_map.get(raw_key.lower())
            if canonical and canonical in sources:
                meta = sources.get(canonical, {})
                return meta.get("name") or canonical
            # Fallback: title-case the raw key
            return raw_key.replace("_", " ").replace("-", " ").title()

        dataset_popularity = {
            "names": [label_for_dataset(ds_id) for ds_id in allowed_dataset_ids],
            "counts": [int(dataset_counts.get(ds_id, 0)) for ds_id in allowed_dataset_ids],
        }
        
        # Action popularity
        action_counts = defaultdict(int)
        for event in events:
            if event.query_text:
                query_lower = event.query_text.lower()
                if 'code' in query_lower or 'python' in query_lower:
                    action_counts['Code Generation'] += 1
                if 'plot' in query_lower or 'visualiz' in query_lower or 'graph' in query_lower:
                    action_counts['Visualization'] += 1
                if 'data' in query_lower or 'dataset' in query_lower:
                    action_counts['Data Exploration'] += 1
                if 'trend' in query_lower or 'analysis' in query_lower or 'anomaly' in query_lower:
                    action_counts['Analysis'] += 1
                if 'compare' in query_lower or 'difference' in query_lower:
                    action_counts['Comparison'] += 1
                if not any(x in query_lower for x in ['code', 'plot', 'visualiz', 'graph', 'data', 'dataset', 'trend', 'analysis', 'anomaly', 'compare', 'difference']):
                    action_counts['General Query'] += 1
        
        action_popularity = {
            'actions': list(action_counts.keys()),
            'counts': list(action_counts.values())
        }
        
        # Top barriers
        barrier_counts = defaultdict(int)
        for event in events:
            if event.accessibility_barriers:
                try:
                    barriers = json.loads(event.accessibility_barriers)
                    for barrier in barriers:
                        barrier_counts[barrier] += 1
                except (json.JSONDecodeError, TypeError):
                    pass
        
        top_barriers = [
            {'name': barrier.replace('_', ' ').title(), 'count': count}
            for barrier, count in sorted(barrier_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        ]
        
        # Pathway success rates
        stage1_success = 100.0
        
        datasets_found_events = []
        for e in events:
            if not e.datasets_mentioned:
                continue
            try:
                datasets = json.loads(e.datasets_mentioned)
                if datasets:
                    datasets_found_events.append(e)
            except (json.JSONDecodeError, TypeError, ValueError):
                # Ignore malformed JSON in legacy records
                continue
        stage2_success = (len(datasets_found_events) / max(total_events, 1) * 100) if total_events > 0 else 0
        
        code_generated_events = [
            e for e in events 
            if any(word in (e.query_text or '').lower() 
                   for word in ['code', 'how', 'access', 'retrieve', 'download', 'read', 'load'])
        ]
        stage3_success = (len(code_generated_events) / max(total_events, 1) * 100) if total_events > 0 else 0
        
        # Final stage mirrors stage 3 for now (we no longer compute an explicit success_rate metric)
        stage4_success = stage3_success
        
        pathway_success_rates = [stage1_success, stage2_success, stage3_success, stage4_success]
        
        # Model popularity
        model_counts = defaultdict(int)
        model_time_to_insight = defaultdict(list)
        
        for e in events:
            m = getattr(e, 'model_used', None)
            if m:
                model_counts[m] += 1
                if e.time_to_insight:
                    model_time_to_insight[m].append(e.time_to_insight)
        
        model_popularity = {
            'models': [m for m, _ in sorted(model_counts.items(), key=lambda x: x[1], reverse=True)],
            'counts': [cnt for _, cnt in sorted([(k, v) for k, v in model_counts.items()], key=lambda x: x[1], reverse=True)]
        }
        
        return jsonify({
            'query_popularity': query_popularity,
            'dataset_popularity': dataset_popularity,
            'action_popularity': action_popularity,
            'top_barriers': top_barriers,
            'pathway_success_rates': pathway_success_rates,
            'total_events': total_events,
            'model_popularity': model_popularity,
        })
    except Exception as e:
        logger.error(f"Error getting accessibility metrics: {e}")
        return jsonify({'error': 'Failed to get metrics'}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Chat Session Management API ────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/sessions")
def sessions():
    """Return user's chat sessions, including shared and workspace sessions"""
    if "user_id" not in session:
        abort(401)
    
    try:
        user_id = session["user_id"]
        user = User.objects(id=user_id).first()
        user_email = user.email.lower() if user else None
        
        # Get user's own sessions
        own_sessions = ChatSession.objects(user_id=user_id).order_by('-updated_at')
        
        # Get sessions shared with this user
        shared_sessions = ChatSession.objects(
            is_shared=True,
            shared_with=user_id
        ).order_by('-updated_at')
        
        # Get workspace sessions (sessions in workspaces where user is a member)
        workspace_ids = []
        if user_email:
            workspaces = Workspace.objects(
                __raw__={
                    "$or": [
                        {"members": user_id},
                        {"member_emails": user_email}
                    ]
                }
            )
            workspace_ids = [str(ws.id) for ws in workspaces]
        
        workspace_sessions = ChatSession.objects(
            workspace_id__in=workspace_ids
        ).order_by('-updated_at') if workspace_ids else []

        items = []
        seen_uuids = set()
        
        # Add own sessions
        for cs in own_sessions:
            msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
            if msg_count == 0:
                continue
            
            items.append({
                "session_uuid": cs.session_uuid,
                "title": cs.title or "New Chat",
                "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                "workspace_id": cs.workspace_id,
                "is_shared": cs.is_shared,
                "is_owner": True
            })
            seen_uuids.add(cs.session_uuid)
        
        # Add shared sessions
        for cs in shared_sessions:
            if cs.session_uuid not in seen_uuids:
                msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
                if msg_count > 0:
                    items.append({
                        "session_uuid": cs.session_uuid,
                        "title": cs.title or "New Chat",
                        "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                        "workspace_id": cs.workspace_id,
                        "is_shared": True,
                        "is_owner": False
                    })
                    seen_uuids.add(cs.session_uuid)
        
        # Add workspace sessions
        for cs in workspace_sessions:
            if cs.session_uuid not in seen_uuids:
                msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
                if msg_count > 0:
                    items.append({
                        "session_uuid": cs.session_uuid,
                        "title": cs.title or "New Chat",
                        "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                        "workspace_id": cs.workspace_id,
                        "is_shared": False,
                        "is_owner": cs.user_id == user_id
                    })
                    seen_uuids.add(cs.session_uuid)

        return jsonify(items)
    except Exception as e:
        logger.error(f"Error fetching sessions: {e}")
        return jsonify({'error': 'Failed to fetch sessions'}), 500

@app.route("/load_chat/<sid>")
def load_chat(sid):
    if "user_id" not in session:
        abort(401)
    
    try:
        user_id = session["user_id"]
        user = User.objects(id=user_id).first()
        user_email = user.email.lower() if user else None
        
        # Check if session exists
        cs = ChatSession.objects(session_uuid=sid).first()
        if not cs:
            abort(404)
        
        # Check access: user owns it, it's shared with them, or it's in a workspace they're a member of
        has_access = False
        
        # Check if user owns the session
        if cs.user_id == user_id:
            has_access = True
        
        # Check if session is shared with user
        if not has_access and cs.is_shared and user_id in (cs.shared_with or []):
            has_access = True
        
        # Check if session is in a workspace the user is a member of
        if not has_access and cs.workspace_id:
            workspace = Workspace.objects(id=cs.workspace_id).first()
            if workspace:
                is_member = (
                    workspace.owner_id == user_id or
                    user_id in (workspace.members or []) or
                    (user_email and user_email in (workspace.member_emails or []))
                )
                if is_member:
                    has_access = True
        
        if not has_access:
            abort(403)  # Forbidden - user doesn't have access
        
        # Load messages from MongoDB
        messages = ChatMessage.objects(session_uuid=sid).order_by('timestamp')
        msg_list = [{"role": m.role, "content": m.content} for m in messages]
        
        # Fallback to JSON file if no messages in MongoDB
        if not msg_list:
            path = os.path.join(LOG_DIR, f"{sid}.json")
            if os.path.exists(path):
                with open(path) as f:
                    msg_list = json.load(f)
        
        return jsonify(msg_list)
    except Exception as e:
        logger.error(f"Error loading chat: {e}")
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException):
            raise
        abort(500)

@app.route("/new_chat", methods=["POST"])
def new_chat():
    if "user_id" not in session:
        abort(401)
    
    try:
        payload = request.get_json(silent=True) or {}
        dataset_id = payload.get("dataset_id")
        sid = str(uuid.uuid4())
        
        # Create ChatSession in MongoDB
        cs = ChatSession(session_uuid=sid, user_id=session["user_id"], title="New Chat")
        cs.save()
        
        # Store system message in MongoDB (optionally scope to one dataset to keep prompt small)
        # Use unified chat system prompt builder so user datasets are supported.
        from routes.utils import get_chat_system_prompt
        _sys = get_chat_system_prompt(dataset_id)
        system_msg = ChatMessage(session_uuid=sid, role="system", content=_sys)
        system_msg.save()
        
        # Keep in memory for this request
        histories[sid] = [{"role": "system", "content": _sys}]
        
        return jsonify({"session_id": sid})
    except Exception as e:
        logger.error(f"Error creating new chat: {e}")
        return jsonify({'error': 'Failed to create chat'}), 500

@app.route("/delete_chat/<sid>", methods=["DELETE"])
def delete_chat(sid):
    if "user_id" not in session:
        abort(401)
    
    try:
        cs = ChatSession.objects(session_uuid=sid, user_id=session["user_id"]).first()
        
        if cs:
            try:
                # Delete dependent records
                DataAccessEvent.objects(session_uuid=cs.session_uuid).delete()
                
                traces = list(AIReasoningTrace.objects(session_uuid=cs.session_uuid))
                trace_ids = [t.id for t in traces]
                
                if trace_ids:
                    AIUncertaintyEvent.objects(reasoning_trace_id__in=trace_ids).delete()
                    PlainLanguageSummary.objects(reasoning_trace_id__in=trace_ids).delete()
                    DataProvenance.objects(reasoning_trace_id__in=trace_ids).delete()
                    AIReasoningTrace.objects(id__in=trace_ids).delete()
                
                cs.delete()
            except Exception as e:
                logger.exception(f"Failed to delete chat session {sid}: {e}")
                return jsonify({"error": "Failed to delete chat session"}), 500
        
        histories.pop(sid, None)
        path = os.path.join(LOG_DIR, f"{sid}.json")
        if os.path.exists(path):
            os.remove(path)
        
        return jsonify({"deleted": True})
    except Exception as e:
        logger.error(f"Error deleting chat: {e}")
        return jsonify({'error': 'Failed to delete chat'}), 500

@app.route("/cleanup_empty_chats", methods=["POST"])
def cleanup_empty_chats_endpoint():
    """Clean up empty chat sessions"""
    if "user_id" not in session:
        abort(401)
    
    try:
        user_sessions = ChatSession.objects(user_id=session["user_id"])
        empty_sessions = []
        
        for cs in user_sessions:
            path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
            if os.path.exists(path):
                try:
                    with open(path) as f:
                        msgs = json.load(f)
                    conversation_msgs = [m for m in msgs if m.get("role") in ("user", "assistant")]
                    if not conversation_msgs:
                        empty_sessions.append(cs)
                except (json.JSONDecodeError, IOError):
                    empty_sessions.append(cs)
            else:
                empty_sessions.append(cs)
        
        for cs in empty_sessions:
            cs.delete()
            path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
            if os.path.exists(path):
                os.remove(path)
            histories.pop(cs.session_uuid, None)
        
        return jsonify({"cleaned_up": len(empty_sessions), "message": f"Cleaned up {len(empty_sessions)} empty chat session(s)"})
    except Exception as e:
        logger.error(f"Error cleaning up chats: {e}")
        return jsonify({'error': 'Failed to cleanup chats'}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Main Chat Endpoint ─────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/suggest_title", methods=["POST"])
def suggest_title():
    """Generate a title suggestion for the chat based on first message"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json(force=True)
        sid = data.get("session_id")
        
        if not sid:
            return jsonify({"error": "Bad request"}), 400
        
        # Get first user message
        first_msg = ChatMessage.objects(session_uuid=sid, role="user").order_by('timestamp').first()
        
        if first_msg:
            # Simple title generation: take first 50 chars of first message
            title = first_msg.content[:50].strip()
            if len(first_msg.content) > 50:
                title += "..."
            
            # Update session title
            cs = ChatSession.objects(session_uuid=sid).first()
            if cs:
                cs.title = title
                cs.save()
            
            return jsonify({"title": title})
        
        return jsonify({"title": "New Chat"})
    except Exception as e:
        logger.error(f"Error suggesting title: {e}")
        return jsonify({"title": "New Chat"})

@app.route("/suggest_followups", methods=["POST"])
def suggest_followups():
    """Suggest follow-up questions based on conversation"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json(force=True)
        sid = data.get("session_id")
        
        if not sid:
            return jsonify({"error": "Bad request"}), 400
        
        # Simple follow-up suggestions related to climate data
        suggestions = [
            "How can I access this dataset using Python?",
            "What's the spatial resolution of this data?",
            "Show me an example visualization",
            "What are the available variables?"
        ]
        
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        logger.error(f"Error suggesting followups: {e}")
        return jsonify({"suggestions": []})

@app.route("/chat", methods=["POST"])
@limiter.limit("90 per minute")  # Rate limit: 90 requests per minute
@handle_api_errors
def chat_endpoint():
    """
    Main chat endpoint for user queries
    ---
    tags:
      - Chat
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - session_id
            - message
          properties:
            session_id:
              type: string
              description: Chat session UUID
            message:
              type: string
              description: User message/query
            model:
              type: string
              description: Optional model deployment name
    responses:
      200:
        description: Streaming response
      400:
        description: Bad request
      401:
        description: Unauthorized
      429:
        description: Rate limit exceeded
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    
    # Validate input
    try:
        sid = validate_session_id(data.get("session_id", ""))
        user_msg = validate_query_text(data.get("message", ""))
        model = data.get("model")  # Optional
        dataset_id = data.get("dataset_id")  # Optional dataset scope
    except AppValidationError as e:
        raise AppValidationError(str(e))
    
    if not sid or not user_msg:
        raise AppValidationError("session_id and message are required")
    
    # Check if user has access to this session
    user_id = session["user_id"]
    user = User.objects(id=user_id).first()
    user_email = user.email.lower() if user else None
    
    cs = ChatSession.objects(session_uuid=sid).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # Check access: user owns it, it's shared with them, or it's in a workspace they're a member of
    has_access = False
    
    # Check if user owns the session
    if cs.user_id == user_id:
        has_access = True
    
    # Check if session is shared with user
    if not has_access and cs.is_shared and user_id in (cs.shared_with or []):
        has_access = True
    
    # Check if session is in a workspace the user is a member of
    if not has_access and cs.workspace_id:
        workspace = Workspace.objects(id=cs.workspace_id).first()
        if workspace:
            is_member = (
                workspace.owner_id == user_id or
                user_id in (workspace.members or []) or
                (user_email and user_email in (workspace.member_emails or []))
            )
            if is_member:
                has_access = True
    
    if not has_access:
        raise UnauthorizedError("You don't have access to this session")

    # Load history from MongoDB or JSON fallback
    if sid not in histories:
        messages = ChatMessage.objects(session_uuid=sid).order_by('timestamp')
        if messages:
            histories[sid] = [{"role": m.role, "content": m.content} for m in messages]
        else:
            path = os.path.join(LOG_DIR, f"{sid}.json")
            if os.path.exists(path):
                with open(path) as f:
                    histories[sid] = json.load(f)
            else:
                return jsonify({"error": "Bad request"}), 400

    query_start_time = datetime.now()
    
    # Save user message to MongoDB
    user_message = ChatMessage(session_uuid=sid, role="user", content=user_msg)
    user_message.save()
    
    histories[sid].append({"role": "user", "content": user_msg})

    # Keep system prompt aligned with the selected dataset scope (if provided)
    try:
        if dataset_id:
            registry_block = get_registry_context_for_prompt([dataset_id])
            new_sys = SYSTEM_PROMPT if not registry_block else (SYSTEM_PROMPT + "\n\n" + registry_block)
            if histories[sid] and histories[sid][0].get("role") == "system":
                histories[sid][0]["content"] = new_sys
            else:
                histories[sid].insert(0, {"role": "system", "content": new_sys})

            sys_msg = ChatMessage.objects(session_uuid=sid, role="system").order_by('timestamp').first()
            if sys_msg:
                sys_msg.content = new_sys
                sys_msg.save()
    except Exception:
        pass

    def generate():
        full = ""
        datasets_mentioned = []
        retrieved_docs = []

        try:
            # Stream chat response (with MCP-style tools)
            for chunk in chat_stream_with_tools(
                histories[sid],
                deployment_name=model,
                provenance_sink=retrieved_docs,
            ):
                if chunk:
                    full += chunk
                    yield chunk.encode("utf-8")
        except Exception as e:
            from services.error_handler import format_user_friendly_error, log_error_with_context
            log_error_with_context(e, user_id=session.get("user_id"), session_id=sid)
            error_msg = format_user_friendly_error(e)
            yield f"⚠️ Error: {error_msg}".encode("utf-8")
            return
        
        try:
            # Strip progress/tool markers (VIZ_IMAGES contains huge base64; don't save or count as tokens)
            full_clean = re.sub(r'<!--PROGRESS:.*?-->', '', full, flags=re.DOTALL) if full else full
            full_clean = re.sub(r'<!--TOOLS_USED:[\s\S]*?-->', '', full_clean or '')
            full_clean = re.sub(r'<!--VIZ_IMAGES:[\s\S]*?-->', '', full_clean or '')
            full_clean = re.sub(r'<!--LIVE_TOOL_CODE_B64:[\s\S]*?-->', '', full_clean or '')
            full_clean = (full_clean or '').strip()
            from routes.chat import strip_sandbox_figure_markdown

            full_clean = strip_sandbox_figure_markdown(full_clean)
            # Save assistant response to MongoDB
            assistant_message = ChatMessage(session_uuid=sid, role="assistant", content=full_clean)
            assistant_message.save()
            
            # Update session timestamp
            cs = ChatSession.objects(session_uuid=sid).first()
            if cs:
                cs.updated_at = datetime.now()
                cs.save()
            
            # Save to history
            histories[sid].append({"role": "assistant", "content": full_clean})
            
            # Track token usage and cost
            token_usage_data = None
            try:
                from services.token_counter import (
                    count_messages_tokens, estimate_cost, track_token_usage,
                    count_tokens as count_text_tokens
                )
                input_tokens = count_messages_tokens(histories[sid], model or DEPLOYMENT_NAME)
                output_tokens = count_text_tokens(full_clean, model or DEPLOYMENT_NAME)
                token_usage = track_token_usage(
                    user_id=session["user_id"],
                    session_id=sid,
                    model=model or DEPLOYMENT_NAME,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens
                )
                token_usage_data = {
                    'tokens': token_usage['total_tokens'],
                    'cost': token_usage['total_cost_usd']
                }
                logger.info(f"Token usage: {token_usage['total_tokens']} tokens, "
                          f"cost=${token_usage['total_cost_usd']:.6f}")
            except Exception as e:
                logger.warning(f"Token tracking failed: {e}")
            
            # Send token usage info to frontend as special marker
            if token_usage_data:
                yield f"\n\n<!--TOKEN_USAGE:{json.dumps(token_usage_data)}-->".encode("utf-8")
            
            ENABLE_ANALYTICS = True
            
            if ENABLE_ANALYTICS:
                processing_time_ms = int((datetime.now() - query_start_time).total_seconds() * 1000)
                
                # Prefer explicit dataset scope if provided by the UI (more reliable than text scanning)
                if dataset_id:
                    datasets_mentioned = [dataset_id]
                else:
                    climate_datasets = [
                        'cmip6', 'loca', 'cordex', 'nex-gddp', 'era5', 'daymet',
                        'nex_gddp_cmip6', 'llc2160_ocean', 'llc2160_geos_atmosphere', 'llc4320_ocean',
                    ]
                    datasets_mentioned = [ds for ds in climate_datasets if ds.lower() in (full_clean or full).lower()]
                
                # Evaluate response success using LLM via track_ai_reasoning 
                # (We initialize success_score to 0.0 but it will be calculated during tracking and stored in DB. 
                # We can do an immediate lightweight calculation if needed, but since tracking happens in background we'll estimate)
                success_score = 0.0 # A placeholder, the accurate score is evaluated and stored in AIReasoningTrace
                
                def _background_post_processing(user_id, sid_local, user_query_local, response_text, retr_docs, proc_ms, datasets, success, model_used=None, conversation_hist=None, raw_stream_for_provenance=None):
                    try:
                        from services.analytics_service import calculate_response_confidence
                        quality_metrics = calculate_response_confidence(
                            response_text,
                            retr_docs,
                            conversation_hist,
                            user_query=user_query_local,
                        )
                        real_success_score = quality_metrics.get("overall", 0.0)
                        
                        merged_docs = merge_tools_used_marker_into_provenance(
                            retr_docs, raw_stream_for_provenance or ""
                        )
                        track_ai_reasoning(
                            user_id=user_id,
                            session_uuid=sid_local,
                            user_query=user_query_local,
                            response_content=response_text,
                            retrieved_docs=merged_docs,
                            processing_time_ms=proc_ms,
                            conversation_history=conversation_hist,
                            model_name=model_used or DEPLOYMENT_NAME,
                        )
                    except Exception as e:
                        logger.exception(f"Background: failed to track AI reasoning: {e}")
                        real_success_score = 0.0

                    try:
                        time_to_insight = (datetime.now() - query_start_time).total_seconds()
                        event = track_data_access_event(
                            user_id=user_id,
                            session_uuid=sid_local,
                            query_text=user_query_local,
                            datasets_found=datasets,
                            success_score=real_success_score,
                            model=model_used
                        )
                        if event:
                            event.time_to_insight = time_to_insight
                            event.save()
                    except Exception as e:
                        logger.exception(f"Background: failed to track accessibility event: {e}")

                    try:
                        if real_success_score > 0.6 and datasets:
                            update_user_expertise(user_id, user_query_local, datasets[0])
                    except Exception as e:
                        logger.exception(f"Background: failed to update user expertise: {e}")

                try:
                    thread = threading.Thread(
                        target=_background_post_processing,
                        args=(session["user_id"], sid, user_msg, full_clean, retrieved_docs, processing_time_ms, datasets_mentioned, success_score, model, histories[sid], full),
                        daemon=True,
                    )
                    thread.start()
                except Exception as e:
                    logger.exception(f"Failed to start background analytics thread: {e}")
                
        except Exception as e:
            logger.error(f"Post-processing error: {e}")

    return Response(
        stream_with_context(generate()),
        content_type="text/plain; charset=utf-8",
        direct_passthrough=True
    )

# ────────────────────────────────────────────────────────────────────────────
# ── Accessibility Features APIs ────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/api/plain_language_summary", methods=["POST"])
def plain_language_summary():
    """Generate beginner-friendly summary"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json(force=True)
        reasoning_trace_id = data.get("reasoning_trace_id")
        
        if not reasoning_trace_id:
            return jsonify({"error": "Missing reasoning_trace_id"}), 400
        
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        summary = PlainLanguageSummary.objects(reasoning_trace_id=reasoning_trace_id).first()
        
        if summary:
            return jsonify({
                "beginner_summary": summary.beginner_summary,
                "key_concepts": json.loads(summary.key_concepts or "[]"),
                "data_meaning": summary.data_meaning
            })
        
        # Generate new summary
        summary_prompt = f"""
You are an expert at explaining climate data to beginners. 

Original question: {trace.user_query}

Create a beginner-friendly summary (2-3 sentences max) that:
1. Explains what data was analyzed in simple terms
2. Avoids jargon or explains technical terms
3. States the key finding clearly

Also provide 3-5 key concepts mentioned in simple terms.

Format your response as JSON with keys: 'beginner_summary', 'key_concepts' (list), 'data_meaning'
"""
        
        summary_text = chat_non_streaming(
            [{"role": "user", "content": summary_prompt}],
            temperature=0.3,
            max_tokens=300
        )
        
        try:
            summary_json = json.loads(summary_text)
        except json.JSONDecodeError:
            summary_json = {
                "beginner_summary": summary_text,
                "key_concepts": [],
                "data_meaning": "Unable to parse structured response"
            }
        
        new_summary = PlainLanguageSummary(
            reasoning_trace_id=reasoning_trace_id,
            beginner_summary=summary_json.get("beginner_summary", ""),
            key_concepts=json.dumps(summary_json.get("key_concepts", [])),
            data_meaning=summary_json.get("data_meaning", "")
        )
        new_summary.save()
        
        return jsonify(summary_json)
    
    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        return jsonify({"error": f"Failed to generate summary: {str(e)}"}), 500

@app.route("/api/data_provenance/<reasoning_trace_id>", methods=["GET"])
def get_data_provenance(reasoning_trace_id):
    """Get provenance information"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        provenance_records = list(DataProvenance.objects(reasoning_trace_id=reasoning_trace_id))
        
        result = [
            {
                "dataset_name": prov.dataset_name,
                "source_origin": prov.source_origin,
                "last_updated": prov.last_updated.isoformat() if prov.last_updated else None,
                "confidence_level": prov.confidence_level,
                "data_quality_metrics": json.loads(prov.data_quality_metrics or "{}"),
                "usage_rights": prov.usage_rights
            }
            for prov in provenance_records
        ]
        
        return jsonify({"provenance": result})
    except Exception as e:
        logger.error(f"Error getting provenance: {e}")
        return jsonify({'error': 'Failed to get provenance'}), 500

@app.route("/api/add_provenance", methods=["POST"])
def add_provenance():
    """Add provenance information"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json(force=True)
        reasoning_trace_id = data.get("reasoning_trace_id")
        
        if not reasoning_trace_id:
            return jsonify({"error": "Missing reasoning_trace_id"}), 400
        
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        prov = DataProvenance(
            reasoning_trace_id=reasoning_trace_id,
            dataset_name=data.get("dataset_name", ""),
            source_origin=data.get("source_origin", ""),
            last_updated=datetime.fromisoformat(data["last_updated"]) if data.get("last_updated") else None,
            confidence_level=float(data.get("confidence_level", 1.0)),
            data_quality_metrics=json.dumps(data.get("data_quality_metrics", {})),
            usage_rights=data.get("usage_rights", "")
        )
        prov.save()
        
        return jsonify({"id": str(prov.id), "message": "Provenance added successfully"})
    except Exception as e:
        logger.error(f"Error adding provenance: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/glossary", methods=["GET"])
def get_glossary():
    """Get all glossary terms"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        terms = list(ClimateGlossary.objects())
        result = [
            {
                "id": str(term.id),
                "term": term.term,
                "definition": term.definition,
                "technical_definition": term.technical_definition,
                "examples": json.loads(term.examples or "[]"),
                "related_terms": json.loads(term.related_terms or "[]")
            }
            for term in terms
        ]
        
        return jsonify({"glossary": result})
    except Exception as e:
        logger.error(f"Error fetching glossary: {e}")
        return jsonify({'error': 'Failed to fetch glossary'}), 500

@app.route("/api/glossary_term/<term>", methods=["GET"])
def get_glossary_term(term):
    """Get definition for a specific term"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        term_record = ClimateGlossary.objects(term=term.lower()).first()
        
        if not term_record:
            return jsonify({"error": "Term not found"}), 404
        
        return jsonify({
            "term": term_record.term,
            "definition": term_record.definition,
            "technical_definition": term_record.technical_definition,
            "examples": json.loads(term_record.examples or "[]"),
            "related_terms": json.loads(term_record.related_terms or "[]")
        })
    except Exception as e:
        logger.error(f"Error fetching glossary term: {e}")
        return jsonify({'error': 'Failed to fetch term'}), 500

@app.route("/api/add_glossary_term", methods=["POST"])
def add_glossary_term():
    """Add new glossary term"""
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        data = request.get_json(force=True)
        
        existing = ClimateGlossary.objects(term=data.get("term", "").lower()).first()
        if existing:
            return jsonify({"error": "Term already exists"}), 409
        
        term_record = ClimateGlossary(
            term=data.get("term", "").lower(),
            definition=data.get("definition", ""),
            technical_definition=data.get("technical_definition", ""),
            examples=json.dumps(data.get("examples", [])),
            related_terms=json.dumps(data.get("related_terms", []))
        )
        term_record.save()
        
        return jsonify({"id": str(term_record.id), "message": "Term added successfully"})
    except NotUniqueError:
        return jsonify({"error": "Term already exists"}), 409
    except Exception as e:
        logger.error(f"Error adding glossary term: {e}")
        return jsonify({"error": str(e)}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Code Execution Endpoints ────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/api/execute_code", methods=["POST"])
@limiter.limit("60 per minute")
@handle_api_errors
def execute_code():
    """
    Execute Python code safely and return results
    ---
    tags:
      - Code Execution
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - code
          properties:
            code:
              type: string
              description: Python code to execute
            timeout:
              type: integer
              description: Execution timeout in seconds (default 30)
    responses:
      200:
        description: Code execution result
      400:
        description: Invalid code or security violation
      401:
        description: Unauthorized
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    code = data.get("code", "").strip()
    timeout = data.get("timeout", 30)
    
    if not code:
        raise AppValidationError("Code is required")
    
    if len(code) > 10000:
        raise AppValidationError("Code exceeds maximum length of 10000 characters")
    
    try:
        from services.code_executor import execute_code_safely
        
        result = execute_code_safely(code, timeout=timeout)
        
        return jsonify(result)
    except Exception as e:
        from services.error_handler import format_user_friendly_error, log_error_with_context
        log_error_with_context(e, user_id=session.get("user_id"))
        raise AppError(
            f"Code execution failed: {str(e)}",
            user_message=format_user_friendly_error(e)
        )


@app.route("/api/generate_visualization", methods=["POST"])
@limiter.limit("60 per minute")
@handle_api_errors
def generate_visualization():
    """
    Generate visualization from Python code
    ---
    tags:
      - Code Execution
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - code
          properties:
            code:
              type: string
              description: Python code that generates plots
            output_format:
              type: string
              description: Output format (png, svg, pdf)
    responses:
      200:
        description: Visualization result with base64-encoded images
      400:
        description: Invalid code
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    code = data.get("code", "").strip()
    output_format = data.get("output_format", "png")
    
    if not code:
        raise AppValidationError("Code is required")
    
    try:
        from services.code_executor import generate_visualization
        
        result = generate_visualization(code, output_format=output_format)
        return jsonify(result)
    except Exception as e:
        from services.error_handler import format_user_friendly_error, log_error_with_context
        log_error_with_context(e, user_id=session.get("user_id"))
        raise AppError(
            f"Visualization generation failed: {str(e)}",
            user_message=format_user_friendly_error(e)
        )


@app.route("/api/token_usage", methods=["GET"])
@handle_api_errors
def get_token_usage():
    """
    Get token usage statistics for current user
    ---
    tags:
      - Analytics
    parameters:
      - in: query
        name: days
        type: integer
        description: Number of days to look back (default 30)
    responses:
      200:
        description: Token usage statistics
      401:
        description: Unauthorized
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    days = request.args.get('days', 30, type=int)
    
    try:
        from services.token_counter import get_user_token_stats
        from models import TokenUsage
        from datetime import datetime, timedelta
        from collections import defaultdict
        
        stats = get_user_token_stats(session["user_id"], days=days)
        
        # Add daily breakdown for charts
        cutoff_date = datetime.now() - timedelta(days=days)
        usage_records = TokenUsage.objects(
            user_id=session["user_id"],
            timestamp__gte=cutoff_date
        ).order_by('timestamp')
        
        # Group by date
        daily_data = defaultdict(lambda: {'tokens': 0, 'cost': 0})
        for record in usage_records:
            date_key = record.timestamp.strftime('%Y-%m-%d')
            daily_data[date_key]['tokens'] += record.total_tokens
            daily_data[date_key]['cost'] += record.total_cost_usd
        
        stats['daily_breakdown'] = [
            {'date': date, 'tokens': data['tokens'], 'cost': data['cost']}
            for date, data in sorted(daily_data.items())
        ]
        
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting token usage: {e}")
        raise AppError("Failed to retrieve token usage statistics")


# ────────────────────────────────────────────────────────────────────────────
# ── Collaborative Features Endpoints ───────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.route("/api/share_session", methods=["POST"])
@limiter.limit("90 per hour")
@handle_api_errors
def share_session():
    """
    Share a chat session with other users
    ---
    tags:
      - Collaboration
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - session_id
            - user_ids
          properties:
            session_id:
              type: string
            user_ids:
              type: array
              items:
                type: string
    responses:
      200:
        description: Session shared successfully
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    user_ids = data.get("user_ids", [])
    
    if not isinstance(user_ids, list):
        raise AppValidationError("user_ids must be a list")
    
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # Add users to shared_with list
    current_shared = set(cs.shared_with or [])
    current_shared.update(user_ids)
    cs.shared_with = list(current_shared)
    cs.is_shared = True
    cs.shared_by = session["user_id"]
    cs.save()
    
    return jsonify({
        "success": True,
        "message": f"Session shared with {len(user_ids)} user(s)",
        "shared_with": cs.shared_with
    })


@app.route("/api/unshare_session", methods=["POST"])
@handle_api_errors
def unshare_session():
    """Unshare a chat session"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    cs.is_shared = False
    cs.shared_with = []
    cs.save()
    
    return jsonify({"success": True, "message": "Session unshared"})


@app.route("/api/shared_sessions", methods=["GET"])
@handle_api_errors
def get_shared_sessions():
    """Get sessions shared with current user"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    user_id = session["user_id"]
    
    # Get sessions shared with this user
    shared_sessions = ChatSession.objects(
        is_shared=True,
        shared_with=user_id
    ).order_by('-updated_at')
    
    result = []
    for cs in shared_sessions:
        result.append({
            "session_uuid": cs.session_uuid,
            "title": cs.title,
            "owner_id": cs.user_id,
            "shared_by": cs.shared_by,
            "last_modified": cs.updated_at.isoformat() if cs.updated_at else None
        })
    
    return jsonify({"sessions": result})


@app.route("/api/workspaces", methods=["GET", "POST"])
@handle_api_errors
def workspaces():
    """Get or create workspaces"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    user_id = session["user_id"]
    
    # Get current user's email
    user = User.objects(id=user_id).first()
    if not user:
        raise NotFoundError("User")
    user_email = user.email.lower() if user and user.email else ""
    
    if request.method == "POST":
        # Create new workspace
        data = request.get_json(force=True)
        name = sanitize_string(data.get("name", ""), max_length=255)
        description = sanitize_string(data.get("description", ""), max_length=1000)
        
        if not name:
            raise AppValidationError("Workspace name is required")
        
        workspace = Workspace(
            name=name,
            description=description,
            owner_id=user_id,
            members=[user_id],  # Owner is automatically a member
            member_emails=[user_email]  # Owner's email
        )
        workspace.save()
        
        return jsonify({
            "success": True,
            "workspace_id": str(workspace.id),
            "workspace": {
                "id": str(workspace.id),
                "name": workspace.name,
                "description": workspace.description,
                "owner_id": workspace.owner_id,
                "members": workspace.members,
                "member_emails": workspace.member_emails
            }
        })
    
    # GET: List all workspaces (User requested to show all workspaces as options)
    workspaces_list = Workspace.objects().order_by('-updated_at')
    
    result = []
    for ws in workspaces_list:
        result.append({
            "id": str(ws.id),
            "name": ws.name,
            "description": ws.description,
            "owner_id": ws.owner_id,
            "members": ws.members or [],
            "member_emails": ws.member_emails or [],
            "created_at": ws.created_at.isoformat() if ws.created_at else None
        })
    
    return jsonify({"workspaces": result})


@app.route("/api/workspaces/<workspace_id>", methods=["DELETE"])
@handle_api_errors
def delete_workspace(workspace_id):
    """Delete a workspace"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    user_id = session["user_id"]
    workspace = Workspace.objects(id=workspace_id).first()
    
    if not workspace:
        raise NotFoundError("Workspace")
    
    # Only owner can delete
    if workspace.owner_id != user_id:
        raise UnauthorizedError("Only workspace owner can delete the workspace")
    
    workspace.delete()
    
    return jsonify({
        "success": True,
        "message": "Workspace deleted successfully"
    })


@app.route("/api/workspaces/<workspace_id>/members", methods=["POST", "DELETE"])
@handle_api_errors
def manage_workspace_members(workspace_id):
    """Add or remove workspace members by email"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    user_id = session["user_id"]
    workspace = Workspace.objects(id=workspace_id).first()
    
    if not workspace:
        raise NotFoundError("Workspace")
    
    # Check if user is owner
    if workspace.owner_id != user_id:
        raise UnauthorizedError("Only workspace owner can manage members")
    
    if request.method == "POST":
        # Add member by email
        data = request.get_json(force=True)
        member_email = data.get("email", "").strip().lower()
        
        if not member_email:
            raise AppValidationError("Email is required")
        
        # Validate email format
        from services.input_validator import validate_email
        try:
            member_email = validate_email(member_email)
        except AppValidationError as e:
            raise AppValidationError(f"Invalid email: {str(e)}")
        
        # Find user by email
        member_user = User.objects(email=member_email).first()
        member_user_id = str(member_user.id) if member_user else None
        
        # Add to member_emails if not already there
        if member_email not in (workspace.member_emails or []):
            if workspace.member_emails is None:
                workspace.member_emails = []
            workspace.member_emails.append(member_email)
        
        # Add to members if user exists
        if member_user_id and member_user_id not in (workspace.members or []):
            if workspace.members is None:
                workspace.members = []
            workspace.members.append(member_user_id)
        
        workspace.save()
        
        return jsonify({
            "success": True,
            "members": workspace.members or [],
            "member_emails": workspace.member_emails or [],
            "message": f"Added {member_email} to workspace"
        })
    else:
        # Remove member by email
        data = request.get_json(force=True)
        member_email = data.get("email", "").strip().lower()
        
        if not member_email:
            raise AppValidationError("Email is required")
        
        # Find user by email
        member_user = User.objects(email=member_email).first()
        member_user_id = str(member_user.id) if member_user else None
        
        # Remove from member_emails
        if workspace.member_emails and member_email in workspace.member_emails:
            workspace.member_emails.remove(member_email)
        
        # Remove from members if exists
        if member_user_id and workspace.members and member_user_id in workspace.members:
            if member_user_id != workspace.owner_id:  # Can't remove owner
                workspace.members.remove(member_user_id)
        
        workspace.save()
        
        return jsonify({
            "success": True,
            "members": workspace.members or [],
            "member_emails": workspace.member_emails or [],
            "message": f"Removed {member_email} from workspace"
        })


@app.route("/api/query_builder/suggest", methods=["POST"])
@limiter.limit("90 per minute")
@handle_api_errors
def query_builder_suggest():
    """
    Get query suggestions based on partial input
    ---
    tags:
      - Query Builder
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            partial_query:
              type: string
            context:
              type: array
    responses:
      200:
        description: Query suggestions
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    partial_query = sanitize_string(data.get("partial_query", ""), max_length=500)
    context = data.get("context", [])
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        suggestions = builder.generate_query_suggestions(partial_query, context)
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        logger.error(f"Query suggestion failed: {e}")
        raise AppError("Failed to generate query suggestions")


@app.route("/api/query_builder/structure", methods=["POST"])
@limiter.limit("90 per minute")
@handle_api_errors
def query_builder_structure():
    """
    Convert natural language query to structured format
    ---
    tags:
      - Query Builder
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - query
          properties:
            query:
              type: string
    responses:
      200:
        description: Structured query
    """
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    query = validate_query_text(data.get("query", ""))
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        structured = builder.suggest_query_structure(query)
        return jsonify(structured)
    except Exception as e:
        logger.error(f"Query structuring failed: {e}")
        raise AppError("Failed to structure query")


@app.route("/api/query_builder/templates", methods=["GET"])
@handle_api_errors
def query_builder_templates():
    """Get available query templates"""
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        templates = builder.get_query_templates()
        return jsonify({"templates": templates})
    except Exception as e:
        logger.error(f"Failed to get templates: {e}")
        raise AppError("Failed to retrieve query templates")


@app.route("/api/query_builder/validate", methods=["POST"])
@handle_api_errors
def query_builder_validate():
    """Validate a query and provide feedback"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    query = validate_query_text(data.get("query", ""))
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        validation = builder.validate_query(query)
        return jsonify(validation)
    except Exception as e:
        logger.error(f"Query validation failed: {e}")
        raise AppError("Failed to validate query")


@app.route("/api/assign_session_to_workspace", methods=["POST"])
@handle_api_errors
def assign_session_to_workspace():
    """Assign a chat session to a workspace"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    workspace_id = data.get("workspace_id", "").strip()
    
    # Get session
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # If workspace_id is empty, remove from workspace
    if not workspace_id:
        cs.workspace_id = None
        cs.save()
        return jsonify({"success": True, "message": "Session removed from workspace"})
    
    # Check if workspace exists
    workspace = Workspace.objects(id=workspace_id).first()
    if not workspace:
        raise NotFoundError("Workspace")
    
    # Check if user is member of workspace
    is_member = (
        workspace.owner_id == session["user_id"] or
        session["user_id"] in (workspace.members or []) or
        (user_email and user_email in (workspace.member_emails or []))
    )
    
    # We no longer strictly require membership since the user requested to see and use all workspaces as options
    
    cs.workspace_id = workspace_id
    cs.save()
    
    return jsonify({
        "success": True,
        "message": f"Session assigned to workspace '{workspace.name}'",
        "workspace_id": workspace_id
    })


@app.route("/api/session_comments", methods=["GET", "POST"])
@handle_api_errors
def session_comments():
    """Get or add comments on a session"""
    if "user_id" not in session:
        raise UnauthorizedError()
    
    user_id = session["user_id"]
    
    if request.method == "POST":
        # Add comment
        data = request.get_json(force=True)
        session_id = validate_session_id(data.get("session_id", ""))
        comment_text = sanitize_string(data.get("comment", ""), max_length=1000)
        message_index = data.get("message_index")
        
        if not comment_text:
            raise AppValidationError("Comment text is required")
        
        # Check access to session
        cs = ChatSession.objects(session_uuid=session_id).first()
        if not cs:
            raise NotFoundError("Chat session")
        
        if cs.user_id != user_id and (not cs.is_shared or user_id not in cs.shared_with):
            raise UnauthorizedError("No access to this session")
        
        comment = SessionComment(
            session_uuid=session_id,
            user_id=user_id,
            comment_text=comment_text,
            message_index=message_index
        )
        comment.save()
        
        return jsonify({
            "success": True,
            "comment_id": str(comment.id),
            "comment": {
                "id": str(comment.id),
                "user_id": comment.user_id,
                "comment_text": comment.comment_text,
                "message_index": comment.message_index,
                "created_at": comment.created_at.isoformat()
            }
        })
    
    # GET: Get comments for a session
    session_id = request.args.get("session_id", "")
    if not session_id:
        raise AppValidationError("session_id is required")
    
    session_id = validate_session_id(session_id)
    
    # Check access
    cs = ChatSession.objects(session_uuid=session_id).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    if cs.user_id != user_id and (not cs.is_shared or user_id not in cs.shared_with):
        raise UnauthorizedError("No access to this session")
    
    comments = SessionComment.objects(session_uuid=session_id).order_by('created_at')
    
    result = []
    for comment in comments:
        result.append({
            "id": str(comment.id),
            "user_id": comment.user_id,
            "comment_text": comment.comment_text,
            "message_index": comment.message_index,
            "created_at": comment.created_at.isoformat()
        })
    
    return jsonify({"comments": result})


# ────────────────────────────────────────────────────────────────────────────
# ── Utility Endpoints ──────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

@app.get("/api/models")
def api_models():
    """Return available deployment models"""
    try:
        env_list = list_available_deployments()
        if env_list:
            return jsonify(env_list)
    except Exception:
        pass

    candidates = []
    for k in os.environ:
        if k.startswith("DEPLOYMENT_NAME"):
            v = os.environ.get(k)
            if v and v not in candidates:
                candidates.append(v)
    
    if candidates:
        return jsonify(candidates)
    
    return jsonify([os.getenv("DEPLOYMENT_NAME") or "azure-model"])

# ────────────────────────────────────────────────────────────────────────────
# ── Arena Debate Endpoints ────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

from uuid import uuid4
arenas = {}

DEBATE_RULES = (
    "You are participating in a structured scientific debate about downscaled climate datasets. "
    "Right now, only NASA NEX-GDDP-CMIP6 dataset is available. Keep arguments factual, concise, and specific to data access, "
    "variables, scenarios, spatial/temporal ranges, and reproducible methods. Be respectful and avoid rhetoric. "
    "Do not generate Python code in arena responses. Keep responses conceptual and evidence-based. "
    "Prefer 4–8 sentences. No emojis."
)

ARENA_SYSTEM_PROMPT = (
    "You are EARTH-VUE in AI-vs-AI Arena mode. "
    "This mode is for conceptual debate and comparative reasoning only. "
    "Do NOT generate or suggest executable code blocks. "
    "If asked for code, state that code generation is only available in Classic Chat."
)

MULTIMODAL_SYSTEM_PROMPT = (
    "You are EARTH-VUE in Multimodal Compare mode. "
    "Provide concise comparative analysis and explanations only. "
    "Do NOT generate executable code or code snippets in this mode. "
    "If the user requests code, tell them code generation is supported in Classic Chat."
)

def side_system_prompt(side_label: str, stance_label: str) -> str:
    other = "B" if side_label == "A" else "A"
    return (
        ARENA_SYSTEM_PROMPT
        + "\n\n"
        + DEBATE_RULES
        + f"\n\nYou are Debater {side_label} ({stance_label}). "
          f"Your goal is to advance your position and rebut Debater {other}'s points. "
          f"Speak as Debater {side_label}. Keep it tight and technically grounded."
    )

def _ensure_arena(arena_id: str):
    if arena_id not in arenas:
        arenas[arena_id] = {
            "messages": [{"role": "system", "content": ARENA_SYSTEM_PROMPT}],
            "stanceA": "Pro",
            "stanceB": "Con",
            "created": datetime.now(timezone.utc).isoformat(),
        }

@app.post("/arena/new")
def arena_new():
    """Create a new arena"""
    data = request.get_json(force=True) if request.data else {}
    user_prompt = (data or {}).get("prompt", "").strip()
    stanceA = (data or {}).get("stanceA") or "Pro"
    stanceB = (data or {}).get("stanceB") or "Con"

    arena_id = str(uuid4())
    arenas[arena_id] = {
        "messages": [{"role": "system", "content": ARENA_SYSTEM_PROMPT}],
        "stanceA": stanceA,
        "stanceB": stanceB,
        "created": datetime.now(timezone.utc).isoformat(),
    }
    if user_prompt:
        arenas[arena_id]["messages"].append({"role": "user", "content": user_prompt})
    
    return jsonify({"arena_id": arena_id})

@app.post("/arena/turn")
def arena_turn():
    """Stream a single turn in arena debate"""
    data = request.get_json(force=True)
    arena_id = (data.get("arena_id") or "").strip()
    side = (data.get("side") or "A").upper()
    
    if side not in ("A", "B"):
        return jsonify({"error": "side must be 'A' or 'B'"}), 400

    _ensure_arena(arena_id)
    st = arenas[arena_id]

    if not any(m["role"] == "user" for m in st["messages"]):
        first_prompt = (data.get("prompt") or "").strip()
        if first_prompt:
            st["messages"].append({"role": "user", "content": first_prompt})
        else:
            return jsonify({"error": "missing initial prompt"}), 400

    stance_label = st["stanceA"] if side == "A" else st["stanceB"]
    system_for_side = side_system_prompt(side, stance_label)

    messages = [{"role": "system", "content": system_for_side}] + st["messages"]

    def generate():
        full = ""
        try:
            for chunk in chat_stream(messages, temperature=0.4, max_tokens=900):
                if chunk:
                    full += chunk
                    yield chunk.encode("utf-8")
        except Exception as e:
            logger.error(f"Arena streaming error: {e}")
            yield f"Error: {str(e)}".encode("utf-8")
            return
        
        st["messages"].append({"role": "assistant", "content": f"[Debater {side}] {full}"})

    return Response(stream_with_context(generate()),
                    content_type="text/plain; charset=utf-8",
                    direct_passthrough=True)

@app.post("/api/arena/respond")
def api_arena_respond():
    """Non-streaming arena response"""
    data = request.get_json(force=True)
    messages_in = data.get("messages") or []
    side = (data.get("side") or "A").upper()

    if not isinstance(messages_in, list) or not messages_in:
        return jsonify({"error": "messages required"}), 400
    if side not in ("A", "B"):
        return jsonify({"error": "side must be 'A' or 'B'"}), 400

    resolution = ""
    for m in messages_in:
        if m.get("role") == "user":
            resolution = (m.get("content") or "").strip()
            break

    stance = "PRO (support)" if side == "A" else "CON (oppose)"
    stance_tag = "SUPPORT" if side == "A" else "OPPOSE"

    stance_rules = f"""
You are Debater {side}. Your immutable stance is {stance} the resolution below.

Resolution: "{resolution}"

Debate rules (follow strictly):
- If PRO: defend the resolution decisively and emphasize strengths, applications, and evidence.
- If CON: refute the resolution decisively and emphasize limitations, risks, and counter-evidence.
- Do NOT hedge or partially agree with the opposite stance.
- Don't use more than 4-5 sentences per turn.
- Try to be concrete. don't use a lot of bullet points.
- Use technical language and specific climate data terms.
- Treat any prior *assistant* messages in the conversation as the other debater's points; quote or paraphrase at least two and rebut them directly.
- Use concrete climate-data specifics (variables, scenarios, temporal/spatial ranges) and short, runnable Python snippets with real values (xarray/intake/OpenVisus) when helpful.
- End with a one-line stance marker: "[Debater {side} – I {stance_tag} the resolution]".
"""

    sys_msg = {"role": "system", "content": ARENA_SYSTEM_PROMPT + "\n\n" + stance_rules}
    model = (data.get("model") or os.getenv("DEPLOYMENT_NAME"))
    
    try:
        text = chat_non_streaming([sys_msg] + messages_in, temperature=0.4, max_tokens=900, deployment_name=model)
        return jsonify({"text": text})
    except Exception as e:
        logger.error(f"Arena error: {e}")
        return jsonify({"error": str(e)}), 500

@app.post("/api/arena_embeddings")
def api_arena_embeddings():
    """Generates 2D coordinates representing the semantic trajectory of the debate."""
    try:
        data = request.get_json(force=True)
        history = data.get("history", [])
        
        if not history:
            return jsonify({"nodesA": [], "nodesB": []})
            
        import numpy as np
        from sentence_transformers import SentenceTransformer
        from sklearn.decomposition import PCA
        
        # Load a small, fast sentence transformer model
        model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # We need a shared vector space for both A and B.
        # Let's extract sentences and embed them.
        import nltk
        try:
            nltk.data.find('tokenizers/punkt')
            nltk.data.find('tokenizers/punkt_tab')
        except LookupError:
            nltk.download('punkt', quiet=True)
            nltk.download('punkt_tab', quiet=True)
            
        from nltk.tokenize import sent_tokenize
        
        nodesA, nodesB = [], []
        
        # We'll collect all sentences across the entire debate to fit the PCA space
        all_sentences = []
        sentence_metadata = [] # stores (side, turn_index, sentence_index)
        
        for turn_idx, turn in enumerate(history):
            side = turn.get('speaker')
            if side not in ('A', 'B'):
                continue
                
            text = turn.get('text', '')
            # Split text into sentences for more granular semantic nodes
            sentences = sent_tokenize(text)
            
            for sent_idx, sentence in enumerate(sentences):
                if len(sentence.strip()) > 10: # Ignore very short artifacts
                    all_sentences.append(sentence)
                    sentence_metadata.append((side, turn_idx, sent_idx))
                    
        if not all_sentences:
            return jsonify({"nodesA": [], "nodesB": []})
            
        # Get dense vector embeddings
        embeddings = model.encode(all_sentences)
        
        # Use PCA to project embeddings down to 2D
        # If there are fewer than 2 sentences, handle gracefully
        if len(embeddings) < 2:
            coords = np.zeros((len(embeddings), 2))
        else:
            pca = PCA(n_components=2)
            coords = pca.fit_transform(embeddings)
            
            # Normalize coordinates to a consistent -20 to 20 range for the UI
            if len(coords) > 1:
                max_val = np.abs(coords).max()
                if max_val > 0:
                    # scale to roughly [-15, 15] range
                    coords = (coords / max_val) * 15.0
                    
        # Group coordinates back to their respective models
        for i, (side, t_idx, s_idx) in enumerate(sentence_metadata):
            node = {
                "x": float(coords[i][0]),
                "y": float(coords[i][1]),
                "sentence": all_sentences[i]
            }
            if side == 'A':
                nodesA.append(node)
            else:
                nodesB.append(node)
                
        return jsonify({
            "nodesA": nodesA, 
            "nodesB": nodesB
        })
        
    except Exception as e:
        logger.error(f"Error calculating embeddings: {e}")
        return jsonify({"error": str(e)}), 500

# ────────────────────────────────────────────────────────────────────────────
# ── Startup & Cleanup ──────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

def cleanup_empty_chats():
    """Remove empty chat sessions from MongoDB and disk"""
    try:
        all_sessions = ChatSession.objects()
        empty_sessions = []
        
        for cs in all_sessions:
            path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
            if os.path.exists(path):
                try:
                    with open(path) as f:
                        msgs = json.load(f)
                    conversation_msgs = [m for m in msgs if m.get("role") in ("user", "assistant")]
                    if not conversation_msgs:
                        empty_sessions.append(cs)
                except (json.JSONDecodeError, IOError):
                    empty_sessions.append(cs)
            else:
                empty_sessions.append(cs)
        
        for cs in empty_sessions:
            try:
                logger.info(f"Cleaning up empty chat session: {cs.session_uuid}")

                DataAccessEvent.objects(session_uuid=cs.session_uuid).delete()

                traces = list(AIReasoningTrace.objects(session_uuid=cs.session_uuid))
                trace_ids = [t.id for t in traces]
                
                if trace_ids:
                    AIUncertaintyEvent.objects(reasoning_trace_id__in=trace_ids).delete()
                    PlainLanguageSummary.objects(reasoning_trace_id__in=trace_ids).delete()
                    DataProvenance.objects(reasoning_trace_id__in=trace_ids).delete()
                    AIReasoningTrace.objects(id__in=trace_ids).delete()

                cs.delete()
                path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
                if os.path.exists(path):
                    os.remove(path)
                histories.pop(cs.session_uuid, None)
            except Exception as e:
                logger.error(f"Error cleaning up session {cs.session_uuid}: {e}")

        if empty_sessions:
            logger.info(f"Cleaned up {len(empty_sessions)} empty chat session(s)")
            
    except Exception as e:
        logger.error(f"Error during chat cleanup: {e}")

if __name__ == "__main__":
    cleanup_empty_chats()
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
