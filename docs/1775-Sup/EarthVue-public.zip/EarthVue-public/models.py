"""
MongoEngine Models for EARTH-VUE / Unified AI Framework

This module defines all MongoDB document models using MongoEngine ORM.
Models are organized by function: User & Auth, Chat Sessions, Analytics, AI Reasoning, etc.
"""

from mongoengine import (
    Document, StringField, IntField, FloatField, BooleanField,
    DateTimeField, ReferenceField, ListField, DictField, EmailField,
    NotUniqueError, ValidationError
)
from datetime import datetime
import json


# ────────────────────────────────────────────────────────────────────────────
# ── User & Authentication Models ──────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class User(Document):
    """User account model for authentication and profile management"""
    # MongoEngine automatically creates an 'id' property that references '_id'
    name = StringField(required=True, max_length=120)
    username = StringField(required=True, unique=True, max_length=80)
    email = EmailField(required=True, unique=True)
    password_hash = StringField(required=True, max_length=256)
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'users',
        'indexes': ['username', 'email']
    }
    
    def __repr__(self):
        return f"<User {self.username}>"


# ────────────────────────────────────────────────────────────────────────────
# ── Chat Session Models ───────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class ChatSession(Document):
    """User chat session records"""
    session_uuid = StringField(required=True, unique=True, max_length=36)
    user_id = StringField(required=True)  # References User.id (ObjectId as string)
    title = StringField(max_length=255, default="New Chat")
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)
    
    # Collaborative features
    is_shared = BooleanField(default=False)
    shared_with = ListField(StringField())  # List of user IDs who have access
    shared_by = StringField()  # User ID who shared the session
    workspace_id = StringField()  # Optional workspace ID
    
    meta = {
        'collection': 'chat_sessions',
        'indexes': ['session_uuid', 'user_id', 'workspace_id', 'is_shared']
    }
    
    def __repr__(self):
        return f"<ChatSession {self.session_uuid}>"


class ChatMessage(Document):
    """Individual chat messages within sessions"""
    session_uuid = StringField(required=True, max_length=36)
    role = StringField(required=True, choices=['system', 'user', 'assistant'], max_length=20)
    content = StringField(required=True)
    timestamp = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'chat_messages',
        'indexes': [
            'session_uuid',
            ('session_uuid', 'timestamp')
        ]
    }
    
    def __repr__(self):
        return f"<ChatMessage {self.role} in {self.session_uuid}>"


# ────────────────────────────────────────────────────────────────────────────
# ── Accessibility Analytics Models ────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class DataAccessEvent(Document):
    """Track user data access patterns for accessibility research"""
    user_id = StringField(required=True)
    session_uuid = StringField(required=True, max_length=36)
    timestamp = DateTimeField(required=True, default=datetime.now)
    query_text = StringField(required=True)
    datasets_mentioned = StringField()  # JSON array of datasets
    model_used = StringField(max_length=255)
    success_score = FloatField()  # 0-1 score of user success
    time_to_insight = FloatField()  # seconds from query to successful result
    complexity_level = IntField()  # 1-5 scale
    accessibility_barriers = StringField()  # JSON array of identified barriers
    
    meta = {
        'collection': 'data_access_events',
        'indexes': ['user_id', 'session_uuid', 'timestamp']
    }


class UserExpertiseProfile(Document):
    """User expertise and preferences profile"""
    user_id = StringField(required=True, unique=True)
    expertise_level = IntField(default=1)  # 1-5 scale
    preferred_datasets = StringField()  # JSON array
    successful_query_patterns = StringField()  # JSON array
    last_updated = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'user_expertise_profiles',
        'indexes': ['user_id']
    }


# ────────────────────────────────────────────────────────────────────────────
# ── User Datasets (uploaded, prompt-only for now) ─────────────────────────
# ────────────────────────────────────────────────────────────────────────────
class UserDataset(Document):
    """
    Per-user dataset registry backed by local filesystem storage.

    For Phase 1, this is "prompt-only" grounding: we store the user-provided
    system prompt and uploaded files locally, but we do not index uploaded
    content into Azure Search (option B).
    """

    user_id = StringField(required=True)  # Stringified ObjectId from User.id
    dataset_key = StringField(required=True, max_length=120)  # URL-safe slug
    display_label = StringField(required=True, max_length=255)
    system_prompt = StringField()  # user-provided extra instructions about the dataset

    # Optional structured access details (Phase 1: prompt-only grounding)
    # These help the assistant generate the correct data-loading code.
    access_type = StringField()  # e.g. OpenVisus, intake, OpenVisusPy, HTTP, etc.
    access_url = StringField()   # remote dataset URL / signed URL
    variables_text = StringField()  # free-form text listing variables/fields
    read_instructions = StringField()  # instructions/pseudocode about how to read
    minimal_read_code = StringField()  # optional: minimal snippet to use as starting point

    # Optional: format hint for the underlying primary dataset files.
    # Used to steer code generation/read patterns (prompt-only for now).
    data_format = StringField()  # e.g. Netcdf (.nc,.nc4), HDF5 (.h5), IDX (.idx), Zarr (.zarr), JSON (.json)

    # JSON-encoded manifest of uploaded files in ./user_datasets/<dataset_key>/
    files_manifest = StringField()  # e.g. [{original_name, stored_name, size, mime}, ...]

    status = StringField(default="ready", max_length=50)  # ready / indexing / failed
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)

    meta = {
        'collection': 'user_datasets',
        'indexes': [
            'user_id',
            'dataset_key',
            {'fields': ['user_id', 'dataset_key'], 'unique': True},
        ],
    }

    def __repr__(self):
        return f"<UserDataset {self.dataset_key} for {self.user_id}>"


# ────────────────────────────────────────────────────────────────────────────
# ── Multimodal Comparison Models ──────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class MultimodalCompareHistory(Document):
    """History of multimodal model comparisons"""
    user_id = StringField()  # nullable for demo/anon
    session_id = StringField(max_length=36)  # for tracking anonymous users
    prompt = StringField(required=True)
    modelA = StringField(required=True, max_length=255)
    modelB = StringField(required=True, max_length=255)
    answerA = StringField()
    answerB = StringField()
    votes_a = IntField(default=0)
    votes_b = IntField(default=0)
    voter_votes = DictField(default=dict)  # key: user_id/session_id, value: "A" or "B"
    created_at = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'multimodal_compare_history',
        'indexes': ['user_id', 'session_id', 'created_at']
    }


# ────────────────────────────────────────────────────────────────────────────
# ── AI Reasoning & Uncertainty Models ─────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class AIReasoningTrace(Document):
    """Comprehensive AI reasoning trace for response generation"""
    session_uuid = StringField(required=True, max_length=36)
    user_id = StringField(required=True)
    timestamp = DateTimeField(required=True, default=datetime.now)
    user_query = StringField(required=True)
    assistant_response = StringField()  # full model reply for workflow / inspector

    # AI Decision Process
    reasoning_steps = StringField()  # JSON array of reasoning chain
    dataset_selection_logic = StringField()  # JSON explaining dataset choices
    confidence_scores = StringField()  # JSON of confidence for different aspects
    uncertainty_factors = StringField()  # JSON array of uncertainty sources
    
    # Provenance Information
    retrieved_documents = StringField()  # JSON array of RAG documents used
    model_parameters = StringField()  # JSON of model settings used
    processing_time_ms = IntField()  # Response generation time
    
    # Quality Metrics
    response_coherence_score = FloatField()  # 0-1 coherence rating
    factual_accuracy_score = FloatField()  # 0-1 accuracy rating
    completeness_score = FloatField()  # 0-1 completeness rating
    dataset_appropriateness_score = FloatField() # 0-1 appropriateness rating
    bias_indicators = StringField()  # JSON array of detected biases

    # Optional lineage (keeps MongoEngine/schema in sync if DB has these keys or indexes)
    parent_trace_id = StringField(max_length=32)
    fork_step_index = IntField()
    branch_label = StringField(max_length=200)
    
    meta = {
        'collection': 'ai_reasoning_traces',
        'indexes': ['session_uuid', 'user_id', 'timestamp']
    }


class AIUncertaintyEvent(Document):
    """AI uncertainty events tracked for decision impact"""
    reasoning_trace_id = StringField(required=True)
    uncertainty_type = StringField(required=True, max_length=50)  # epistemic, aleatory, model, data
    uncertainty_source = StringField(required=True, max_length=100)
    confidence_level = FloatField(required=True)  # 0-1 confidence
    impact_assessment = StringField(max_length=20)  # low, medium, high impact
    mitigation_strategy = StringField()
    user_notified = BooleanField(default=False)
    
    meta = {
        'collection': 'ai_uncertainty_events',
        'indexes': ['reasoning_trace_id', 'uncertainty_type']
    }


class ReasoningFeedback(Document):
    """Human-in-the-loop feedback on AI reasoning quality for research analysis"""
    reasoning_trace_id = StringField(required=True)
    session_uuid = StringField(required=True, max_length=36)
    user_id = StringField(required=True)
    rating = StringField(required=True, choices=['correct', 'partial', 'problematic'], max_length=20)
    tags = StringField()  # JSON array of tag strings (e.g. ["lacks data source", "overconfident"])
    comment = StringField()  # Free-form user notes
    created_at = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'reasoning_feedback',
        'indexes': ['reasoning_trace_id', 'session_uuid', 'user_id', 'rating']
    }


# ────────────────────────────────────────────────────────────────────────────
# ── Accessibility Features Models ─────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class PlainLanguageSummary(Document):
    """Plain language summaries for accessibility"""
    reasoning_trace_id = StringField(required=True)
    beginner_summary = StringField(required=True)
    key_concepts = StringField()  # JSON array of key concepts explained
    data_meaning = StringField()
    created_at = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'plain_language_summaries',
        'indexes': ['reasoning_trace_id']
    }


class DataProvenance(Document):
    """Data provenance and quality information"""
    reasoning_trace_id = StringField(required=True)
    dataset_name = StringField(required=True, max_length=255)
    source_origin = StringField()
    last_updated = DateTimeField()
    confidence_level = FloatField()  # 0-1 confidence score
    data_quality_metrics = StringField()  # JSON of quality metrics
    usage_rights = StringField(max_length=255)
    created_at = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'data_provenance',
        'indexes': ['reasoning_trace_id']
    }


class ClimateGlossary(Document):
    """Climate science glossary for user education"""
    term = StringField(required=True, unique=True, max_length=255)
    definition = StringField(required=True)
    technical_definition = StringField()
    examples = StringField()  # JSON array of usage examples
    related_terms = StringField()  # JSON array of related terms
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'climate_glossary',
        'indexes': ['term']
    }


# ────────────────────────────────────────────────────────────────────────────
# ── Arena Debate Models ───────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class ArenaDebateHistory(Document):
    """Arena debate history between models"""
    user_id = StringField()  # nullable for demo/anon
    topic = StringField(required=True)
    modelA = StringField(required=True, max_length=255)
    modelB = StringField(required=True, max_length=255)
    debate_json = StringField(required=True)  # JSON array of debate turns
    created_at = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'arena_debate_history',
        'indexes': ['user_id', 'created_at']
    }


class Workspace(Document):
    """Team workspace for collaborative work"""
    name = StringField(required=True, max_length=255)
    description = StringField()
    owner_id = StringField(required=True)  # User ID of workspace owner
    members = ListField(StringField())  # List of user IDs
    member_emails = ListField(EmailField())  # List of member emails for easy lookup
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'workspaces',
        'indexes': ['owner_id', 'members', 'member_emails']
    }
    
    def __repr__(self):
        return f"<Workspace {self.name}>"


class TokenUsage(Document):
    """Token usage and cost tracking"""
    user_id = StringField(required=True)
    session_id = StringField(max_length=36)
    model = StringField(required=True, max_length=255)
    input_tokens = IntField(required=True)
    output_tokens = IntField(required=True)
    total_tokens = IntField(required=True)
    input_cost_usd = FloatField(required=True)
    output_cost_usd = FloatField(required=True)
    total_cost_usd = FloatField(required=True)
    timestamp = DateTimeField(required=True, default=datetime.now)
    
    meta = {
        'collection': 'token_usage',
        'indexes': ['user_id', 'session_id', 'timestamp', 'model']
    }
    
    def __repr__(self):
        return f"<TokenUsage user={self.user_id} tokens={self.total_tokens}>"


class SessionComment(Document):
    """Comments/annotations on chat sessions"""
    session_uuid = StringField(required=True, max_length=36)
    user_id = StringField(required=True)
    comment_text = StringField(required=True)
    message_index = IntField()  # Index of message being commented on (optional)
    created_at = DateTimeField(default=datetime.now)
    
    meta = {
        'collection': 'session_comments',
        'indexes': ['session_uuid', 'user_id', 'created_at']
    }
    
    def __repr__(self):
        return f"<SessionComment on {self.session_uuid}>"


# ────────────────────────────────────────────────────────────────────────────
# ── User Skill Models ───────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class UserSkill(Document):
    """Per-user skill profiles for ClimateAssistant (Phase 1: prompt-only skills)."""
    user_id = StringField(required=True)  # References User.id (ObjectId as string)
    name = StringField(required=True, max_length=120)
    description = StringField(max_length=500)
    instructions = StringField(required=True)  # Detailed system-style instructions
    activation_keywords = ListField(StringField(max_length=50))
    enabled_by_default = BooleanField(default=True)
    order = IntField(default=0)
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)

    meta = {
        'collection': 'user_skills',
        'indexes': ['user_id', 'order']
    }

    def __repr__(self):
        return f"<UserSkill {self.name} for {self.user_id}>"


# ────────────────────────────────────────────────────────────────────────────
# ── Knowledge Triple Curation Models ───────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────

class KnowledgeTriple(Document):
    """Auditable candidate/approved semantic triples extracted from chat traces."""

    user_id = StringField(required=True)  # Owner of this triple candidate
    session_uuid = StringField(max_length=36)
    reasoning_trace_id = StringField()

    subject_id = StringField(required=True, max_length=200)
    subject_label = StringField(required=True, max_length=255)
    subject_type = StringField(required=True, max_length=50)  # dataset|variable|model|scenario|concept

    predicate = StringField(required=True, max_length=120)

    object_id = StringField(required=True, max_length=200)
    object_label = StringField(required=True, max_length=255)
    object_type = StringField(required=True, max_length=50)

    confidence = FloatField(default=0.0)  # 0..1 extraction confidence
    extraction_method = StringField(default="heuristic_v1", max_length=80)
    extractor_version = StringField(default="triple-candidate-0.1", max_length=80)

    source_kind = StringField(default="response", max_length=40)  # query|response|retrieved_docs
    source_excerpt = StringField()  # short human-auditable excerpt
    source_payload = DictField(default=dict)  # full extraction context for audit

    status = StringField(default="candidate", max_length=20)  # candidate|approved|rejected
    reviewer_user_id = StringField()
    reviewer_note = StringField()
    reviewed_at = DateTimeField()

    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)

    meta = {
        'collection': 'knowledge_triples',
        'indexes': [
            'user_id',
            'session_uuid',
            'reasoning_trace_id',
            'status',
            ('user_id', 'status', 'created_at'),
            ('subject_id', 'predicate', 'object_id'),
        ]
    }

    def __repr__(self):
        return (
            f"<KnowledgeTriple {self.subject_id} -[{self.predicate}]-> "
            f"{self.object_id} ({self.status})>"
        )
