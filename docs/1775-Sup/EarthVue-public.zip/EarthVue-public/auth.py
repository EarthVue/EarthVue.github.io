from flask import Blueprint, render_template, request, redirect, url_for, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET','POST'])
def register():
    # Import MongoEngine User model
    from models import User
    if request.method == 'POST':
        name     = request.form['name'].strip()
        username = request.form['username'].strip()
        email    = request.form['email'].strip()
        pwd      = request.form['password']
        # validations
        if not all([name, username, email, pwd]):
            return render_template('register.html', error="All fields are required")
        if len(pwd) < 8:
            return render_template('register.html', error="Password must be at least 8 characters")
        if User.objects(username=username).first():
            return render_template('register.html', error="Username already taken")
        if User.objects(email=email).first():
            return render_template('register.html', error="Email already registered")
        # create user with MongoEngine
        user = User(
            name=name, username=username,
            email=email,
            password_hash=generate_password_hash(pwd)
        )
        user.save()
        # Auto-login after registration
        session['user_id'] = str(user.id)
        return redirect(url_for('landing'))
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET','POST'])
def login():
    from models import User
    import logging
    logger = logging.getLogger(__name__)
    
    # If already logged in, redirect to home
    if 'user_id' in session:
        logger.info(f"User already logged in: {session['user_id']}")
        return redirect(url_for('landing'))
    
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '')
        
        logger.info(f"Login attempt for username: {u}")
        
        if not u or not p:
            logger.warning("Empty username or password")
            return render_template('login.html', error="Username and password are required")
        
        try:
            user = User.objects(username=u).first()
            logger.info(f"User found: {user is not None}")
            
            if user and check_password_hash(user.password_hash, p):
                session['user_id'] = str(user.id)
                logger.info(f"Login successful for user: {u}, user_id: {session['user_id']}")
                return redirect(url_for('landing'))
            else:
                logger.warning(f"Invalid credentials for user: {u}")
                return render_template('login.html', error="Invalid credentials")
        except Exception as e:
            logger.error(f"Login error: {e}")
            return render_template('login.html', error="An error occurred. Please try again.")
    
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    from models import User
    import logging
    logger = logging.getLogger(__name__)
    
    # Check if user is logged in
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user = User.objects(id=session['user_id']).first()
    if not user:
        session.clear()
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'update_profile':
            name = request.form.get('name', '').strip()
            
            if not name:
                return render_template('profile.html', user=user, error="Name is required")
            
            user.name = name
            user.updated_at = datetime.now()
            user.save()
            
            return render_template('profile.html', user=user, success="Profile updated successfully!")
        
        elif action == 'update_password':
            new_pwd = request.form.get('new_password', '')
            confirm_pwd = request.form.get('confirm_password', '')
            
            if len(new_pwd) < 8:
                return render_template('profile.html', user=user, error="New password must be at least 8 characters")
            
            if new_pwd != confirm_pwd:
                return render_template('profile.html', user=user, error="New passwords do not match")
            
            user.password_hash = generate_password_hash(new_pwd)
            user.updated_at = datetime.now()
            user.save()
            
            return render_template('profile.html', user=user, success="Password updated successfully!")
    
    return render_template('profile.html', user=user)
