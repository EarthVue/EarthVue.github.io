# EarthVue

Flask web app for exploring downscaled climate datasets (e.g. NEX-GDDP-CMIP6) with chat, optional RAG over Azure AI Search, Azure OpenAI, and a sandboxed code-execution path for analysis and plots.

## Layout

| Path | Role |
|------|------|
| `app.py` | Flask app entry |
| `auth.py` | Auth blueprint |
| `models.py` | MongoEngine models |
| `routes/` | HTTP blueprints |
| `services/` | LLM, search, analytics, code execution |
| `templates/`, `static/` | UI |
| `earthvue_mcp/` | MCP server (`python -m earthvue_mcp.server`) |
| `cmip6_catalog.yml`, `data_registry.yml` | Data catalog metadata |
| `docs/docs.md` | Setup and environment variables |

## Quick start

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Set environment variables (at minimum `FLASK_SECRET_KEY`, `MONGODB_URI`, and your Azure/Mongo settings as needed). See [docs/setup.md](docs/setup.md).

```bash
export FLASK_APP=app.py
flask run --port 5000
```

## User uploads

Runtime uploads go under `user_datasets/` (ignored by git except `.gitkeep`). Do not commit private datasets.

## License

Add a `LICENSE` file when you publish.
