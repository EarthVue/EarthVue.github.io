# export_answer_notebook.py
import re
import nbformat as nbf
from flask import Blueprint, request, Response

export_bp = Blueprint('export_answer', __name__)

COMMON_DEPS = {
    'xarray':'xarray','xr':'xarray','numpy':'numpy','np':'numpy','pandas':'pandas','pd':'pandas',
    'matplotlib':'matplotlib','plt':'matplotlib','seaborn':'seaborn','cartopy':'cartopy',
    'geopandas':'geopandas','gpd':'geopandas','intake':'intake','intake_esm':'intake-esm',
    'zarr':'zarr','fsspec':'fsspec','s3fs':'s3fs','gcsfs':'gcsfs','dask':'dask[distributed]',
    'xesmf':'xesmf','netCDF4':'netCDF4','bottleneck':'bottleneck','cftime':'cftime',
    'plotly':'plotly','hvplot':'hvplot','holoviews':'holoviews'
}
IMPORT_RE = re.compile(r'\b(?:from|import)\s+([A-Za-z_][\w\.]*)')

def infer_libs(code_text: str):
    libs = set()
    for m in IMPORT_RE.findall(code_text or ''):
        libs.add(COMMON_DEPS.get(m.split('.')[0], ''))
    for alias, pkg in COMMON_DEPS.items():
        if alias and re.search(rf'\b{re.escape(alias)}\b', code_text or ''):
            libs.add(pkg)
    return sorted(x for x in libs if x)

def split_markdown_into_cells(md: str):
    """
    Returns a list like [('md', text), ('py', code), ...] in order.
    Only ```python/```py``` are treated as code; other fences go into markdown.
    """
    parts = []
    pos = 0
    for m in re.finditer(r"```(\w+)?\s*([\s\S]*?)```", md or "", flags=re.MULTILINE):
        start, end = m.span()
        lang = (m.group(1) or '').lower().strip()
        code = (m.group(2) or '').rstrip()
        if start > pos:
            parts.append(('md', md[pos:start]))
        if lang in ('python','py'):
            parts.append(('py', code))
        else:
            # keep non-python fences as markdown
            fenced = f"```{lang}\n{code}\n```"
            parts.append(('md', fenced))
        pos = end
    if pos < len(md or ''):
        parts.append(('md', md[pos:]))
    return parts

def make_notebook_from_answer(md: str, title: str):
    chunks = split_markdown_into_cells(md)
    # infer deps from all python chunks
    deps = infer_libs("\n\n".join(text for kind, text in chunks if kind=='py'))

    nb = nbf.v4.new_notebook()
    nb['metadata']['kernelspec'] = {'name':'python3','display_name':'Python 3'}
    cells = [ nbf.v4.new_markdown_cell(f"# {title or 'Exported Answer'}") ]

    if deps:
        pip_line = " ".join(sorted(set(deps)))
        cells.append(nbf.v4.new_code_cell(
            "import sys\nIN_COLAB = 'google.colab' in sys.modules\n"
            f"if IN_COLAB:\n    !pip -q install {pip_line}\n"
            "# If not in Colab, install the above packages in your environment."
        ))

    for kind, text in chunks:
        if kind == 'md':
            # strip leading/trailing blank lines for neatness
            cells.append(nbf.v4.new_markdown_cell(text.strip('\n')))
        else:
            cells.append(nbf.v4.new_code_cell(text))

    nb['cells'] = cells
    raw = nbf.writes(nb).encode('utf-8')
    return Response(raw, mimetype='application/x-ipynb+json',
                    headers={'Content-Disposition': 'attachment; filename=answer.ipynb'})

@export_bp.post('/export_answer_notebook')
def export_answer_notebook():
    data = request.get_json(force=True)
    md = data.get('markdown','')
    title = (data.get('title') or 'Exported Answer').strip()
    return make_notebook_from_answer(md, title)
