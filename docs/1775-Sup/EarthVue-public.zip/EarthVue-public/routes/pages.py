"""
Page routes blueprint - All routes that render HTML templates
"""
from flask import Blueprint, render_template, redirect, url_for, session, request
from models import User
import logging

logger = logging.getLogger(__name__)

pages_bp = Blueprint('pages', __name__)


def get_user_or_redirect():
    """Helper function to get current user or redirect to login"""
    if "user_id" not in session:
        return None, redirect(url_for("auth.login"))
    
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            logger.warning(f"User not found for session user_id: {session['user_id']}")
            session.clear()
            return None, redirect(url_for("auth.login"))
        return user, None
    except Exception as e:
        logger.error(f"Error loading user: {e}")
        session.clear()
        return None, redirect(url_for("auth.login"))


@pages_bp.get("/")
def landing():
    """Landing page - show mode selection if logged in, otherwise redirect to login"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("landing.html", user=user)


@pages_bp.get("/logout")
def logout():
    """Logout endpoint - clears session and redirects to login"""
    session.clear()
    return redirect(url_for("auth.login"))


@pages_bp.route("/chat")
def chat():
    """Main chat interface - requires authentication"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("index.html", current_user_name=user.name, user=user)


@pages_bp.get("/multimodal")
def multimodal():
    """Multimodal comparison interface - requires authentication"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("multimodal.html", user=user)


@pages_bp.get("/arena")
def arena():
    """AI Arena debate interface - requires authentication"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("arena.html", user=user)


@pages_bp.get("/accessibility")
def accessibility_dashboard():
    """Render the accessibility analytics dashboard"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("accessibility_dashboard.html", user=user)


@pages_bp.get("/reasoning")
def ai_reasoning_dashboard():
    """Render the AI reasoning and uncertainty visualization dashboard"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("ai_reasoning.html", user=user)


@pages_bp.get("/provenance-workflow")
def provenance_workflow():
    """Full-page interactive provenance workflow graph"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("provenance_workflow.html", user=user)


@pages_bp.get("/code-executor")
def code_executor():
    """Code executor page"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("code_executor.html", user=user)


@pages_bp.get("/help")
def help_page():
    """Help and documentation page"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("help.html", user=user)


@pages_bp.get("/knowledge-graph")
def knowledge_graph():
    """Knowledge graph visualization page"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("knowledge_graph.html", user=user)


@pages_bp.get("/usage")
def usage_dashboard():
    """Token usage and cost dashboard"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("usage_dashboard.html", user=user)


@pages_bp.get("/workspaces")
def workspaces_page():
    """Workspace management page"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("workspaces.html", user=user)


@pages_bp.get("/skills")
def skills_page():
    """User skills management page"""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("skills.html", user=user)


@pages_bp.get("/user-datasets/upload")
def upload_user_dataset_page():
    """Page to upload a private user dataset for chat grounding (Phase 1: local storage)."""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("upload_user_dataset.html", user=user)


@pages_bp.get("/user-datasets/manage")
def manage_user_datasets_page():
    """Page to manage (list + delete) private user datasets."""
    user, redirect_response = get_user_or_redirect()
    if redirect_response:
        return redirect_response
    return render_template("manage_user_datasets.html", user=user)


#
# Legacy /visualize page removed – visualization is now handled directly via chat/code execution flows.
