"""
Collaboration routes blueprint - Workspaces and session sharing
"""
import logging
from flask import Blueprint, request, jsonify, session

from models import User, ChatSession, Workspace, SessionComment
from services.error_handler import handle_api_errors, AppError, ValidationError as AppValidationError, UnauthorizedError, NotFoundError
from services.input_validator import validate_session_id, sanitize_string, validate_email
from routes.utils import get_user_or_abort

logger = logging.getLogger(__name__)

collaboration_bp = Blueprint('collaboration', __name__)


@collaboration_bp.route("/api/share_session", methods=["POST"])
@handle_api_errors
def share_session():
    """
    Share a chat session with other users
    ---
    tags:
      - Collaboration
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    user_ids = data.get("user_ids", [])
    
    if not isinstance(user_ids, list):
        raise AppValidationError("user_ids must be a list")
    
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # Add users to shared_with list
    current_shared = set(cs.shared_with or [])
    current_shared.update(user_ids)
    cs.shared_with = list(current_shared)
    cs.is_shared = True
    cs.shared_by = session["user_id"]
    cs.save()
    
    return jsonify({
        "success": True,
        "message": f"Session shared with {len(user_ids)} user(s)",
        "shared_with": cs.shared_with
    })


@collaboration_bp.route("/api/unshare_session", methods=["POST"])
@handle_api_errors
def unshare_session():
    """Unshare a chat session"""
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    cs.is_shared = False
    cs.shared_with = []
    cs.save()
    
    return jsonify({"success": True, "message": "Session unshared"})


@collaboration_bp.route("/api/shared_sessions", methods=["GET"])
@handle_api_errors
def get_shared_sessions():
    """Get sessions shared with current user"""
    user = get_user_or_abort()
    
    user_id = session["user_id"]
    
    # Get sessions shared with this user
    shared_sessions = ChatSession.objects(
        is_shared=True,
        shared_with=user_id
    ).order_by('-updated_at')
    
    result = []
    for cs in shared_sessions:
        result.append({
            "session_uuid": cs.session_uuid,
            "title": cs.title,
            "owner_id": cs.user_id,
            "shared_by": cs.shared_by,
            "last_modified": cs.updated_at.isoformat() if cs.updated_at else None
        })
    
    return jsonify({"sessions": result})


@collaboration_bp.route("/api/workspaces", methods=["GET", "POST"])
@handle_api_errors
def workspaces():
    """Get or create workspaces"""
    user = get_user_or_abort()
    
    user_id = session["user_id"]
    user_email = user.email.lower() if user and user.email else ""
    
    if request.method == "POST":
        # Create new workspace
        data = request.get_json(force=True)
        name = sanitize_string(data.get("name", ""), max_length=255)
        description = sanitize_string(data.get("description", ""), max_length=1000)
        
        if not name:
            raise AppValidationError("Workspace name is required")
        
        workspace = Workspace(
            name=name,
            description=description,
            owner_id=user_id,
            members=[user_id],  # Owner is automatically a member
            member_emails=[user_email]  # Owner's email
        )
        workspace.save()
        
        return jsonify({
            "success": True,
            "workspace_id": str(workspace.id),
            "workspace": {
                "id": str(workspace.id),
                "name": workspace.name,
                "description": workspace.description,
                "owner_id": workspace.owner_id,
                "members": workspace.members,
                "member_emails": workspace.member_emails
            }
        })
    
    # GET: List all workspaces (User requested to show all workspaces as options)
    workspaces_list = Workspace.objects().order_by('-updated_at')
    
    result = []
    for ws in workspaces_list:
        result.append({
            "id": str(ws.id),
            "name": ws.name,
            "description": ws.description,
            "owner_id": ws.owner_id,
            "members": ws.members or [],
            "member_emails": ws.member_emails or [],
            "created_at": ws.created_at.isoformat() if ws.created_at else None
        })
    
    return jsonify({"workspaces": result})


@collaboration_bp.route("/api/workspaces/<workspace_id>", methods=["DELETE"])
@handle_api_errors
def delete_workspace(workspace_id):
    """Delete a workspace"""
    user = get_user_or_abort()
    
    user_id = session["user_id"]
    workspace = Workspace.objects(id=workspace_id).first()
    
    if not workspace:
        raise NotFoundError("Workspace")
    
    # Only owner can delete
    if workspace.owner_id != user_id:
        raise UnauthorizedError("Only workspace owner can delete the workspace")
    
    workspace.delete()
    
    return jsonify({
        "success": True,
        "message": "Workspace deleted successfully"
    })


@collaboration_bp.route("/api/workspaces/<workspace_id>/members", methods=["POST", "DELETE"])
@handle_api_errors
def manage_workspace_members(workspace_id):
    """Add or remove workspace members by email"""
    user = get_user_or_abort()
    
    user_id = session["user_id"]
    workspace = Workspace.objects(id=workspace_id).first()
    
    if not workspace:
        raise NotFoundError("Workspace")
    
    # Check if user is owner
    if workspace.owner_id != user_id:
        raise UnauthorizedError("Only workspace owner can manage members")
    
    if request.method == "POST":
        # Add member by email
        data = request.get_json(force=True)
        member_email = data.get("email", "").strip().lower()
        
        if not member_email:
            raise AppValidationError("Email is required")
        
        # Validate email format
        try:
            member_email = validate_email(member_email)
        except AppValidationError as e:
            raise AppValidationError(f"Invalid email: {str(e)}")
        
        # Find user by email
        member_user = User.objects(email=member_email).first()
        member_user_id = str(member_user.id) if member_user else None
        
        # Add to member_emails if not already there
        if member_email not in (workspace.member_emails or []):
            if workspace.member_emails is None:
                workspace.member_emails = []
            workspace.member_emails.append(member_email)
        
        # Add to members if user exists
        if member_user_id and member_user_id not in (workspace.members or []):
            if workspace.members is None:
                workspace.members = []
            workspace.members.append(member_user_id)
        
        workspace.save()
        
        return jsonify({
            "success": True,
            "members": workspace.members or [],
            "member_emails": workspace.member_emails or [],
            "message": f"Added {member_email} to workspace"
        })
    else:
        # Remove member by email
        data = request.get_json(force=True)
        member_email = data.get("email", "").strip().lower()
        
        if not member_email:
            raise AppValidationError("Email is required")
        
        # Find user by email
        member_user = User.objects(email=member_email).first()
        member_user_id = str(member_user.id) if member_user else None
        
        # Remove from member_emails
        if workspace.member_emails and member_email in workspace.member_emails:
            workspace.member_emails.remove(member_email)
        
        # Remove from members if exists
        if member_user_id and workspace.members and member_user_id in workspace.members:
            if member_user_id != workspace.owner_id:  # Can't remove owner
                workspace.members.remove(member_user_id)
        
        workspace.save()
        
        return jsonify({
            "success": True,
            "members": workspace.members or [],
            "member_emails": workspace.member_emails or [],
            "message": f"Removed {member_email} from workspace"
        })


@collaboration_bp.route("/api/assign_session_to_workspace", methods=["POST"])
@handle_api_errors
def assign_session_to_workspace():
    """Assign a chat session to a workspace"""
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    session_id = validate_session_id(data.get("session_id", ""))
    workspace_id = data.get("workspace_id")
    
    if not workspace_id:
        raise AppValidationError("workspace_id is required")
    
    # Check if session exists and user owns it
    cs = ChatSession.objects(session_uuid=session_id, user_id=session["user_id"]).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # Check if workspace exists and user is a member
    workspace = Workspace.objects(id=workspace_id).first()
    if not workspace:
        raise NotFoundError("Workspace")
    
    user_id = session["user_id"]
    user_email = user.email.lower() if user and user.email else ""
    
    is_member = (
        workspace.owner_id == user_id or
        user_id in (workspace.members or []) or
        (user_email in (workspace.member_emails or []))
    )
    
    # We no longer strictly require membership since the user requested to see and use all workspaces as options
    
    # Assign session to workspace
    cs.workspace_id = workspace_id
    cs.save()
    
    return jsonify({
        "success": True,
        "message": "Session assigned to workspace",
        "workspace_id": workspace_id
    })


@collaboration_bp.route("/api/session_comments", methods=["GET", "POST"])
@handle_api_errors
def session_comments():
    """Get or create comments on a session"""
    user = get_user_or_abort()
    
    if request.method == "POST":
        # Create comment
        data = request.get_json(force=True)
        session_id = validate_session_id(data.get("session_id", ""))
        comment_text = sanitize_string(data.get("comment", ""), max_length=2000)
        
        if not comment_text:
            raise AppValidationError("Comment text is required")
        
        # Check if user has access to session
        cs = ChatSession.objects(session_uuid=session_id).first()
        if not cs:
            raise NotFoundError("Chat session")
        
        user_id = session["user_id"]
        user_email = user.email.lower()
        
        # Check access
        has_access = (
            cs.user_id == user_id or
            (cs.is_shared and user_id in (cs.shared_with or [])) or
            (cs.workspace_id and (
                cs.workspace_id in [ws.id for ws in Workspace.objects(
                    __raw__={
                        "$or": [
                            {"members": user_id},
                            {"member_emails": user_email}
                        ]
                    }
                )]
            ))
        )
        
        if not has_access:
            raise UnauthorizedError("You don't have access to this session")
        
        comment = SessionComment(
            session_uuid=session_id,
            user_id=user_id,
            comment=comment_text
        )
        comment.save()
        
        return jsonify({
            "success": True,
            "comment": {
                "id": str(comment.id),
                "comment": comment.comment,
                "user_id": comment.user_id,
                "created_at": comment.created_at.isoformat() if comment.created_at else None
            }
        })
    else:
        # GET: List comments for a session
        session_id = request.args.get("session_id")
        if not session_id:
            raise AppValidationError("session_id is required")
        
        session_id = validate_session_id(session_id)
        
        # Check access
        cs = ChatSession.objects(session_uuid=session_id).first()
        if not cs:
            raise NotFoundError("Chat session")
        
        user_id = session["user_id"]
        user_email = user.email.lower()
        
        has_access = (
            cs.user_id == user_id or
            (cs.is_shared and user_id in (cs.shared_with or [])) or
            (cs.workspace_id and (
                cs.workspace_id in [ws.id for ws in Workspace.objects(
                    __raw__={
                        "$or": [
                            {"members": user_id},
                            {"member_emails": user_email}
                        ]
                    }
                )]
            ))
        )
        
        if not has_access:
            raise UnauthorizedError("You don't have access to this session")
        
        comments = SessionComment.objects(session_uuid=session_id).order_by('created_at')
        
        result = []
        for comment in comments:
            result.append({
                "id": str(comment.id),
                "comment": comment.comment,
                "user_id": comment.user_id,
                "created_at": comment.created_at.isoformat() if comment.created_at else None
            })
        
        return jsonify({"comments": result})
