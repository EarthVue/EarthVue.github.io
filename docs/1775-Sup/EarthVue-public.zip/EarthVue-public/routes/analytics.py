"""
Analytics routes blueprint - Health checks and usage statistics
"""
import os
import logging
import json
import re
from datetime import datetime, timedelta
from collections import defaultdict
from flask import Blueprint, request, jsonify, session

from services.error_handler import handle_api_errors, AppError, UnauthorizedError
from routes.utils import get_user_or_abort
from models import AIReasoningTrace

logger = logging.getLogger(__name__)

analytics_bp = Blueprint('analytics', __name__)

# Configuration constants
ENDPOINT_URL = os.getenv("ENDPOINT_URL") or os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
SEARCH_ENDPOINT = os.getenv("SEARCH_ENDPOINT")
SEARCH_KEY = os.getenv("SEARCH_KEY")
SEARCH_INDEX_NAME = os.getenv("SEARCH_INDEX_NAME")


def _safe_json_loads(value, default):
    if value is None:
        return default
    if isinstance(value, (dict, list)):
        return value
    if isinstance(value, str):
        if not value.strip():
            return default
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return default
    return default


def _infer_intent(query_text):
    q = (query_text or "").lower()
    if any(k in q for k in ("plot", "chart", "figure", "visual", "heatmap", "map")):
        return "visualization"
    if any(k in q for k in ("uncertainty", "confidence", "error", "bias", "risk")):
        return "uncertainty"
    if any(k in q for k in ("compare", "difference", "versus", "vs", "trend")):
        return "comparison"
    if any(k in q for k in ("predict", "forecast", "projection", "future", "scenario")):
        return "projection"
    if any(k in q for k in ("why", "explain", "reason", "because", "interpret")):
        return "explanation"
    return "general"


def _extract_expected_facets(query_text):
    q = (query_text or "").lower()
    facets = []

    variable_patterns = (
        (r"\btemperature\b|\btemp\b", "variable:temperature"),
        (r"\bprecipitation\b|\brainfall\b|\bpr\b", "variable:precipitation"),
        (r"\bsea\s*level\b", "variable:sea_level"),
        (r"\bwind\b", "variable:wind"),
        (r"\bsalinity\b", "variable:salinity"),
        (r"\bco2\b|\bcarbon\b", "variable:co2"),
    )
    for pattern, label in variable_patterns:
        if re.search(pattern, q):
            facets.append(label)

    region_patterns = (
        (r"\bglobal\b|\bworld\b", "region:global"),
        (r"\barctic\b", "region:arctic"),
        (r"\bantarctic\b", "region:antarctic"),
        (r"\batlantic\b", "region:atlantic"),
        (r"\bpacific\b", "region:pacific"),
        (r"\beurope\b", "region:europe"),
        (r"\bnorth america\b", "region:north_america"),
        (r"\bafrica\b", "region:africa"),
        (r"\basia\b", "region:asia"),
    )
    for pattern, label in region_patterns:
        if re.search(pattern, q):
            facets.append(label)

    if re.search(r"\b(19|20)\d{2}\b", q):
        facets.append("time:year_specific")
    if any(k in q for k in ("historical", "past", "baseline")):
        facets.append("time:historical")
    if any(k in q for k in ("future", "projection", "forecast", "ssp")):
        facets.append("time:future")

    if any(k in q for k in ("ssp", "scenario", "rcp")):
        facets.append("scenario:explicit")

    return facets


def _source_from_doc(doc):
    md = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    for key in ("dataset_id", "dataset_name", "source", "index_name", "title"):
        value = md.get(key) if key != "title" else doc.get("title")
        if value is not None and str(value).strip():
            return str(value).strip()[:64]
    title = doc.get("title")
    if title:
        return str(title).strip()[:64]
    return "unknown_source"


def _doc_text_blob(doc):
    md = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    pieces = [
        str(doc.get("title") or ""),
        str(doc.get("content") or ""),
        str(doc.get("text") or ""),
        str(doc.get("snippet") or ""),
    ]
    for key in ("dataset_name", "dataset_id", "source", "region", "variable", "scenario"):
        if md.get(key) is not None:
            pieces.append(str(md.get(key)))
    return " ".join(pieces).lower()


def _facet_hit(expected_facet, text_blob):
    facet = expected_facet.lower()
    if facet.startswith("variable:"):
        name = facet.split(":", 1)[1]
        return name.replace("_", " ") in text_blob or name in text_blob
    if facet.startswith("region:"):
        name = facet.split(":", 1)[1]
        return name.replace("_", " ") in text_blob or name in text_blob
    if facet == "time:future":
        return any(k in text_blob for k in ("future", "projection", "ssp", "rcp"))
    if facet == "time:historical":
        return any(k in text_blob for k in ("historical", "baseline", "past"))
    if facet == "time:year_specific":
        return bool(re.search(r"\b(19|20)\d{2}\b", text_blob))
    if facet == "scenario:explicit":
        return any(k in text_blob for k in ("ssp", "rcp", "scenario"))
    return False

# Note: /health is served by app.py (HTML for browser, JSON for API)


@analytics_bp.route("/api/token_usage", methods=["GET"])
@handle_api_errors
def get_token_usage():
    """
    Get token usage statistics for current user
    ---
    tags:
      - Analytics
    """
    user = get_user_or_abort()
    
    days = request.args.get('days', 30, type=int)
    
    try:
        from services.token_counter import get_user_token_stats
        from models import TokenUsage
        
        stats = get_user_token_stats(session["user_id"], days=days)
        
        # Add daily breakdown for charts
        cutoff_date = datetime.now() - timedelta(days=days)
        usage_records = TokenUsage.objects(
            user_id=session["user_id"],
            timestamp__gte=cutoff_date
        ).order_by('timestamp')
        
        # Group by date
        daily_data = defaultdict(lambda: {'tokens': 0, 'cost': 0})
        for record in usage_records:
            date_key = record.timestamp.strftime('%Y-%m-%d')
            daily_data[date_key]['tokens'] += record.total_tokens
            daily_data[date_key]['cost'] += record.total_cost_usd
        
        stats['daily_breakdown'] = [
            {'date': date, 'tokens': data['tokens'], 'cost': data['cost']}
            for date, data in sorted(daily_data.items())
        ]
        
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting token usage: {e}")
        raise AppError("Failed to retrieve token usage statistics")


@analytics_bp.route("/api/token_usage/<session_id>", methods=["GET"])
@handle_api_errors
def get_session_token_usage(session_id):
    """
    Get token usage statistics for a specific session
    ---
    tags:
      - Analytics
    """
    user = get_user_or_abort()
    
    try:
        from models import TokenUsage
        
        # Get all token usage records for this session
        usage_records = TokenUsage.objects(
            user_id=session["user_id"],
            session_id=session_id
        ).order_by('timestamp')
        
        total_tokens = sum(record.total_tokens for record in usage_records)
        total_cost = sum(record.total_cost_usd for record in usage_records)
        total_requests = usage_records.count()
        
        return jsonify({
            'session_id': session_id,
            'total_tokens': total_tokens,
            'total_cost_usd': round(total_cost, 6),
            'total_requests': total_requests
        })
    except Exception as e:
        logger.error(f"Error getting session token usage: {e}")
        return jsonify({
            'session_id': session_id,
            'total_tokens': 0,
            'total_cost_usd': 0,
            'total_requests': 0
        })


@analytics_bp.route("/api/retrieval_coverage", methods=["GET"])
@handle_api_errors
def get_retrieval_coverage():
    """Get retrieval coverage matrix and blind-spot summary for current user."""
    user = get_user_or_abort()

    days = request.args.get("days", 30, type=int)
    cutoff_date = datetime.now() - timedelta(days=days)

    traces = AIReasoningTrace.objects(
        user_id=session["user_id"], timestamp__gte=cutoff_date
    ).order_by("-timestamp")

    if not traces:
        return jsonify(
            {
                "days": days,
                "trace_count": 0,
                "query_count": 0,
                "retrieval_doc_count": 0,
                "coverage_matrix": {
                    "intents": [],
                    "sources": [],
                    "values": [],
                },
                "blind_spots": [],
            }
        )

    matrix_counts = defaultdict(lambda: defaultdict(int))
    source_totals = defaultdict(int)
    trace_count = 0
    query_count = 0
    retrieval_doc_count = 0

    for trace in traces:
        trace_count += 1
        query = trace.user_query or ""
        if query.strip():
            query_count += 1
        intent = _infer_intent(query)

        docs = _safe_json_loads(trace.retrieved_documents, [])
        if not isinstance(docs, list):
            docs = []

        doc_blobs = []
        for raw in docs:
            if not isinstance(raw, dict):
                continue
            md = raw.get("metadata") if isinstance(raw.get("metadata"), dict) else {}
            provenance_kind = str(md.get("provenance_kind") or "")
            if provenance_kind and provenance_kind != "rag_chunk":
                continue
            source_id = _source_from_doc(raw)
            matrix_counts[intent][source_id] += 1
            source_totals[source_id] += 1
            retrieval_doc_count += 1
            doc_blobs.append(_doc_text_blob(raw))

    intents = sorted(matrix_counts.keys())
    sorted_sources = sorted(source_totals.items(), key=lambda item: item[1], reverse=True)
    top_sources = [name for name, _ in sorted_sources[:12]]

    values = []
    for intent in intents:
        row = [matrix_counts[intent].get(src, 0) for src in top_sources]
        values.append(row)

    return jsonify(
        {
            "days": days,
            "trace_count": trace_count,
            "query_count": query_count,
            "retrieval_doc_count": retrieval_doc_count,
            "coverage_matrix": {
                "intents": intents,
                "sources": top_sources,
                "values": values,
            },
        }
    )


