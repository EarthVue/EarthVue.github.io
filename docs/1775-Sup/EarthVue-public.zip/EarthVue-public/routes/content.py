"""
Content routes blueprint - Glossary, Plain Language Summary, Data Provenance
"""
import json
import logging
from datetime import datetime
from flask import Blueprint, request, jsonify, session

from models import (
    ClimateGlossary, PlainLanguageSummary, DataProvenance, AIReasoningTrace
)
from services.langchain_client import chat_non_streaming
from services.error_handler import handle_api_errors, AppError, UnauthorizedError, NotFoundError
from services.input_validator import sanitize_string
from routes.utils import get_user_or_abort

logger = logging.getLogger(__name__)

content_bp = Blueprint('content', __name__)


@content_bp.route("/api/plain_language_summary", methods=["POST"])
def plain_language_summary():
    """Generate beginner-friendly summary"""
    user = get_user_or_abort()
    
    try:
        data = request.get_json(force=True)
        reasoning_trace_id = data.get("reasoning_trace_id")
        
        if not reasoning_trace_id:
            return jsonify({"error": "Missing reasoning_trace_id"}), 400
        
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        summary = PlainLanguageSummary.objects(reasoning_trace_id=reasoning_trace_id).first()
        
        if summary:
            return jsonify({
                "beginner_summary": summary.beginner_summary,
                "key_concepts": json.loads(summary.key_concepts or "[]"),
                "data_meaning": summary.data_meaning
            })
        
        # Generate new summary
        summary_prompt = f"""
You are an expert at explaining climate data to beginners. 

Original question: {trace.user_query}

Create a beginner-friendly summary (2-3 sentences max) that:
1. Explains what data was analyzed in simple terms
2. Avoids jargon or explains technical terms
3. States the key finding clearly

Also provide 3-5 key concepts mentioned in simple terms.

Format your response as JSON with keys: 'beginner_summary', 'key_concepts' (list), 'data_meaning'
"""
        
        summary_text = chat_non_streaming(
            [{"role": "user", "content": summary_prompt}],
            temperature=0.3,
            max_tokens=300
        )
        
        try:
            summary_json = json.loads(summary_text)
        except json.JSONDecodeError:
            summary_json = {
                "beginner_summary": summary_text,
                "key_concepts": [],
                "data_meaning": "Unable to parse structured response"
            }
        
        new_summary = PlainLanguageSummary(
            reasoning_trace_id=reasoning_trace_id,
            beginner_summary=summary_json.get("beginner_summary", ""),
            key_concepts=json.dumps(summary_json.get("key_concepts", [])),
            data_meaning=summary_json.get("data_meaning", "")
        )
        new_summary.save()
        
        return jsonify(summary_json)
    
    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        return jsonify({"error": f"Failed to generate summary: {str(e)}"}), 500


@content_bp.route("/api/data_provenance/<reasoning_trace_id>", methods=["GET"])
def get_data_provenance(reasoning_trace_id):
    """Get provenance information"""
    user = get_user_or_abort()
    
    try:
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        provenance_records = list(DataProvenance.objects(reasoning_trace_id=reasoning_trace_id))
        
        result = [
            {
                "dataset_name": prov.dataset_name,
                "source_origin": prov.source_origin,
                "last_updated": prov.last_updated.isoformat() if prov.last_updated else None,
                "confidence_level": prov.confidence_level,
                "data_quality_metrics": json.loads(prov.data_quality_metrics or "{}"),
                "usage_rights": prov.usage_rights
            }
            for prov in provenance_records
        ]
        
        return jsonify({"provenance": result})
    except Exception as e:
        logger.error(f"Error getting provenance: {e}")
        return jsonify({'error': 'Failed to get provenance'}), 500


@content_bp.route("/api/add_provenance", methods=["POST"])
def add_provenance():
    """Add provenance information"""
    user = get_user_or_abort()
    
    try:
        data = request.get_json(force=True)
        reasoning_trace_id = data.get("reasoning_trace_id")
        
        if not reasoning_trace_id:
            return jsonify({"error": "Missing reasoning_trace_id"}), 400
        
        trace = AIReasoningTrace.objects(id=reasoning_trace_id).first()
        if not trace or trace.user_id != session["user_id"]:
            return jsonify({"error": "Unauthorized"}), 403
        
        prov = DataProvenance(
            reasoning_trace_id=reasoning_trace_id,
            dataset_name=data.get("dataset_name", ""),
            source_origin=data.get("source_origin", ""),
            last_updated=datetime.fromisoformat(data["last_updated"]) if data.get("last_updated") else None,
            confidence_level=float(data.get("confidence_level", 1.0)),
            data_quality_metrics=json.dumps(data.get("data_quality_metrics", {})),
            usage_rights=data.get("usage_rights", "")
        )
        prov.save()
        
        return jsonify({"id": str(prov.id), "message": "Provenance added successfully"})
    except Exception as e:
        logger.error(f"Error adding provenance: {e}")
        return jsonify({"error": str(e)}), 500


@content_bp.route("/api/glossary", methods=["GET"])
def get_glossary():
    """Get all glossary terms"""
    user = get_user_or_abort()
    
    try:
        terms = list(ClimateGlossary.objects())
        result = [
            {
                "id": str(term.id),
                "term": term.term,
                "definition": term.definition,
                "technical_definition": term.technical_definition,
                "examples": json.loads(term.examples or "[]"),
                "related_terms": json.loads(term.related_terms or "[]")
            }
            for term in terms
        ]
        
        return jsonify({"glossary": result})
    except Exception as e:
        logger.error(f"Error fetching glossary: {e}")
        return jsonify({'error': 'Failed to fetch glossary'}), 500


@content_bp.route("/api/glossary_term/<term>", methods=["GET"])
def get_glossary_term(term):
    """Get definition for a specific term"""
    user = get_user_or_abort()
    
    try:
        term_record = ClimateGlossary.objects(term=term.lower()).first()
        
        if not term_record:
            return jsonify({"error": "Term not found"}), 404
        
        return jsonify({
            "term": term_record.term,
            "definition": term_record.definition,
            "technical_definition": term_record.technical_definition,
            "examples": json.loads(term_record.examples or "[]"),
            "related_terms": json.loads(term_record.related_terms or "[]")
        })
    except Exception as e:
        logger.error(f"Error fetching glossary term: {e}")
        return jsonify({'error': 'Failed to fetch term'}), 500


@content_bp.route("/api/add_glossary_term", methods=["POST"])
def add_glossary_term():
    """Add new glossary term"""
    user = get_user_or_abort()
    
    try:
        data = request.get_json(force=True)
        
        existing = ClimateGlossary.objects(term=data.get("term", "").lower()).first()
        if existing:
            return jsonify({"error": "Term already exists"}), 409
        
        term_record = ClimateGlossary(
            term=data.get("term", "").lower(),
            definition=data.get("definition", ""),
            technical_definition=data.get("technical_definition", ""),
            examples=json.dumps(data.get("examples", [])),
            related_terms=json.dumps(data.get("related_terms", []))
        )
        term_record.save()
        
        return jsonify({
            "id": str(term_record.id),
            "message": "Glossary term added successfully"
        })
    except Exception as e:
        logger.error(f"Error adding glossary term: {e}")
        return jsonify({"error": str(e)}), 500
