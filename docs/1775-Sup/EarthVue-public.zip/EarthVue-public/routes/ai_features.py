"""
AI Features routes blueprint - Multimodal comparison, Arena, Reasoning, Knowledge Graph
"""
import os
import uuid
import json
import logging
from datetime import datetime, timedelta
from collections import defaultdict
from flask import Blueprint, request, jsonify, session, abort

from models import (
    MultimodalCompareHistory, ArenaDebateHistory, AIReasoningTrace,
    AIUncertaintyEvent, DataAccessEvent, ChatSession, DataProvenance,
    KnowledgeTriple,
)
from services.provenance_graph import build_provenance_graph
from services.session_reasoning_merge import (
    build_session_aggregate,
    build_reasoning_analysis_json,
    build_selected_trace_aggregate,
)
from services.langchain_client import chat_non_streaming
from services.error_handler import handle_api_errors, AppError, UnauthorizedError, NotFoundError
from routes.utils import SYSTEM_PROMPT, get_user_or_abort
from services.triple_curation import (
    extract_and_store_candidate_triples,
    evaluate_decision_impact,
    merge_legacy_triple_predicates,
)

logger = logging.getLogger(__name__)

ai_features_bp = Blueprint('ai_features', __name__)


@ai_features_bp.route('/api/compare', methods=['POST'])
def api_compare():
    """Compare a prompt between two selected models"""
    try:
        prompt = request.form.get('prompt') or request.form.get('question')
        model_a = request.form.get('modelA') or request.form.get('model_a')
        model_b = request.form.get('modelB') or request.form.get('model_b')

        if not prompt:
            return jsonify({'error': 'prompt is required'}), 400

        # Handle optional image upload
        image_info = None
        if 'image' in request.files:
            img = request.files['image']
            if img and img.filename:
                upload_dir = os.path.join(os.getcwd(), 'instance', 'uploads')
                os.makedirs(upload_dir, exist_ok=True)
                save_path = os.path.join(upload_dir, f"multimodal_{uuid.uuid4().hex}_{img.filename}")
                img.save(save_path)
                image_info = {'path': save_path, 'filename': img.filename}

        sys_prefix = SYSTEM_PROMPT
        if image_info:
            sys_prefix += f"\nNote: an image file was uploaded ({image_info['filename']}). Use it as contextual information if relevant."

        sys_msg = {'role': 'system', 'content': sys_prefix}
        user_msg = {'role': 'user', 'content': prompt}

        from time import perf_counter

        a_text, b_text = '', ''
        a_ms, b_ms = None, None

        try:
            t0 = perf_counter()
            a_text = chat_non_streaming([sys_msg, user_msg], deployment_name=model_a)
            a_ms = int((perf_counter() - t0) * 1000)
        except Exception as e:
            a_text = f"Error: {e}"
            a_ms = 0

        try:
            t0 = perf_counter()
            b_text = chat_non_streaming([sys_msg, user_msg], deployment_name=model_b)
            b_ms = int((perf_counter() - t0) * 1000)
        except Exception as e:
            b_text = f"Error: {e}"
            b_ms = 0

        return jsonify({'a': a_text, 'b': b_text, 'a_ms': a_ms, 'b_ms': b_ms})
    except Exception as e:
        logger.exception('Failed to run multimodal compare')
        return jsonify({'error': str(e)}), 500


@ai_features_bp.route('/api/compare_history', methods=['GET', 'POST'])
def compare_history():
    user_id = session.get('user_id')
    session_id = session.sid if hasattr(session, 'sid') else session.get('id')
    
    if request.method == 'POST':
        data = request.get_json(force=True)
        prompt = data.get('prompt', '').strip()
        modelA = data.get('modelA', '').strip()
        modelB = data.get('modelB', '').strip()
        answerA = data.get('answerA', '')
        answerB = data.get('answerB', '')
        
        if not prompt or not modelA or not modelB:
            return jsonify({'error': 'Missing required fields'}), 400
        
        try:
            entry = MultimodalCompareHistory(
                user_id=user_id if user_id else None,
                session_id=session_id if not user_id else None,
                prompt=prompt,
                modelA=modelA,
                modelB=modelB,
                answerA=answerA,
                answerB=answerB
            )
            entry.save()
            return jsonify({'ok': True, 'id': str(entry.id)})
        except Exception as e:
            logger.error(f"Error saving compare history: {e}")
            return jsonify({'error': 'Failed to save history'}), 500
    
    # GET: return history
    try:
        if user_id:
            items = MultimodalCompareHistory.objects(user_id=user_id).order_by('-created_at').limit(50)
        elif session_id:
            items = MultimodalCompareHistory.objects(session_id=session_id, user_id=None).order_by('-created_at').limit(50)
        else:
            return jsonify({'history': []})
        
        result = [
            {
                'id': str(h.id),
                'prompt': h.prompt,
                'modelA': h.modelA,
                'modelB': h.modelB,
                'answerA': h.answerA,
                'answerB': h.answerB,
                'votesA': getattr(h, 'votes_a', 0),
                'votesB': getattr(h, 'votes_b', 0),
                'created_at': h.created_at.isoformat()
            }
            for h in items
        ]
        return jsonify({'history': result})
    except Exception as e:
        logger.error(f"Error fetching compare history: {e}")
        return jsonify({'error': 'Failed to fetch history'}), 500


@ai_features_bp.route('/api/compare_history/<history_id>', methods=['DELETE'])
def delete_compare_history(history_id):
    user_id = session.get('user_id')
    session_id = session.sid if hasattr(session, 'sid') else session.get('id')
    
    try:
        from bson.objectid import ObjectId
        entry = MultimodalCompareHistory.objects(id=ObjectId(history_id)).first()
        
        if not entry:
            return jsonify({'error': 'Not found'}), 404
        
        # Verify ownership
        if user_id and entry.user_id != user_id:
            return jsonify({'error': 'Unauthorized'}), 403
        elif session_id and entry.session_id != session_id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        entry.delete()
        return jsonify({'deleted': True})
    except Exception as e:
        logger.error(f"Error deleting compare history: {e}")
        return jsonify({'error': 'Failed to delete'}), 500


@ai_features_bp.route('/api/compare_vote', methods=['POST'])
def compare_vote():
    """Record a user vote for a comparison entry"""
    try:
        data = request.get_json(force=True)
        history_id = data.get('history_id')
        vote = (data.get('vote') or '').upper()
        if vote not in ['A', 'B']:
            return jsonify({'error': 'vote must be "A" or "B"'}), 400

        voter = session.get('user_id') or (session.sid if hasattr(session, 'sid') else session.get('id'))
        if not voter:
            return jsonify({'error': 'Unauthorized'}), 401

        from bson.objectid import ObjectId
        entry = MultimodalCompareHistory.objects(id=ObjectId(history_id)).first()
        if not entry:
            return jsonify({'error': 'Not found'}), 404

        # Initialize fields if missing
        entry.votes_a = getattr(entry, 'votes_a', 0) or 0
        entry.votes_b = getattr(entry, 'votes_b', 0) or 0
        voter_votes = getattr(entry, 'voter_votes', {}) or {}

        previous = voter_votes.get(str(voter))
        # Undo previous vote if it exists
        if previous == 'A':
            entry.votes_a = max(0, entry.votes_a - 1)
        elif previous == 'B':
            entry.votes_b = max(0, entry.votes_b - 1)

        # Apply new vote
        if vote == 'A':
            entry.votes_a += 1
        else:
            entry.votes_b += 1

        voter_votes[str(voter)] = vote
        entry.voter_votes = voter_votes
        entry.save()

        return jsonify({
            'votesA': entry.votes_a,
            'votesB': entry.votes_b,
            'totalVotes': entry.votes_a + entry.votes_b,
            'vote': vote,
            'modelA': entry.modelA,
            'modelB': entry.modelB
        })
    except Exception as e:
        logger.error(f"Error recording vote: {e}")
        return jsonify({'error': 'Failed to record vote'}), 500


@ai_features_bp.route('/api/model_vote_stats', methods=['GET'])
def model_vote_stats():
    """Aggregate vote statistics across all comparisons"""
    try:
        totals = {}
        overall_votes = 0
        for item in MultimodalCompareHistory.objects():
            votes_a = getattr(item, 'votes_a', 0) or 0
            votes_b = getattr(item, 'votes_b', 0) or 0
            totals[item.modelA] = totals.get(item.modelA, 0) + votes_a
            totals[item.modelB] = totals.get(item.modelB, 0) + votes_b
            overall_votes += (votes_a + votes_b)

        top_model = None
        if totals:
            top_model = max(totals, key=lambda k: totals[k])

        sorted_totals = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)

        return jsonify({
            'totals': totals,
            'sorted_totals': sorted_totals,
            'top_model': top_model,
            'total_votes': overall_votes
        })
    except Exception as e:
        logger.error(f"Error aggregating model vote stats: {e}")
        return jsonify({'error': 'Failed to fetch stats'}), 500


@ai_features_bp.route('/api/compare_metrics', methods=['POST'])
def compare_metrics():
    """Optional endpoint for comparison metrics/analytics"""
    try:
        data = request.get_json(force=True)
        logger.info(f"Comparison metrics: {data}")
        return jsonify({'status': 'ok'})
    except Exception as e:
        logger.error(f"Error tracking metrics: {e}")
        return jsonify({'status': 'error'}), 500


@ai_features_bp.route('/api/arena_history', methods=['GET', 'POST'])
def arena_history():
    user_id = session.get('user_id')
    
    if request.method == 'POST':
        data = request.get_json(force=True)
        debate_id = data.get('id')
        topic = data.get('topic', '').strip()
        modelA = data.get('modelA', '').strip()
        modelB = data.get('modelB', '').strip()
        debate_json = json.dumps(data.get('debate', []))
        
        if not topic or not modelA or not modelB:
            return jsonify({'error': 'Missing required fields'}), 400
        
        try:
            if debate_id:
                from bson.objectid import ObjectId
                entry = ArenaDebateHistory.objects(id=ObjectId(debate_id)).first()
                if entry and (not user_id or entry.user_id == user_id):
                    entry.topic = topic
                    entry.modelA = modelA
                    entry.modelB = modelB
                    entry.debate_json = debate_json
                    entry.created_at = datetime.now()
                    entry.save()
                    return jsonify({'ok': True, 'id': str(entry.id), 'updated': True})
            
            # Create new debate
            entry = ArenaDebateHistory(
                user_id=user_id if user_id else None,
                topic=topic,
                modelA=modelA,
                modelB=modelB,
                debate_json=debate_json
            )
            entry.save()
            return jsonify({'ok': True, 'id': str(entry.id)})
        except Exception as e:
            logger.error(f"Error saving arena history: {e}")
            return jsonify({'error': 'Failed to save history'}), 500
    
    # GET: return all debates for user
    try:
        if user_id:
            items = ArenaDebateHistory.objects(user_id=user_id).order_by('-created_at').limit(50)
        else:
            items = ArenaDebateHistory.objects().order_by('-created_at').limit(50)
        
        result = [
            {
                'id': str(h.id),
                'topic': h.topic,
                'modelA': h.modelA,
                'modelB': h.modelB,
                'debate': json.loads(h.debate_json),
                'created_at': h.created_at.isoformat()
            }
            for h in items
        ]
        return jsonify({'history': result})
    except Exception as e:
        logger.error(f"Error fetching arena history: {e}")
        return jsonify({'error': 'Failed to fetch history'}), 500


@ai_features_bp.route('/api/arena_history/<history_id>', methods=['DELETE'])
def delete_arena_history(history_id):
    user_id = session.get('user_id')
    
    try:
        from bson.objectid import ObjectId
        entry = ArenaDebateHistory.objects(id=ObjectId(history_id)).first()
        
        if not entry:
            return jsonify({'error': 'Not found'}), 404
        
        if user_id and entry.user_id != user_id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        entry.delete()
        return jsonify({'deleted': True})
    except Exception as e:
        logger.error(f"Error deleting arena history: {e}")
        return jsonify({'error': 'Failed to delete'}), 500


# AI Reasoning routes - importing helper functions from app.py for now
@ai_features_bp.route("/api/reasoning_sessions")
def reasoning_sessions():
    """Get available reasoning sessions for analysis"""
    user = get_user_or_abort()
    
    try:
        user_id = session["user_id"]
        traces = AIReasoningTrace.objects(user_id=user_id).order_by('-timestamp').limit(200)
        
        # One reasoning overview per chat session (session_uuid), using the
        # most recent trace for each session, and enriched with the chat title.
        sessions = []
        seen_sessions = set()
        for trace in traces:
            sid = trace.session_uuid
            if sid in seen_sessions:
                continue
            seen_sessions.add(sid)
            
            cs = ChatSession.objects(session_uuid=sid, user_id=user_id).first()
            title = (cs.title if cs and cs.title else None) or "New Chat"
            
            sessions.append({
                'session_uuid': sid,
                'title': title,
                'timestamp': trace.timestamp.isoformat(),
                'user_query': (trace.user_query[:100] + '...') if len(trace.user_query) > 100 else trace.user_query,
                'processing_time_ms': trace.processing_time_ms,
                'overall_confidence': json.loads(trace.confidence_scores or '{}').get('overall', 0)
            })
        
        return jsonify(sessions)
    except Exception as e:
        logger.error(f"Error fetching reasoning sessions: {e}")
        return jsonify({'error': 'Failed to fetch sessions'}), 500


def _safe_json_loads(s, default):
    """Parse JSON string with fallback to default on error."""
    if not s:
        return default
    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        return default


@ai_features_bp.route("/api/reasoning_analysis/<session_id>")
def reasoning_analysis(session_id):
    """Get reasoning analysis merged across all turns in the chat session."""
    user = get_user_or_abort()

    try:
        user_id = session["user_id"]
        selected_trace_id = request.args.get("trace_id")
        _has, analysis_data = build_reasoning_analysis_json(
            session_id, user_id, selected_trace_id
        )
        return jsonify(analysis_data)
    except Exception as e:
        logger.exception("Error analyzing reasoning: %s", e)
        return jsonify({'error': 'Failed to analyze reasoning', 'has_trace': False}), 500


def _retrieved_docs_preview_payload(docs, limit: int = 25):
    """Light list for workflow UI; full graph still uses complete docs server-side."""
    if not isinstance(docs, list):
        return [], 0
    return docs[:limit], len(docs)


@ai_features_bp.route("/api/provenance_graph/<session_id>")
def provenance_graph(session_id):
    """Unified provenance DAG merged across all reasoning traces in the session."""
    user = get_user_or_abort()
    try:
        user_id = session["user_id"]
        selected_trace_id = request.args.get("trace_id")
        if selected_trace_id:
            selected = build_selected_trace_aggregate(
                session_id, user_id, selected_trace_id
            )
            if selected:
                payload = build_provenance_graph(
                    session_id=session_id,
                    trace_id=selected["trace_id"],
                    user_query=selected["user_query"],
                    retrieved_documents=selected["retrieved_documents"],
                    dataset_logic=selected["dataset_logic"],
                    reasoning_steps=selected["reasoning_steps"],
                    quality_scores=selected["quality_scores"],
                    uncertainties=selected["uncertainties"],
                    biases=selected["biases"],
                    data_provenance_rows=selected["data_provenance_rows"],
                    model_parameters=selected["model_parameters"],
                    processing_time_ms=int(selected["processing_time_ms"] or 0),
                    assistant_response=selected.get("assistant_response") or "",
                )
                payload["session_merged"] = True
                payload["selected_trace_mode"] = True
                payload["reasoning_trace_id"] = selected["trace_id"]
                payload["reasoning_trace_ids"] = selected["trace_ids"]
                payload["session_trace_count"] = selected["trace_count"]
                payload["total_turn_count"] = selected["total_turn_count"]
                payload["turn_options"] = selected.get("turn_options", [])
                payload["selected_turn"] = selected.get("selected_turn")
                payload["model_name"] = selected.get("model_name", "")
                prev, total = _retrieved_docs_preview_payload(
                    selected.get("retrieved_documents")
                )
                payload["retrieved_documents_preview"] = prev
                payload["retrieved_documents_total"] = total
                payload["assistant_response"] = selected.get("assistant_response") or ""
                return jsonify(payload)

        agg = build_session_aggregate(session_id, user_id)

        if not agg:
            payload = build_provenance_graph(
                session_id=session_id,
                trace_id=None,
                user_query="",
                retrieved_documents=[],
                dataset_logic={},
                reasoning_steps=[],
                quality_scores={},
                uncertainties=[],
                biases=[],
                data_provenance_rows=[],
                model_parameters={},
                processing_time_ms=0,
                assistant_response="",
            )
            payload["has_trace"] = False
            payload["session_merged"] = True
            payload["session_trace_count"] = 0
            payload["message"] = (
                "No reasoning data for this session. Reasoning is recorded when you send messages in chat."
            )
            payload["retrieved_documents_preview"] = []
            payload["retrieved_documents_total"] = 0
            return jsonify(payload)

        payload = build_provenance_graph(
            session_id=session_id,
            trace_id=agg["primary_trace_id"],
            user_query=agg["user_query"],
            retrieved_documents=agg["retrieved_documents"],
            dataset_logic=agg["dataset_logic"],
            reasoning_steps=agg["reasoning_steps"],
            quality_scores=agg["quality_scores"],
            uncertainties=agg["uncertainties"],
            biases=agg["biases"],
            data_provenance_rows=agg["data_provenance_rows"],
            model_parameters=agg["model_parameters"],
            processing_time_ms=int(agg["processing_time_ms"] or 0),
            assistant_response=agg.get("assistant_response") or "",
        )
        payload["session_merged"] = True
        payload["session_trace_count"] = agg["trace_count"]
        payload["total_turn_count"] = agg.get(
            "total_turn_count", agg["trace_count"]
        )
        payload["reasoning_trace_ids"] = agg["trace_ids"]
        payload["turn_options"] = agg.get("turn_options", [])
        payload["selected_trace_mode"] = False
        payload["session_summary"] = agg.get("session_summary")
        payload["provenance_summary"] = agg.get("provenance_summary")
        payload["reasoning_summary"] = agg.get("reasoning_summary")
        payload["model_name"] = agg.get("model_name", "")
        payload["uncertainty_total"] = agg.get("uncertainty_total")
        payload["uncertainty_shown"] = agg.get("uncertainty_shown")
        payload["bias_total"] = agg.get("bias_total")
        payload["bias_shown"] = agg.get("bias_shown")
        prev, total = _retrieved_docs_preview_payload(agg.get("retrieved_documents"))
        payload["retrieved_documents_preview"] = prev
        payload["retrieved_documents_total"] = total
        payload["assistant_response"] = agg.get("assistant_response") or ""
        return jsonify(payload)
    except Exception as e:
        logger.exception("Error building provenance graph: %s", e)
        return jsonify({"error": "Failed to build provenance graph", "has_trace": False}), 500


@ai_features_bp.route("/api/latest_reasoning")
def latest_reasoning():
    """Get the most recent reasoning trace"""
    user = get_user_or_abort()

    try:
        trace = AIReasoningTrace.objects().order_by("-timestamp").first()

        if not trace:
            return jsonify({"message": "No reasoning data available"})

        uncertainties = AIUncertaintyEvent.objects(reasoning_trace_id=trace.id)

        latest_data = {
            "timestamp": trace.timestamp.isoformat(),
            "reasoning_steps": json.loads(trace.reasoning_steps or "[]"),
            "dataset_logic": json.loads(trace.dataset_selection_logic or "{}"),
            "confidence_scores": json.loads(trace.confidence_scores or "{}"),
            "uncertainties": [
                {
                    "type": u.uncertainty_type,
                    "source": u.uncertainty_source,
                    "confidence": u.confidence_level,
                    "impact": u.impact_assessment,
                    "description": f"{u.uncertainty_type} uncertainty from {u.uncertainty_source}",
                    "mitigation": u.mitigation_strategy,
                }
                for u in uncertainties
            ],
            "provenance": json.loads(trace.retrieved_documents or "[]"),
            "biases": json.loads(trace.bias_indicators or "[]"),
        }

        return jsonify(latest_data)
    except Exception as e:
        logger.error(f"Error fetching latest reasoning: {e}")
        return jsonify({"error": "Failed to fetch reasoning"}), 500


@ai_features_bp.route("/api/reasoning_visualization/<session_id>")
@handle_api_errors
def enhanced_reasoning_visualization(session_id):
    """Get enhanced reasoning visualization data for a session"""
    user = get_user_or_abort()
    
    try:
        user_id = session["user_id"]
        trace = AIReasoningTrace.objects(session_uuid=session_id, user_id=user_id).order_by('-timestamp').first()
        
        if not trace:
            raise NotFoundError("Reasoning trace")
        
        # Parse JSON fields
        reasoning_steps = json.loads(trace.reasoning_steps or '[]')
        dataset_logic = json.loads(trace.dataset_selection_logic or '{}')
        confidence_scores = json.loads(trace.confidence_scores or '{}')
        uncertainties = json.loads(trace.uncertainty_factors or '[]')
        biases = json.loads(trace.bias_indicators or '[]')
        retrieved_docs = json.loads(trace.retrieved_documents or '[]')
        
        # Enhanced visualization data
        visualization_data = {
            'session_id': session_id,
            'timestamp': trace.timestamp.isoformat(),
            'user_query': trace.user_query,
            'reasoning_flow': {
                'steps': reasoning_steps,
                'total_steps': len(reasoning_steps),
            },
            'confidence_breakdown': {
                'overall': float(confidence_scores.get('overall', 0.0)),
                'coherence': float(confidence_scores.get('coherence', trace.response_coherence_score or 0.0)),
                'accuracy': float(confidence_scores.get('accuracy', trace.factual_accuracy_score or 0.0)),
                'completeness': float(confidence_scores.get('completeness', trace.completeness_score or 0.0)),
            },
            'dataset_selection': {
                'selected_datasets': dataset_logic.get('selected_datasets', []),
                'primary_factors': dataset_logic.get('primary_factors', []),
            },
            'uncertainty_analysis': {
                'uncertainties': uncertainties,
            },
            'bias_analysis': {
                'biases': biases,
            },
            'provenance': {
                'retrieved_documents': retrieved_docs,
                'document_count': len(retrieved_docs),
            },
            'performance': {
                'processing_time_ms': trace.processing_time_ms,
            }
        }
        
        return jsonify(visualization_data)
    except Exception as e:
        logger.error(f"Error generating enhanced visualization: {e}")
        raise AppError("Failed to generate enhanced visualization")


@ai_features_bp.route("/api/uncertainty_summary")
def uncertainty_summary():
    """Get aggregated uncertainty statistics"""
    user = get_user_or_abort()
    
    try:
        days = request.args.get('days', 30, type=int)
        cutoff_date = datetime.now() - timedelta(days=days)
        
        uncertainties = AIUncertaintyEvent.objects(
            reasoning_trace_id__in=[
                t.id for t in AIReasoningTrace.objects(timestamp__gte=cutoff_date)
            ]
        )
        
        uncertainty_by_type = {}
        for u in uncertainties:
            if u.uncertainty_type not in uncertainty_by_type:
                uncertainty_by_type[u.uncertainty_type] = {
                    'count': 0,
                    'avg_confidence': 0,
                    'impact_distribution': {'low': 0, 'medium': 0, 'high': 0}
                }
            
            uncertainty_by_type[u.uncertainty_type]['count'] += 1
            uncertainty_by_type[u.uncertainty_type]['avg_confidence'] += u.confidence_level
            if u.impact_assessment:
                uncertainty_by_type[u.uncertainty_type]['impact_distribution'][u.impact_assessment] += 1
        
        for utype, data in uncertainty_by_type.items():
            if data['count'] > 0:
                data['avg_confidence'] /= data['count']
        
        summary = {
            'total_uncertainty_events': len(list(uncertainties)),
            'uncertainty_by_type': uncertainty_by_type,
            'high_impact_events': len([u for u in uncertainties if u.impact_assessment == 'high']),
            'avg_system_confidence': sum(u.confidence_level for u in uncertainties) / max(len(list(uncertainties)), 1) if uncertainties else 0
        }
        
        return jsonify(summary)
    except Exception as e:
        logger.error(f"Error getting uncertainty summary: {e}")
        return jsonify({'error': 'Failed to get summary'}), 500


#
# NOTE:
# `/api/accessibility_metrics` is implemented in `app.py` with the full payload
# used by the accessibility dashboard (dataset popularity, model popularity, etc.).
# The earlier simplified duplicate endpoint here caused route collisions and
# resulted in the dashboard showing "no data" for most charts.


@ai_features_bp.route("/api/knowledge_graph/<graph_type>", methods=["GET"])
@handle_api_errors
def get_knowledge_graph(graph_type):
    """Get knowledge graph data"""
    user = get_user_or_abort()
    
    try:
        from services.knowledge_graph import get_graph_data
        user_id = session.get("user_id")
        graph_data = get_graph_data(graph_type, user_id)
        return jsonify(graph_data)
    except Exception as e:
        logger.error(f"Error generating knowledge graph: {e}")
        raise AppError(f"Failed to generate knowledge graph: {str(e)}")


@ai_features_bp.route("/api/kg/triples", methods=["GET"])
@handle_api_errors
def list_knowledge_triples():
    """List candidate/approved/rejected knowledge triples for curation."""
    _ = get_user_or_abort()
    user_id = str(session.get("user_id"))

    status = (request.args.get("status") or "").strip().lower()
    session_id = (request.args.get("session_id") or "").strip()
    limit = max(1, min(int(request.args.get("limit", 100)), 300))

    qs = KnowledgeTriple.objects(user_id=user_id)
    if status in {"candidate", "approved", "rejected"}:
        qs = qs.filter(status=status)
    if session_id:
        qs = qs.filter(session_uuid=session_id)

    items = []
    for t in qs.order_by("-updated_at")[:limit]:
        items.append(
            {
                "id": str(t.id),
                "session_uuid": t.session_uuid,
                "reasoning_trace_id": t.reasoning_trace_id,
                "subject": {
                    "id": t.subject_id,
                    "label": t.subject_label,
                    "type": t.subject_type,
                },
                "predicate": t.predicate,
                "object": {
                    "id": t.object_id,
                    "label": t.object_label,
                    "type": t.object_type,
                },
                "confidence": float(t.confidence or 0.0),
                "status": t.status,
                "source_kind": t.source_kind,
                "source_excerpt": t.source_excerpt,
                "reviewer_note": t.reviewer_note,
                "reviewed_at": t.reviewed_at.isoformat() if t.reviewed_at else None,
                "created_at": t.created_at.isoformat() if t.created_at else None,
                "updated_at": t.updated_at.isoformat() if t.updated_at else None,
            }
        )

    return jsonify({"items": items, "count": len(items)})


@ai_features_bp.route("/api/kg/triples/extract/<session_id>", methods=["POST"])
@handle_api_errors
def extract_knowledge_triples_for_session(session_id):
    """Extract candidate triples from latest (or selected) reasoning trace in session."""
    _ = get_user_or_abort()
    user_id = str(session.get("user_id"))

    trace_id = (request.args.get("trace_id") or "").strip()
    if trace_id:
        trace = AIReasoningTrace.objects(
            id=trace_id,
            session_uuid=session_id,
            user_id=user_id,
        ).first()
    else:
        trace = AIReasoningTrace.objects(
            session_uuid=session_id,
            user_id=user_id,
        ).order_by("-timestamp").first()

    if not trace:
        raise NotFoundError("Reasoning trace")

    result = extract_and_store_candidate_triples(
        user_id=user_id,
        session_uuid=session_id,
        reasoning_trace_id=str(trace.id),
        query_text=trace.user_query or "",
        response_text=trace.assistant_response or "",
    )
    return jsonify({
        "ok": True,
        "session_uuid": session_id,
        "reasoning_trace_id": str(trace.id),
        **result,
    })


@ai_features_bp.route("/api/kg/triples/<triple_id>/review", methods=["POST"])
@handle_api_errors
def review_knowledge_triple(triple_id):
    """Approve/reject a candidate triple for KG curation."""
    _ = get_user_or_abort()
    user_id = str(session.get("user_id"))

    triple = KnowledgeTriple.objects(id=triple_id, user_id=user_id).first()
    if not triple:
        raise NotFoundError("Knowledge triple")

    payload = request.get_json(silent=True) or {}
    new_status = (payload.get("status") or "").strip().lower()
    reviewer_note = (payload.get("reviewer_note") or "").strip()

    if new_status not in {"candidate", "approved", "rejected"}:
        raise AppError("status must be one of candidate, approved, rejected")

    triple.status = new_status
    triple.reviewer_user_id = user_id
    triple.reviewer_note = reviewer_note
    triple.reviewed_at = datetime.now()
    triple.updated_at = datetime.now()
    triple.save()

    return jsonify(
        {
            "ok": True,
            "id": str(triple.id),
            "status": triple.status,
            "reviewed_at": triple.reviewed_at.isoformat() if triple.reviewed_at else None,
        }
    )


@ai_features_bp.route("/api/kg/evaluate_decisions", methods=["GET"])
@handle_api_errors
def evaluate_kg_decision_impact():
    """Evaluate decision-quality proxy metrics for curated KG triples."""
    _ = get_user_or_abort()
    user_id = str(session.get("user_id"))
    days = request.args.get("days", 30, type=int)

    result = evaluate_decision_impact(user_id=user_id, days=days)
    return jsonify(result)


@ai_features_bp.route("/api/kg/triples/merge_legacy", methods=["POST"])
@handle_api_errors
def merge_kg_legacy_relations():
    """Canonicalize legacy predicate labels and merge duplicate triples."""
    _ = get_user_or_abort()
    user_id = str(session.get("user_id"))

    payload = request.get_json(silent=True) or {}
    dry_run = bool(payload.get("dry_run", True))

    result = merge_legacy_triple_predicates(user_id=user_id, dry_run=dry_run)
    return jsonify({"ok": True, **result})
