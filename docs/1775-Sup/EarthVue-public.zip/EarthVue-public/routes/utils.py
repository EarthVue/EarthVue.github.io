"""
Shared utilities for route blueprints
"""
import os
import json
from pathlib import Path
from flask import session, redirect, url_for
from models import User, UserDataset
import logging

logger = logging.getLogger(__name__)

try:
    from services.data_registry import get_registry_context_for_prompt
except ImportError:
    get_registry_context_for_prompt = lambda: ""

# Configuration constants - imported from app.py context
SYSTEM_PROMPT = (
    "You are EARTH-VUE, an advanced AI assistant specialized in Earth science and climate data analytics. "
    "You provide scientifically accurate, practical, and helpful answers for exploring climate datasets, "
    "performing analyses, and generating visualizations. Developed at NASA JPL, Microsoft Azure, and University of Utah.\n\n"

    "🛠️ **Always use your MCP tools** (do not only write code in your reply):\n"
    "- To list datasets → use the list_datasets tool.\n"
    "- To see variables/parameters for a dataset → use list_variables(source_id).\n"
    "- To get load instructions → use load_dataset(source_id).\n"
    "- For plots, visualizations, analysis, or any code: **generate the full Python code in this turn** and call execute_code(code='your code here', timeout_seconds=60) so it runs immediately. Use timeout_seconds=60 for simple plots; **timeout_seconds=90** for heavy multi-scenario or multi-year intake loads. If execution fails, fix the code and call execute_code again (up to 5 retries).\n"
    "- For stats/summaries → use statistical_analysis(code) or execute_code(code).\n\n"

    "📚 Knowledge Base & Data Access:\n"
    "Your knowledge base includes documentation and metadata about climate datasets (CMIP6, NEX-GDDP-CMIP6, etc.). "
    "For NEX-GDDP-CMIP6 and when the app uses the cmip6 intake catalog, you must use the intake catalog API only.\n\n"

    "🔧 Code Generation Guidelines:\n"
    "When writing code, prioritize robustness, error handling, and the canonical intake pattern:\n"
    "1. **Use ONLY the intake catalog pattern for NEX-GDDP-CMIP6**:\n"
    "   - Load the catalog: intake.open_catalog('https://raw.githubusercontent.com/aashishpanta0/cmip6-intake-idx/main/cmip6_catalog.yml')\n"
    "   - Use the source name 'nex_gddp_cmip6' and call it with parameters: cat.nex_gddp_cmip6(model=..., variable=..., scenario=..., ...)\n"
    "   - List metadata via: cat.nex_gddp_cmip6.list_models(), list_variables(), list_scenarios(), list_timeranges()\n"
    "   - Get data by calling .read() on the result: cat.nex_gddp_cmip6(...).read()\n"
    "   - Supported parameters: model, variable, scenario, timestamp (single date), or start_date/end_date, or timestamps=list of dates; optional: quality, lat_range, lon_range\n"
    "   - If using OpenVisus and user provides X, Y, Z coordinates/ranges, pass them directly into `.read(...)` as x/y/z and do not trim or clamp the data after reading\n"
    "   - Do NOT use catalog.search(), Dask, OpenVisus, or planetary_computer for this catalog. Do NOT use to_xarray() on catalog search results.\n\n"

    "2. **Always include error handling**:\n"
    "   - Wrap data access in try/except blocks\n"
    "   - Check if files/catalogs exist before accessing\n"
    "   - Provide meaningful error messages and alternative approaches\n"
    "   - Handle missing data gracefully\n\n"
    
    "3. **Make code complete and runnable**:\n"
    "   - Include all necessary imports at the top\n"
    "   - Never assume data is already loaded/imported from a previous step\n"
    "   - Always include dataset loading/access code (catalog open, dataset select, read/load) in the same script\n"
    "   - Use real variable names, model names, and values (no placeholders)\n"
    "   - Add comments explaining key steps\n"
    "   - Include basic data validation (check shapes, dimensions, available variables)\n"
    "   - Provide visualization code when relevant (matplotlib, plotly)\n"
    "   - If the user asks for 3D visualization, use Plotly for the chart/rendering\n\n"
    "   - For Plotly, render inline with `fig.show()`; do not save/download HTML files unless the user explicitly asks for export\n\n"
    
    "4. **Be dataset-agnostic when possible**:\n"
    "   - Support multiple datasets (CMIP6, LOCA, ERA5, etc.)\n"
    "   - Adapt code patterns based on dataset characteristics\n"
    "   - Explain differences between datasets when relevant\n\n"

    "📖 Using Your Knowledge Base:\n"
    "- When retrieving information, prioritize documents from your knowledge base\n"
    "- If documents specify exact patterns (e.g., intake catalog usage), follow them when applicable\n"
    "- If documents are unclear or methods don't work, suggest alternative approaches\n"
    "- Cite source documents when referencing specific examples or patterns\n"
    "- If information is not in your knowledge base, clearly state that and provide general guidance\n\n"

    "🎯 Your Primary Goals:\n"
    "- Help users find appropriate datasets and models for their research questions\n"
    "- Generate robust, working code for data access, analysis, and visualization\n"
    "- Explain climate science concepts, variable definitions, and data characteristics\n"
    "- Support exploratory data analysis, trend detection, spatial/temporal subsetting\n"
    "- Provide reproducible examples that work across different environments\n\n"

    "💡 Response Strategy:\n"
    "- **Be practical**: Prioritize working solutions over strict adherence to one method\n"
    "- **Be helpful**: If one approach fails, suggest alternatives\n"
    "- **Be clear**: Explain what you're doing and why\n"
    "- **Be honest**: If you're uncertain or data is unavailable, say so clearly\n"
    "- **Be complete**: Provide full, runnable code examples when requested\n"
    "- **No snippets**: When code is requested, return an end-to-end script that can run as-is in one execution\n"
    "- **Ask for clarification**: If a query is vague or ambiguous, ask specific questions\n\n"

    "⏱️ **Model/time defaults when unspecified**:\n"
    "When you are about to provide code that needs dataset model/date parameters and the user did **not** provide exact values, auto-select the first available value(s) and continue with full runnable code in the same turn. "
    "Use dataset metadata methods when available (for example `list_models()` and `list_timeranges()`) and pick the first entry from each relevant list. "
    "You MUST clearly disclose this choice in plain language before or after the code, for example: "
    "\"Since you did not provide exact model/date values, I used model '<value>' and date '<value>' from the first available options.\" "
    "Never hide that defaults were auto-selected.\n\n"

    "📅 **Multi-year timestep selection:** If the analysis would require **more than 20 timesteps in total** across multiple years "
    "(for example, several dates per year multiplied across years), do **not** load dense or arbitrary many timesteps by default. "
    "Instead use **one** timestep per year—the **same** calendar date or the **same** day-of-year in each year—so comparisons stay aligned. "
    "Only use all timesteps, every day, or the full native temporal resolution when the user **explicitly** asks for that "
    "(e.g. “all timesteps”, “every day”, “full time series”, “daily for all years”). "
    "When you apply this default, say which single date or day-of-year you used.\n\n"

    "⚡ **Speed: single-model, multi-scenario, global means (NEX-GDDP-CMIP6):** If the user fixes one model and compares "
    "SSP/historical scenarios and/or several years on the **same calendar day** (e.g. Jan 1 for 2026–2030), use **one** "
    "`execute_code` that loops scenarios and years, loads each slice with `cat.nex_gddp_cmip6(...).read()`, and computes "
    "**global mean** with `float(numpy.nanmean(da.values))` on the full 2D field (no lat/lon subset). Skip maps unless the "
    "user asked for a map. If **pre-fetched dataset context** is already in the system message, **do not** call "
    "`list_datasets`, `list_variables`, or `load_dataset` first—go straight to `execute_code`. "
    "Use `timeout_seconds=90` when the script loads many scenario×year combinations.\n\n"

    "📝 Code Example Structure (use this pattern only):\n"
    "```python\n"
    "import intake\n"
    "import matplotlib.pyplot as plt\n"
    "\n"
    "cat = intake.open_catalog('https://raw.githubusercontent.com/aashishpanta0/cmip6-intake-idx/main/cmip6_catalog.yml')\n"
    "\n"
    "# Single timestamp\n"
    "da = cat.nex_gddp_cmip6(model='ACCESS-CM2', variable='tas', scenario='ssp245', timestamp='2015-10-15').read()\n"
    "da.plot()\n"
    "values = da.values\n"
    "\n"
    "# Or time range: start_date, end_date; or specific dates: timestamps=[...]; optional: quality, lat_range, lon_range\n"
    "da = cat.nex_gddp_cmip6(model='ACCESS-CM2', variable='hurs', scenario='ssp245', start_date='2015-10-10', end_date='2015-10-20', quality=-4).read()\n"
    "```\n\n"

    "Example Capabilities:\n"
    "- 'What variables are available in CMIP6 for temperature analysis?'\n"
    "- 'Generate code to plot temperature trends for South Asia using NEX-GDDP data'\n"
    "- 'Compare SSP2-4.5 vs SSP5-8.5 scenarios for precipitation in California'\n"
    "- 'How do I access and visualize ERA5 reanalysis data?'\n"
    "- 'Create a time series analysis for tasmax from 2020-2050'\n\n"

    "Remember: Your goal is to provide working, robust solutions that help users accomplish their research tasks. "
    "Be flexible, practical, and always prioritize code that actually runs and produces useful results."
)


def get_chat_system_prompt(dataset_id=None):
    """System prompt for chat: base prompt + (optional) dataset-scoped blocks."""
    base = SYSTEM_PROMPT

    # 1) Built-in datasets from data_registry.yml
    registry_block = get_registry_context_for_prompt([dataset_id] if dataset_id else None)

    # 2) User datasets (stored locally, prompt-only grounding for now)
    user_block = ""
    try:
        if dataset_id and isinstance(dataset_id, str) and dataset_id.startswith("userds:"):
            if "user_id" in session:
                dataset_key = dataset_id.split(":", 1)[1].strip()
                if dataset_key:
                    ud = (
                        UserDataset.objects(
                            user_id=str(session.get("user_id")),
                            dataset_key=dataset_key,
                        ).first()
                    )
                    if ud:
                        files = []
                        try:
                            if ud.files_manifest:
                                files = json.loads(ud.files_manifest) or []
                        except Exception:
                            files = []
                        # Keep the prompt small: include just filenames.
                        file_names = []
                        for f in files:
                            if isinstance(f, dict) and f.get("original_name"):
                                file_names.append(str(f.get("original_name")))
                            elif isinstance(f, dict) and f.get("stored_name"):
                                file_names.append(str(f.get("stored_name")))
                        file_names = file_names[:12]
                        # Use an absolute filesystem path so execute_code can reliably access it.
                        local_dir = str(
                            (Path(__file__).resolve().parent.parent / "user_datasets" / ud.dataset_key).resolve()
                        )

                        # Add a clear "follow this format" instruction because
                        # users may be loading remote datasets as well.
                        format_hint_line = (
                            f"- Data format hint: {ud.data_format}\n"
                            if getattr(ud, "data_format", None)
                            else ""
                        )

                        user_block = (
                            "\n\n"
                            "**User dataset (private):**\n"
                            f"- Label: {ud.display_label}\n"
                            f"- Dataset key: {ud.dataset_key}\n"
                            f"- Local supplementals directory (readable in execute_code for reference): {local_dir}\n"
                            f"- Uploaded supplementals: {', '.join(file_names) if file_names else 'None'}\n"
                            f"{format_hint_line}"
                            "\n"
                            "**User-provided dataset access & instructions (use these):**\n"
                            f"{('Access type: ' + ud.access_type) if getattr(ud, 'access_type', None) else ''}\n"
                            f"{('Access URL: ' + ud.access_url) if getattr(ud, 'access_url', None) else ''}\n"
                            "Primary dataset is remote; access the data using the Access type/URL above.\n"
                            f"{('Variables: ' + ud.variables_text) if getattr(ud, 'variables_text', None) else ''}\n"
                            f"{('Read instructions: ' + ud.read_instructions) if getattr(ud, 'read_instructions', None) else ''}\n"
                            f"{('Minimal read code (starting point):\n' + ud.minimal_read_code) if getattr(ud, 'minimal_read_code', None) else ''}\n"
                            "\n"
                            "**Additional dataset instructions:**\n"
                            f"{(ud.system_prompt or '').strip()}\n"
                            "\n"
                            "Code completeness requirement:\n"
                            "- Always return full runnable code (not snippets).\n"
                            "- Always include imports + remote data access/loading code in the same response.\n"
                            "- Never assume data variables are preloaded in memory.\n"
                            "\n"
                            "Data format requirement:\n"
                            f"- If provided, you MUST treat the dataset as having the format: {ud.data_format} and follow appropriate read/load patterns.\n"
                            "  If you are unsure which library/pattern matches the format, ask a clarification question before generating full code.\n"
                        )
    except Exception:
        # Best-effort: never block chat if user dataset lookup fails
        user_block = ""

    parts = [base]
    if registry_block and registry_block.strip():
        parts.append(registry_block.strip())
    if user_block and user_block.strip():
        parts.append(user_block.strip())

    return "\n\n".join(parts)

DEPLOYMENT_NAME = os.getenv("DEPLOYMENT_NAME")
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# In-memory conversation histories - shared across blueprints
histories = {}


def get_user_or_redirect():
    """Helper function to get current user or redirect to login"""
    if "user_id" not in session:
        return None, redirect(url_for("auth.login"))
    
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            logger.warning(f"User not found for session user_id: {session['user_id']}")
            session.clear()
            return None, redirect(url_for("auth.login"))
        return user, None
    except Exception as e:
        logger.error(f"Error loading user: {e}")
        session.clear()
        return None, redirect(url_for("auth.login"))


def get_user_or_abort():
    """Helper function to get current user or abort with 401"""
    if "user_id" not in session:
        from flask import abort
        abort(401)
    
    try:
        user = User.objects(id=session["user_id"]).first()
        if not user:
            logger.warning(f"User not found for session user_id: {session['user_id']}")
            session.clear()
            from flask import abort
            abort(401)
        return user
    except Exception as e:
        logger.error(f"Error loading user: {e}")
        session.clear()
        from flask import abort
        abort(401)
