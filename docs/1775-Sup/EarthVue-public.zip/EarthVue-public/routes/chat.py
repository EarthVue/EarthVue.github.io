"""
Chat routes blueprint - Chat session management and messaging
"""
import os
import re
import uuid
import json
import threading
import logging
from datetime import datetime
from typing import Optional

from flask import Blueprint, request, jsonify, Response, stream_with_context, session, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from models import (
    User, ChatSession, ChatMessage, DataAccessEvent, AIReasoningTrace,
    AIUncertaintyEvent, PlainLanguageSummary, DataProvenance, UserExpertiseProfile,
    UserSkill,
)
from services.langchain_client import chat_stream, chat_stream_with_tools
from services.error_handler import handle_api_errors, AppError, ValidationError as AppValidationError, UnauthorizedError, NotFoundError
from services.input_validator import validate_query_text, validate_session_id
from services.analytics_service import (
    track_ai_reasoning,
    track_data_access_event,
    update_user_expertise,
)
from routes.utils import (
    get_chat_system_prompt,
    DEPLOYMENT_NAME,
    LOG_DIR,
    histories,
    get_user_or_abort,
)
from services.data_registry import (
    get_prefetched_dataset_context,
    resolve_source_id_from_query,
)
from services.provenance_graph import merge_tools_used_marker_into_provenance

logger = logging.getLogger(__name__)

chat_bp = Blueprint('chat', __name__)


def strip_sandbox_figure_markdown(text: Optional[str]) -> str:
    """Remove markdown image refs to sandbox plot paths; figures are shown via VIZ_IMAGES."""
    if not text:
        return ""
    out = re.sub(
        r"!\[[^\]]*\]\(\s*/mnt/data/[^)]+\)",
        "",
        text,
        flags=re.IGNORECASE,
    )
    out = re.sub(
        r"!\[[^\]]*\]\(\s*[^)]*mnt/data[^)]*\)",
        "",
        out,
        flags=re.IGNORECASE,
    )
    out = re.sub(r"\n{3,}", "\n\n", out)
    return out.strip()


def assistant_content_for_model(content: Optional[str]) -> str:
    """If assistant message was stored as visualization JSON, return prose only for LLM context."""
    if not content:
        return ""
    s = content.strip()
    if not s.startswith("{"):
        return content
    try:
        j = json.loads(s)
        if isinstance(j, dict) and j.get("type") == "visualization_answer":
            prose = j.get("prose")
            if prose is not None:
                return str(prose)
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return content


@chat_bp.route("/sessions")
def sessions():
    """Return user's chat sessions, including shared and workspace sessions"""
    user = get_user_or_abort()
    
    try:
        user_id = session["user_id"]
        user_email = user.email.lower() if user else None
        
        # Get user's own sessions
        own_sessions = ChatSession.objects(user_id=user_id).order_by('-updated_at')
        
        # Get sessions shared with this user
        shared_sessions = ChatSession.objects(
            is_shared=True,
            shared_with=user_id
        ).order_by('-updated_at')
        
        # Get workspace sessions (sessions in workspaces where user is a member)
        from models import Workspace
        workspace_ids = []
        if user_email:
            workspaces = Workspace.objects(
                __raw__={
                    "$or": [
                        {"members": user_id},
                        {"member_emails": user_email}
                    ]
                }
            )
            workspace_ids = [str(ws.id) for ws in workspaces]
        
        workspace_sessions = ChatSession.objects(
            workspace_id__in=workspace_ids
        ).order_by('-updated_at') if workspace_ids else []

        items = []
        seen_uuids = set()
        
        # Add own sessions
        for cs in own_sessions:
            msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
            if msg_count == 0:
                continue
            
            items.append({
                "session_uuid": cs.session_uuid,
                "title": cs.title or "New Chat",
                "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                "workspace_id": cs.workspace_id,
                "is_shared": cs.is_shared,
                "is_owner": True
            })
            seen_uuids.add(cs.session_uuid)
        
        # Add shared sessions
        for cs in shared_sessions:
            if cs.session_uuid not in seen_uuids:
                msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
                if msg_count > 0:
                    items.append({
                        "session_uuid": cs.session_uuid,
                        "title": cs.title or "New Chat",
                        "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                        "workspace_id": cs.workspace_id,
                        "is_shared": True,
                        "is_owner": False
                    })
                    seen_uuids.add(cs.session_uuid)
        
        # Add workspace sessions
        for cs in workspace_sessions:
            if cs.session_uuid not in seen_uuids:
                msg_count = ChatMessage.objects(session_uuid=cs.session_uuid, role__in=['user', 'assistant']).count()
                if msg_count > 0:
                    items.append({
                        "session_uuid": cs.session_uuid,
                        "title": cs.title or "New Chat",
                        "last_modified": cs.updated_at.isoformat() if cs.updated_at else None,
                        "workspace_id": cs.workspace_id,
                        "is_shared": False,
                        "is_owner": cs.user_id == user_id
                    })
                    seen_uuids.add(cs.session_uuid)

        return jsonify(items)
    except Exception as e:
        logger.error(f"Error fetching sessions: {e}")
        return jsonify({'error': 'Failed to fetch sessions'}), 500


@chat_bp.route("/load_chat/<sid>")
def load_chat(sid):
    """Load chat messages for a session"""
    user = get_user_or_abort()
    
    try:
        user_id = session["user_id"]
        user_email = user.email.lower() if user else None
        
        # Check if session exists
        cs = ChatSession.objects(session_uuid=sid).first()
        if not cs:
            abort(404)
        
        # Check access: user owns it, it's shared with them, or it's in a workspace they're a member of
        has_access = False
        
        # Check if user owns the session
        if cs.user_id == user_id:
            has_access = True
        
        # Check if session is shared with user
        if not has_access and cs.is_shared and user_id in (cs.shared_with or []):
            has_access = True
        
        # Check if session is in a workspace the user is a member of
        if not has_access and cs.workspace_id:
            from models import Workspace
            workspace = Workspace.objects(id=cs.workspace_id).first()
            if workspace:
                is_member = (
                    workspace.owner_id == user_id or
                    user_id in (workspace.members or []) or
                    (user_email and user_email in (workspace.member_emails or []))
                )
                if is_member:
                    has_access = True
        
        if not has_access:
            abort(403)  # Forbidden - user doesn't have access
        
        # Load messages from MongoDB
        messages = ChatMessage.objects(session_uuid=sid).order_by('timestamp')
        msg_list = [{"role": m.role, "content": m.content} for m in messages]
        
        # Fallback to JSON file if no messages in MongoDB
        if not msg_list:
            path = os.path.join(LOG_DIR, f"{sid}.json")
            if os.path.exists(path):
                with open(path) as f:
                    msg_list = json.load(f)
        
        return jsonify(msg_list)
    except Exception as e:
        logger.error(f"Error loading chat: {e}")
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException):
            raise
        abort(500)


@chat_bp.route("/new_chat", methods=["POST"])
def new_chat():
    """Create a new chat session"""
    user = get_user_or_abort()
    
    try:
        payload = request.get_json(silent=True) or {}
        dataset_id = payload.get("dataset_id")
        sid = str(uuid.uuid4())
        
        # Create ChatSession in MongoDB
        cs = ChatSession(session_uuid=sid, user_id=session["user_id"], title="New Chat")
        cs.save()
        
        # Store system message in MongoDB
        system_msg = ChatMessage(session_uuid=sid, role="system", content=get_chat_system_prompt(dataset_id))
        system_msg.save()
        
        # Keep in memory for this request
        histories[sid] = [{"role": "system", "content": get_chat_system_prompt(dataset_id)}]
        
        return jsonify({"session_id": sid})
    except Exception as e:
        logger.error(f"Error creating new chat: {e}")
        return jsonify({'error': 'Failed to create chat'}), 500


@chat_bp.route("/delete_chat/<sid>", methods=["DELETE"])
def delete_chat(sid):
    """Delete a chat session"""
    user = get_user_or_abort()
    
    try:
        cs = ChatSession.objects(session_uuid=sid, user_id=session["user_id"]).first()
        
        if cs:
            try:
                # Delete dependent records
                DataAccessEvent.objects(session_uuid=cs.session_uuid).delete()
                
                traces = list(AIReasoningTrace.objects(session_uuid=cs.session_uuid))
                trace_ids = [t.id for t in traces]
                
                if trace_ids:
                    AIUncertaintyEvent.objects(reasoning_trace_id__in=trace_ids).delete()
                    PlainLanguageSummary.objects(reasoning_trace_id__in=trace_ids).delete()
                    DataProvenance.objects(reasoning_trace_id__in=trace_ids).delete()
                    AIReasoningTrace.objects(id__in=trace_ids).delete()
                
                cs.delete()
            except Exception as e:
                logger.exception(f"Failed to delete chat session {sid}: {e}")
            
            # Clean up JSON file if exists
            path = os.path.join(LOG_DIR, f"{sid}.json")
            if os.path.exists(path):
                os.remove(path)
            
            # Remove from in-memory history
            histories.pop(sid, None)
            
            return jsonify({"message": "Chat deleted successfully"})
        else:
            return jsonify({"error": "Chat not found"}), 404
    except Exception as e:
        logger.error(f"Error deleting chat: {e}")
        return jsonify({'error': 'Failed to delete chat'}), 500


@chat_bp.route("/cleanup_empty_chats", methods=["POST"])
def cleanup_empty_chats_endpoint():
    """Clean up empty chat sessions"""
    user = get_user_or_abort()
    
    try:
        user_sessions = ChatSession.objects(user_id=session["user_id"])
        empty_sessions = []
        
        for cs in user_sessions:
            path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
            if os.path.exists(path):
                try:
                    with open(path) as f:
                        msgs = json.load(f)
                    conversation_msgs = [m for m in msgs if m.get("role") in ("user", "assistant")]
                    if not conversation_msgs:
                        empty_sessions.append(cs)
                except (json.JSONDecodeError, IOError):
                    empty_sessions.append(cs)
            else:
                empty_sessions.append(cs)
        
        for cs in empty_sessions:
            cs.delete()
            path = os.path.join(LOG_DIR, f"{cs.session_uuid}.json")
            if os.path.exists(path):
                os.remove(path)
            histories.pop(cs.session_uuid, None)
        
        return jsonify({"cleaned_up": len(empty_sessions), "message": f"Cleaned up {len(empty_sessions)} empty chat session(s)"})
    except Exception as e:
        logger.error(f"Error cleaning up chats: {e}")
        return jsonify({'error': 'Failed to cleanup chats'}), 500


@chat_bp.route("/suggest_title", methods=["POST"])
def suggest_title():
    """Generate a concise title suggestion summarizing the entire conversation"""
    user = get_user_or_abort()
    
    try:
        data = request.get_json(force=True)
        sid = data.get("session_id")
        
        if not sid:
            return jsonify({"error": "Bad request"}), 400
        
        # Get all messages in the conversation
        messages = list(ChatMessage.objects(session_uuid=sid).order_by('timestamp'))
        
        if not messages:
            return jsonify({"title": "New Chat"})
        
        # Build conversation summary for LLM (limit to last 20 messages for context)
        conversation_text = ""
        for msg in messages[-20:]:
            role = "User" if msg.role == "user" else "Assistant"
            content = msg.content[:200]  # Limit each message to 200 chars
            conversation_text += f"{role}: {content}\n"
        
        # Use LLM to generate a concise summary title (3-5 words)
        from services.langchain_client import chat_non_streaming
        
        prompt = f"""Based on this conversation, generate a concise title (3-5 words maximum) that summarizes the main topic or question discussed. Return only the title, nothing else.

Conversation:
{conversation_text}

Title:"""
        
        try:
            title = chat_non_streaming(
                [{"role": "user", "content": prompt}],
                deployment_name=DEPLOYMENT_NAME
            ).strip()
            
            # Clean up title - remove quotes, limit length
            title = title.replace('"', '').replace("'", "").strip()
            if len(title) > 60:
                title = title[:57] + "..."
            
            # Update session title
            cs = ChatSession.objects(session_uuid=sid).first()
            if cs:
                cs.title = title
                cs.save()
            
            return jsonify({"title": title})
        except Exception as llm_error:
            logger.warning(f"LLM title generation failed, using fallback: {llm_error}")
            # Fallback: use first user message
            first_msg = next((m for m in messages if m.role == "user"), None)
            if first_msg:
                title = first_msg.content[:50].strip()
                if len(first_msg.content) > 50:
                    title += "..."
                return jsonify({"title": title})
        
        return jsonify({"title": "New Chat"})
    except Exception as e:
        logger.error(f"Error suggesting title: {e}")
        return jsonify({"title": "New Chat"})


@chat_bp.route("/suggest_followups", methods=["POST"])
def suggest_followups():
    """Suggest follow-up questions based on conversation"""
    user = get_user_or_abort()
    
    try:
        data = request.get_json(force=True)
        sid = data.get("session_id")
        
        if not sid:
            return jsonify({"error": "Bad request"}), 400
        
        # Simple follow-up suggestions related to climate data
        suggestions = [
            "How can I access this dataset using Python?",
            "What's the spatial resolution of this data?",
            "Show me an example visualization",
            "What are the available variables?"
        ]
        
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        logger.error(f"Error suggesting followups: {e}")
        return jsonify({"suggestions": []})


@chat_bp.route("/chat", methods=["POST"])
@handle_api_errors
def chat_endpoint():
    """
    Main chat endpoint for user queries
    ---
    tags:
      - Chat
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - session_id
            - message
          properties:
            session_id:
              type: string
              description: Chat session UUID
            message:
              type: string
              description: User message/query
            model:
              type: string
              description: Optional model deployment name
    responses:
      200:
        description: Streaming response
      400:
        description: Bad request
      401:
        description: Unauthorized
      429:
        description: Rate limit exceeded
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    
    # Validate input
    try:
        sid = validate_session_id(data.get("session_id", ""))
        user_msg = validate_query_text(data.get("message", ""))
        model = data.get("model")  # Optional
        dataset_id = data.get("dataset_id")  # Optional dataset scope
    except AppValidationError as e:
        raise AppValidationError(str(e))
    
    if not sid or not user_msg:
        raise AppValidationError("session_id and message are required")
    
    # Check if user has access to this session
    user_id = session["user_id"]
    user_email = user.email.lower() if user else None
    
    cs = ChatSession.objects(session_uuid=sid).first()
    if not cs:
        raise NotFoundError("Chat session")
    
    # Check access: user owns it, it's shared with them, or it's in a workspace they're a member of
    has_access = False
    
    # Check if user owns the session
    if cs.user_id == user_id:
        has_access = True
    
    # Check if session is shared with user
    if not has_access and cs.is_shared and user_id in (cs.shared_with or []):
        has_access = True
    
    # Check if session is in a workspace the user is a member of
    if not has_access and cs.workspace_id:
        from models import Workspace
        workspace = Workspace.objects(id=cs.workspace_id).first()
        if workspace:
            is_member = (
                workspace.owner_id == user_id or
                user_id in (workspace.members or []) or
                (user_email and user_email in (workspace.member_emails or []))
            )
            if is_member:
                has_access = True
    
    if not has_access:
        raise UnauthorizedError("You don't have access to this session")

    # Load history from MongoDB or JSON fallback
    if sid not in histories:
        messages = ChatMessage.objects(session_uuid=sid).order_by('timestamp')
        if messages:
            histories[sid] = [
                {
                    "role": m.role,
                    "content": (
                        assistant_content_for_model(m.content)
                        if m.role == "assistant"
                        else m.content
                    ),
                }
                for m in messages
            ]
        else:
            path = os.path.join(LOG_DIR, f"{sid}.json")
            if os.path.exists(path):
                with open(path) as f:
                    histories[sid] = json.load(f)
            else:
                return jsonify({"error": "Bad request"}), 400

    query_start_time = datetime.now()
    
    # Save user message to MongoDB
    user_message = ChatMessage(session_uuid=sid, role="user", content=user_msg)
    user_message.save()
    
    histories[sid].append({"role": "user", "content": user_msg})

    # If a dataset scope is provided (or we can infer from query), set system prompt and
    # pre-inject dataset context so the agent skips list_datasets/list_variables/load_dataset.
    try:
        effective_dataset_id = dataset_id or resolve_source_id_from_query(user_msg)
        base_sys = get_chat_system_prompt(effective_dataset_id)
        if effective_dataset_id:
            prefetched = get_prefetched_dataset_context(effective_dataset_id)
            if prefetched:
                base_sys = base_sys + prefetched

        # Inject user skills into the system prompt.
        try:
            active_skill_ids = data.get("active_skill_ids", None)

            # If the client provides explicit active_skill_ids (including empty list),
            # it overrides the enabled_by_default selection.
            if active_skill_ids is not None:
                if not isinstance(active_skill_ids, list):
                    raise AppValidationError("active_skill_ids must be a list")
                # Normalize ids to strings and cap to avoid abuse.
                ids = [str(x) for x in active_skill_ids if x is not None]
                ids = ids[:50]
                active_skills = (
                    UserSkill.objects(user_id=str(user.id), id__in=ids)
                    .order_by("order", "created_at")
                )
            else:
                active_skills = (
                    UserSkill.objects(user_id=str(user.id), enabled_by_default=True)
                    .order_by("order", "created_at")
                )
        except AppValidationError:
            raise
        except Exception:
            active_skills = []

        if active_skills:
            skills_block_lines = [
                "",
                "The user has enabled the following personal skill profiles.",
                "You MUST integrate their instructions into your behavior when relevant.",
                "",
            ]
            for sk in active_skills:
                skills_block_lines.append(f"[User Skill: {sk.name}]")
                if sk.description:
                    skills_block_lines.append(f"Description: {sk.description}")
                skills_block_lines.append("Instructions:")
                skills_block_lines.append((sk.instructions or "").strip())
                skills_block_lines.append("")
            base_sys = base_sys + "\n" + "\n".join(skills_block_lines)

        if histories[sid] and histories[sid][0].get("role") == "system":
            histories[sid][0]["content"] = base_sys
        else:
            histories[sid].insert(0, {"role": "system", "content": base_sys})

        # Best-effort persist: update the earliest system message content.
        sys_msg = ChatMessage.objects(session_uuid=sid, role="system").order_by('timestamp').first()
        if sys_msg:
            sys_msg.content = base_sys
            sys_msg.save()
    except Exception:
        pass

    def generate():
        full = ""
        datasets_mentioned = []
        retrieved_docs = []

        try:
            # Stream chat response (with MCP-style tools: list_datasets, list_variables, load_dataset, execute_code, statistical_analysis)
            for chunk in chat_stream_with_tools(
                histories[sid],
                deployment_name=model,
                provenance_sink=retrieved_docs,
            ):
                if chunk:
                    full += chunk
                    yield chunk.encode("utf-8")
        except Exception as e:
            from services.error_handler import format_user_friendly_error, log_error_with_context
            log_error_with_context(e, user_id=session.get("user_id"), session_id=sid)
            error_msg = format_user_friendly_error(e)
            yield f"⚠️ Error: {error_msg}".encode("utf-8")
            return
        
        try:
            # Strip progress/tool markers from saved content (they are for live UX only; VIZ_IMAGES is huge base64)
            full_clean = re.sub(r'<!--PROGRESS:.*?-->', '', full, flags=re.DOTALL)
            full_clean = re.sub(r'<!--TOOLS_USED:[\s\S]*?-->', '', full_clean)
            full_clean = re.sub(r'<!--VIZ_IMAGES:[\s\S]*?-->', '', full_clean)
            full_clean = re.sub(r'<!--VIZ_PLOTLY_HTML:[\s\S]*?-->', '', full_clean)
            full_clean = re.sub(r'<!--LIVE_TOOL_CODE_B64:[\s\S]*?-->', '', full_clean)
            full_clean = strip_sandbox_figure_markdown(full_clean.strip())
            viz_match = re.search(r"<!--VIZ_IMAGES:([\s\S]*?)-->", full)
            viz_images = []
            if viz_match:
                try:
                    viz_images = json.loads(viz_match.group(1).strip())
                except json.JSONDecodeError:
                    viz_images = []
            if not isinstance(viz_images, list):
                viz_images = []
            plotly_match = re.search(r"<!--VIZ_PLOTLY_HTML:([\s\S]*?)-->", full)
            plotly_html = []
            if plotly_match:
                try:
                    plotly_html = json.loads(plotly_match.group(1).strip())
                except json.JSONDecodeError:
                    plotly_html = []
            if not isinstance(plotly_html, list):
                plotly_html = []
            stored_content = full_clean
            if viz_images or plotly_html:
                stored_content = json.dumps(
                    {
                        "type": "visualization_answer",
                        "prose": full_clean,
                        "images": viz_images,
                        "plotly_html": plotly_html,
                    },
                    ensure_ascii=False,
                )
            # Save assistant response to MongoDB (include viz images when present so reload keeps figures)
            assistant_message = ChatMessage(
                session_uuid=sid, role="assistant", content=stored_content
            )
            assistant_message.save()
            
            # Update session timestamp
            cs = ChatSession.objects(session_uuid=sid).first()
            if cs:
                cs.updated_at = datetime.now()
                cs.save()
            
            # Save to history
            histories[sid].append({"role": "assistant", "content": full_clean})
            
            # Track token usage and cost
            token_usage_data = None
            try:
                from services.token_counter import (
                    count_messages_tokens, estimate_cost, track_token_usage,
                    count_tokens as count_text_tokens
                )
                input_tokens = count_messages_tokens(histories[sid], model or DEPLOYMENT_NAME)
                output_tokens = count_text_tokens(full_clean, model or DEPLOYMENT_NAME)
                token_usage = track_token_usage(
                    user_id=session["user_id"],
                    session_id=sid,
                    model=model or DEPLOYMENT_NAME,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens
                )
                token_usage_data = {
                    'tokens': token_usage['total_tokens'],
                    'cost': token_usage['total_cost_usd']
                }
                logger.info(f"Token usage: {token_usage['total_tokens']} tokens, "
                          f"cost=${token_usage['total_cost_usd']:.6f}")
            except Exception as e:
                logger.warning(f"Token tracking failed: {e}")
            
            # Send token usage info to frontend as special marker
            if token_usage_data:
                yield f"\n\n<!--TOKEN_USAGE:{json.dumps(token_usage_data)}-->".encode("utf-8")
            
            # Background analytics processing (moves analytics work off the request thread)
            try:
                ENABLE_ANALYTICS = True
                if ENABLE_ANALYTICS:
                    processing_time_ms = int(
                        (datetime.now() - query_start_time).total_seconds() * 1000
                    )

                    # Prefer explicit dataset scope if provided by the UI (more reliable than text scanning)
                    if dataset_id:
                        datasets_mentioned = [dataset_id]
                    else:
                        # Fallback: lightweight scan of response text for legacy dataset keywords
                        climate_datasets = [
                            'cmip6', 'loca', 'cordex', 'nex-gddp', 'era5', 'daymet',
                            'nex_gddp_cmip6', 'llc2160_ocean', 'llc2160_geos_atmosphere', 'llc4320_ocean',
                        ]
                        datasets_mentioned = [
                            ds for ds in climate_datasets if ds.lower() in full_clean.lower()
                        ]

                    success_score = 0.0
                    if any(ind in full_clean for ind in ['import', 'def ', '.plot(', 'xarray', 'intake', 'dask']):
                        success_score += 0.4
                    if datasets_mentioned:
                        success_score += 0.3
                    if len(full_clean) > 200:
                        success_score += 0.15
                    if any(ind in full_clean.lower() for ind in ['step', 'follow', 'access', 'retrieve', 'download', 'query']):
                        success_score += 0.15

                    success_score = min(1.0, success_score)

                    def _background_post_processing(
                        user_id,
                        sid_local,
                        user_query_local,
                        response_text,
                        retr_docs,
                        proc_ms,
                        datasets,
                        success,
                        model_used=None,
                        conversation_hist=None,
                        raw_stream_for_provenance=None,
                    ):
                        trace_obj = None
                        try:
                            merged_docs = merge_tools_used_marker_into_provenance(
                                retr_docs, raw_stream_for_provenance or ""
                            )
                            trace_obj = track_ai_reasoning(
                                user_id=user_id,
                                session_uuid=sid_local,
                                user_query=user_query_local,
                                response_content=response_text,
                                retrieved_docs=merged_docs,
                                processing_time_ms=proc_ms,
                                conversation_history=conversation_hist,
                                model_name=model_used or DEPLOYMENT_NAME,
                            )
                        except Exception as e:
                            logger.exception(
                                f"Background: failed to track AI reasoning: {e}"
                            )

                        try:
                            from services.triple_curation import (
                                extract_and_store_candidate_triples,
                            )

                            extract_and_store_candidate_triples(
                                user_id=str(user_id),
                                session_uuid=sid_local,
                                reasoning_trace_id=(str(trace_obj.id) if trace_obj else None),
                                query_text=user_query_local,
                                response_text=response_text,
                            )
                        except Exception as e:
                            logger.exception(
                                f"Background: failed to extract knowledge triples: {e}"
                            )

                        try:
                            time_to_insight = (
                                datetime.now() - query_start_time
                            ).total_seconds()
                            event = track_data_access_event(
                                user_id=user_id,
                                session_uuid=sid_local,
                                query_text=user_query_local,
                                datasets_found=datasets,
                                success_score=success,
                                model=model_used,
                            )
                            if event:
                                event.time_to_insight = time_to_insight
                                event.save()
                        except Exception as e:
                            logger.exception(
                                f"Background: failed to track accessibility event: {e}"
                            )

                        try:
                            if success > 0.6 and datasets:
                                update_user_expertise(
                                    user_id, user_query_local, datasets[0]
                                )
                        except Exception as e:
                            logger.exception(
                                f"Background: failed to update user expertise: {e}"
                            )

                    try:
                        thread = threading.Thread(
                            target=_background_post_processing,
                            args=(
                                session["user_id"],
                                sid,
                                user_msg,
                                full_clean,
                                retrieved_docs,
                                processing_time_ms,
                                datasets_mentioned,
                                success_score,
                                model,
                                histories[sid],
                                full,
                            ),
                            daemon=True,
                        )
                        thread.start()
                    except Exception as e:
                        logger.exception(
                            f"Failed to start background analytics thread: {e}"
                        )
            except Exception as e:
                logger.exception(f"Analytics processing failed: {e}")
                
        except Exception as e:
            logger.error(f"Post-processing error: {e}")

    return Response(
        stream_with_context(generate()),
        content_type="text/plain; charset=utf-8",
        direct_passthrough=True
    )
