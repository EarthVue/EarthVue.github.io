"""
Tools routes blueprint - Code execution and query builder
"""
import logging
from flask import Blueprint, request, jsonify, session
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from services.error_handler import handle_api_errors, AppError, ValidationError as AppValidationError, UnauthorizedError
from services.input_validator import validate_query_text, sanitize_string
from routes.utils import get_user_or_abort

logger = logging.getLogger(__name__)

tools_bp = Blueprint('tools', __name__)


@tools_bp.route("/api/execute_code", methods=["POST"])
@handle_api_errors
def execute_code():
    """
    Execute Python code safely and return results
    ---
    tags:
      - Code Execution
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    code = data.get("code", "").strip()
    timeout = data.get("timeout", 30)
    
    if not code:
        raise AppValidationError("Code is required")
    
    if len(code) > 10000:
        raise AppValidationError("Code exceeds maximum length of 10000 characters")
    
    try:
        from services.code_executor import execute_code_safely
        
        result = execute_code_safely(code, timeout=timeout)
        
        return jsonify(result)
    except Exception as e:
        from services.error_handler import format_user_friendly_error, log_error_with_context
        log_error_with_context(e, user_id=session.get("user_id"))
        raise AppError(
            f"Code execution failed: {str(e)}",
            user_message=format_user_friendly_error(e)
        )


@tools_bp.route("/api/generate_visualization", methods=["POST"])
@handle_api_errors
def generate_visualization():
    """
    Generate visualization from Python code
    ---
    tags:
      - Code Execution
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    code = data.get("code", "").strip()
    output_format = data.get("output_format", "png")
    
    if not code:
        raise AppValidationError("Code is required")
    
    try:
        from services.code_executor import generate_visualization
        
        result = generate_visualization(code, output_format=output_format)
        return jsonify(result)
    except Exception as e:
        from services.error_handler import format_user_friendly_error, log_error_with_context
        log_error_with_context(e, user_id=session.get("user_id"))
        raise AppError(
            f"Visualization generation failed: {str(e)}",
            user_message=format_user_friendly_error(e)
        )


@tools_bp.route("/api/query_builder/suggest", methods=["POST"])
@handle_api_errors
def query_builder_suggest():
    """
    Get query suggestions based on partial input
    ---
    tags:
      - Query Builder
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    partial_query = sanitize_string(data.get("partial_query", ""), max_length=500)
    context = data.get("context", [])
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        suggestions = builder.generate_query_suggestions(partial_query, context)
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        logger.error(f"Query suggestion failed: {e}")
        raise AppError("Failed to generate query suggestions")


@tools_bp.route("/api/query_builder/structure", methods=["POST"])
@handle_api_errors
def query_builder_structure():
    """
    Convert natural language query to structured format
    ---
    tags:
      - Query Builder
    """
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    query = validate_query_text(data.get("query", ""))
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        structured = builder.suggest_query_structure(query)
        return jsonify(structured)
    except Exception as e:
        logger.error(f"Query structuring failed: {e}")
        raise AppError("Failed to structure query")


@tools_bp.route("/api/query_builder/templates", methods=["GET"])
@handle_api_errors
def query_builder_templates():
    """Get available query templates"""
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        templates = builder.get_query_templates()
        return jsonify({"templates": templates})
    except Exception as e:
        logger.error(f"Failed to get templates: {e}")
        raise AppError("Failed to retrieve query templates")


@tools_bp.route("/api/query_builder/validate", methods=["POST"])
@handle_api_errors
def query_builder_validate():
    """Validate a query and provide feedback"""
    user = get_user_or_abort()
    
    data = request.get_json(force=True)
    query = validate_query_text(data.get("query", ""))
    
    try:
        from services.query_builder import QueryBuilder
        builder = QueryBuilder()
        validation = builder.validate_query(query)
        return jsonify(validation)
    except Exception as e:
        logger.error(f"Query validation failed: {e}")
        raise AppError("Failed to validate query")


