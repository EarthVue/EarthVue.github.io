"""
Skills routes blueprint - Per-user skill management for ClimateAssistant.

Phase 1: prompt-only skills (no custom tools). Each skill is owned by a user
and is not shared across users.
"""

import logging
from datetime import datetime

from flask import Blueprint, request, jsonify

from models import UserSkill
from routes.utils import get_user_or_abort
from services.error_handler import handle_api_errors, AppError, ValidationError as AppValidationError


logger = logging.getLogger(__name__)

skills_bp = Blueprint("skills", __name__)


def _serialize_skill(skill: UserSkill) -> dict:
    """Serialize a UserSkill document to a JSON-safe dict."""
    return {
        "id": str(skill.id),
        "name": skill.name,
        "description": skill.description or "",
        "instructions": skill.instructions,
        "activation_keywords": skill.activation_keywords or [],
        "enabled_by_default": bool(skill.enabled_by_default),
        "order": skill.order or 0,
        "created_at": skill.created_at.isoformat() if skill.created_at else None,
        "updated_at": skill.updated_at.isoformat() if skill.updated_at else None,
    }


@skills_bp.route("/api/skills", methods=["GET"])
@handle_api_errors
def list_skills():
    """List all skills for the current user."""
    user = get_user_or_abort()
    skills = (
        UserSkill.objects(user_id=str(user.id))
        .order_by("order", "created_at")
    )
    return jsonify({"skills": [_serialize_skill(s) for s in skills]})


@skills_bp.route("/api/skills", methods=["POST"])
@handle_api_errors
def create_skill():
    """Create a new skill for the current user."""
    user = get_user_or_abort()
    data = request.get_json(force=True) or {}

    name = (data.get("name") or "").strip()
    instructions = (data.get("instructions") or "").strip()
    description = (data.get("description") or "").strip() or None
    activation_keywords = data.get("activation_keywords") or []
    enabled_by_default = bool(data.get("enabled_by_default", True))

    if not name:
        raise AppValidationError("Skill name is required")
    if not instructions:
        raise AppValidationError("Skill instructions are required")

    # Normalize keywords to strings and trim length
    clean_keywords = []
    for kw in activation_keywords:
        if not kw:
            continue
        kw_str = str(kw).strip()
        if kw_str:
            clean_keywords.append(kw_str[:50])

    # Determine order: append to the end
    existing_count = UserSkill.objects(user_id=str(user.id)).count()
    order = existing_count

    skill = UserSkill(
        user_id=str(user.id),
        name=name[:120],
        description=description[:500] if description else None,
        instructions=instructions,
        activation_keywords=clean_keywords,
        enabled_by_default=enabled_by_default,
        order=order,
    )
    skill.save()

    return jsonify({"skill": _serialize_skill(skill)}), 201


@skills_bp.route("/api/skills/<skill_id>", methods=["PUT"])
@handle_api_errors
def update_skill(skill_id):
    """Update an existing skill (only if owned by the current user)."""
    user = get_user_or_abort()
    skill = UserSkill.objects(id=skill_id, user_id=str(user.id)).first()
    if not skill:
        raise AppError("Skill not found", status_code=404)

    data = request.get_json(force=True) or {}

    if "name" in data:
        name = (data.get("name") or "").strip()
        if not name:
            raise AppValidationError("Skill name cannot be empty")
        skill.name = name[:120]

    if "description" in data:
        description = (data.get("description") or "").strip() or None
        skill.description = description[:500] if description else None

    if "instructions" in data:
        instructions = (data.get("instructions") or "").strip()
        if not instructions:
            raise AppValidationError("Skill instructions cannot be empty")
        skill.instructions = instructions

    if "activation_keywords" in data:
        activation_keywords = data.get("activation_keywords") or []
        clean_keywords = []
        for kw in activation_keywords:
            if not kw:
                continue
            kw_str = str(kw).strip()
            if kw_str:
                clean_keywords.append(kw_str[:50])
        skill.activation_keywords = clean_keywords

    if "enabled_by_default" in data:
        skill.enabled_by_default = bool(data.get("enabled_by_default"))

    if "order" in data and isinstance(data.get("order"), int):
        skill.order = int(data.get("order"))

    skill.updated_at = datetime.now()
    skill.save()

    return jsonify({"skill": _serialize_skill(skill)})


@skills_bp.route("/api/skills/<skill_id>", methods=["DELETE"])
@handle_api_errors
def delete_skill(skill_id):
    """Delete a skill owned by the current user."""
    user = get_user_or_abort()
    skill = UserSkill.objects(id=skill_id, user_id=str(user.id)).first()
    if not skill:
        raise AppError("Skill not found", status_code=404)

    skill.delete()
    return jsonify({"status": "ok"})


@skills_bp.route("/api/skills/reorder", methods=["POST"])
@handle_api_errors
def reorder_skills():
    """
    Update ordering for multiple skills.

    Body: { "order": [ { "id": "<skill_id>", "order": 0 }, ... ] }
    """
    user = get_user_or_abort()
    data = request.get_json(force=True) or {}
    items = data.get("order") or []

    if not isinstance(items, list):
        raise AppValidationError("order must be a list")

    # Build a mapping from id -> new_order
    order_map = {}
    for item in items:
        sid = item.get("id")
        ord_val = item.get("order")
        if not sid or not isinstance(ord_val, int):
            continue
        order_map[str(sid)] = int(ord_val)

    if not order_map:
        return jsonify({"status": "ok"})

    skills = UserSkill.objects(user_id=str(user.id), id__in=list(order_map.keys()))
    for s in skills:
        new_order = order_map.get(str(s.id))
        if new_order is not None:
            s.order = new_order
            s.updated_at = datetime.now()
            s.save()

    return jsonify({"status": "ok"})

