"""
User dataset routes:
- Upload supplemental documents + store per-user dataset prompt/access metadata.
- Expose dataset list for chat dropdown.

Phase 1 behavior (prompt-only grounding):
- The primary dataset is expected to be remote (accessed via the user-provided URL/instructions).
- Supplemental documents are stored locally under ./user_datasets/<dataset_key>/ for reference.
- We inject the user-provided access info + instructions into the chat system prompt.
- Do NOT index uploaded content into Azure Search (option B).
"""

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

from flask import Blueprint, request, jsonify

from models import User, UserDataset
from routes.utils import get_user_or_abort
from services.error_handler import handle_api_errors, AppError, ValidationError as AppValidationError
from services.input_validator import sanitize_file_upload, sanitize_string

user_datasets_bp = Blueprint("user_datasets", __name__)

DATASET_PREFIX = "userds:"

_BASE_DIR = Path(__file__).resolve().parent.parent / "user_datasets"
_ALLOWED_EXTENSIONS = {
    "pdf",
    "txt",
    "md",
    "docx",
    "doc",
}

MAX_SUPPLEMENTAL_FILES = 10


def _slugify_dataset_key(val: str) -> str:
    # Keep it URL/file safe and predictable.
    s = sanitize_string(val, max_length=120, allow_html=False).strip()
    s = s.lower().replace(" ", "-")
    s = re.sub(r"[^a-z0-9._-]", "", s)
    s = s.strip(".-_")
    if not s:
        raise AppValidationError("dataset_key is invalid")
    return s


def _user_dataset_dir(dataset_key: str) -> Path:
    # Important: dataset_key is already sanitized. Still, keep all paths under _BASE_DIR.
    d = _BASE_DIR / dataset_key
    resolved_base = _BASE_DIR.resolve()
    resolved_dir = d.resolve()
    if resolved_dir != resolved_base and resolved_base not in resolved_dir.parents:
        raise AppError("Invalid dataset path", status_code=400)
    return resolved_dir


def _dataset_id_from_key(dataset_key: str) -> str:
    return f"{DATASET_PREFIX}{dataset_key}"


def _serialize_builtin_dataset(source_id: str, meta: dict) -> dict:
    return {
        "id": source_id,
        "label": (meta.get("name") or source_id),
        "kind": "builtin",
    }


def _serialize_user_dataset(ud: UserDataset) -> dict:
    return {
        "id": _dataset_id_from_key(ud.dataset_key),
        "label": ud.display_label,
        "kind": "user",
        "dataset_key": ud.dataset_key,
    }


@user_datasets_bp.route("/api/chat_datasets", methods=["GET"])
@handle_api_errors
def list_chat_datasets():
    """Return built-in + current-user datasets for the chat dropdown."""
    user = get_user_or_abort()

    # Built-in datasets from data_registry.yml
    try:
        from services.data_registry import get_sources

        sources = get_sources() or {}
        builtins = [_serialize_builtin_dataset(sid, meta or {}) for sid, meta in sources.items()]
    except Exception:
        builtins = []

    # User datasets (private)
    user_datasets = UserDataset.objects(user_id=str(user.id)).order_by("-updated_at")
    users = [_serialize_user_dataset(ud) for ud in user_datasets]

    # Stable order: builtins first, then user datasets
    return jsonify({"datasets": builtins + users})


@user_datasets_bp.route("/api/user_datasets", methods=["POST"])
@handle_api_errors
def upload_user_dataset():
    """
    Upload a new per-user dataset.

    Expected multipart/form-data fields:
    - dataset_key (string, required)
    - display_label (string, required)
    - system_prompt (string, optional)
    - files (one or more files, optional but recommended)
    """
    user = get_user_or_abort()

    dataset_key_raw = request.form.get("dataset_key") or ""
    display_label_raw = request.form.get("display_label") or ""
    system_prompt_raw = request.form.get("system_prompt") or ""
    data_format_raw = request.form.get("data_format") or ""
    access_type_raw = request.form.get("access_type") or ""
    access_url_raw = request.form.get("access_url") or ""
    variables_text_raw = request.form.get("variables_text") or ""
    read_instructions_raw = request.form.get("read_instructions") or ""
    minimal_read_code_raw = request.form.get("minimal_read_code") or ""

    dataset_key = _slugify_dataset_key(dataset_key_raw)
    display_label = sanitize_string(display_label_raw, max_length=255, allow_html=False)

    if not display_label:
        raise AppValidationError("display_label is required")

    if not str(data_format_raw).strip():
        raise AppValidationError("data_format is required")
    if not str(access_type_raw).strip():
        raise AppValidationError("access_type is required")

    # allow_html=True: we do NOT want html escaping here because URLs and code snippets
    # contain characters like '&' and '<' that would otherwise be corrupted.
    system_prompt = sanitize_string(system_prompt_raw, max_length=8000, allow_html=True) if system_prompt_raw else ""
    data_format = sanitize_string(data_format_raw, max_length=120, allow_html=True) if data_format_raw else ""
    access_type = sanitize_string(access_type_raw, max_length=120, allow_html=True) if access_type_raw else ""
    access_url = sanitize_string(access_url_raw, max_length=2000, allow_html=True) if access_url_raw else ""
    variables_text = sanitize_string(variables_text_raw, max_length=8000, allow_html=True) if variables_text_raw else ""
    read_instructions = sanitize_string(read_instructions_raw, max_length=12000, allow_html=True) if read_instructions_raw else ""
    minimal_read_code = sanitize_string(minimal_read_code_raw, max_length=12000, allow_html=True) if minimal_read_code_raw else ""

    # Prepare filesystem storage
    os.makedirs(_BASE_DIR, exist_ok=True)
    dataset_dir = _user_dataset_dir(dataset_key)

    # Replace existing dataset contents for this key
    if dataset_dir.exists():
        shutil.rmtree(dataset_dir)
    dataset_dir.mkdir(parents=True, exist_ok=True)

    files_manifest = []

    # Grab uploaded supplemental files
    uploaded_files = request.files.getlist("files") if hasattr(request.files, "getlist") else []
    if not uploaded_files:
        uploaded_files = []
        # Some clients might send files under different names; try all files.
        for _, f in request.files.items():
            if f and getattr(f, "filename", None):
                uploaded_files.append(f)

    allowed_exts = sorted(_ALLOWED_EXTENSIONS)
    valid_uploaded_files = [
        f for f in (uploaded_files or []) if f and getattr(f, "filename", None)
    ]
    if len(valid_uploaded_files) > MAX_SUPPLEMENTAL_FILES:
        raise AppValidationError(f"Max {MAX_SUPPLEMENTAL_FILES} supplemental files per dataset.")

    for f in valid_uploaded_files:
        original_name = getattr(f, "filename", "") or ""
        if not original_name:
            continue
        safe_name = sanitize_file_upload(original_name, allowed_extensions=allowed_exts)

        # Ensure uniqueness on disk
        import uuid

        stored_name = f"{uuid.uuid4().hex}_{safe_name}"
        save_path = dataset_dir / stored_name
        f.save(str(save_path))

        files_manifest.append(
            {
                "original_name": original_name,
                "stored_name": stored_name,
                "size": int(getattr(save_path, "stat", lambda: None)().st_size) if save_path.exists() else None,
                "mime_type": getattr(f, "content_type", None),
            }
        )

    # Persist metadata in Mongo
    now = datetime.now()
    ud = UserDataset.objects(user_id=str(user.id), dataset_key=dataset_key).first()
    if not ud:
        ud = UserDataset(
            user_id=str(user.id),
            dataset_key=dataset_key,
            display_label=display_label,
            system_prompt=system_prompt,
            data_format=data_format or None,
            access_type=access_type or None,
            access_url=access_url or None,
            variables_text=variables_text or None,
            read_instructions=read_instructions or None,
            minimal_read_code=minimal_read_code or None,
            files_manifest=json.dumps(files_manifest),
            status="ready",
            created_at=now,
            updated_at=now,
        )
    else:
        ud.display_label = display_label
        ud.system_prompt = system_prompt
        ud.data_format = data_format or None
        ud.access_type = access_type or None
        ud.access_url = access_url or None
        ud.variables_text = variables_text or None
        ud.read_instructions = read_instructions or None
        ud.minimal_read_code = minimal_read_code or None
        ud.files_manifest = json.dumps(files_manifest)
        ud.status = "ready"
        ud.updated_at = now

    ud.save()

    return jsonify({"dataset": _serialize_user_dataset(ud), "status": ud.status})


@user_datasets_bp.route("/api/user_datasets/<dataset_key>", methods=["DELETE"])
@handle_api_errors
def delete_user_dataset(dataset_key: str):
    """Delete a user dataset permanently (Mongo metadata + local supplemental files)."""
    user = get_user_or_abort()

    key = _slugify_dataset_key(dataset_key)
    ud = (
        UserDataset.objects(user_id=str(user.id), dataset_key=key)
        .first()
    )
    if not ud:
        raise AppValidationError("Dataset not found")

    # Delete supplemental files directory
    try:
        d = _user_dataset_dir(key)
        if d.exists():
            shutil.rmtree(d)
    except Exception:
        # If filesystem deletion fails, still remove metadata to avoid re-linking deleted content.
        pass

    try:
        ud.delete()
    except Exception:
        # Metadata deletion failure is critical; surface as validation error.
        raise AppValidationError("Failed to delete dataset metadata")

    return jsonify({"status": "ok", "deleted_dataset_key": key})

