# EARTH-VUE documentation

## Overview

Deployed as a Flask app for  data exploration with RAG (Azure AI Search), Azure OpenAI, and optional code execution. This page covers setup, environment variables, and indexing your own documents.

---

## 1. Prerequisites

- Python 3.10+ recommended
- MongoDB (local or Atlas) for sessions and user data
- Azure OpenAI and Azure AI Search (for full RAG features)

---

## 2. Local setup

```bash
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Create a `.env` file in the project root (see below). Then:

```bash
export FLASK_APP=app.py
flask run --port 5000
```

Open `http://127.0.0.1:5000/`.

---

## 3. Environment variables

Set these in `.env` or your shell. Names may vary slightly if you mirror an existing deployment; align with what `app.py` and `services/langchain_client.py` read.

**Required for the app to start**

- `FLASK_SECRET_KEY` — session signing secret
- `MONGODB_URI` — e.g. `mongodb://127.0.0.1:27017/earthvue_db` or your Atlas connection string
- `MONGODB_DB` — database name (default `earthvue_db` in code)

**Azure OpenAI**

- `AZURE_OPENAI_ENDPOINT` or `ENDPOINT_URL`
- `AZURE_OPENAI_API_KEY`
- `DEPLOYMENT_NAME` — chat model deployment
- `AZURE_OPENAI_API_VERSION` — optional, defaults in code

**Azure AI Search (RAG)**

- `SEARCH_ENDPOINT`
- `SEARCH_KEY`
- `SEARCH_INDEX_NAME`
- `EMBEDDING_DEPLOYMENT_NAME` — embedding model deployment name in Azure OpenAI
- `EMBEDDING_MODEL_NAME` — optional, e.g. `text-embedding-ada-002`

**Arena / data-source extras (if used)**

- `SEARCH_SEMANTIC_CONFIGURATION` — optional semantic config name for Azure AI Search

Example skeleton (replace placeholders):

```
FLASK_SECRET_KEY=change-me
MONGODB_URI=mongodb://127.0.0.1:27017/earthvue_db
MONGODB_DB=earthvue_db

AZURE_OPENAI_ENDPOINT=https://YOUR_RESOURCE.openai.azure.com/
AZURE_OPENAI_API_KEY=your-key
DEPLOYMENT_NAME=your-chat-deployment

SEARCH_ENDPOINT=https://YOUR_SEARCH.search.windows.net
SEARCH_KEY=your-search-admin-key
SEARCH_INDEX_NAME=your-index
EMBEDDING_DEPLOYMENT_NAME=your-embedding-deployment
```

---

## 4. Adding data for RAG

1. Upload documents to **Azure Blob Storage** (or your chosen source supported by indexer).
2. In **Azure AI Search**, create or update an indexer so your container (or data source) is indexed into `SEARCH_INDEX_NAME`, including vector fields if you use vector search.
3. Ensure embedding deployment and index schema match what the app expects.
4. Set `SEARCH_*` and embedding variables in `.env` and restart the app.

---

## 5. CMIP6 catalog

The app can use a local `cmip6_catalog.yml` in the repo root for CMIP6 data . Remote catalog URLs in `data_registry.yml` / utilities should point to **your** hosted catalog if you fork or replace the upstream source.

---

## 6. Troubleshooting

- **MongoDB connection errors** — check `MONGODB_URI` and network access (Atlas IP allowlist, etc.).
- **Missing RAG** — verify `SEARCH_ENDPOINT`, `SEARCH_KEY`, `SEARCH_INDEX_NAME`, and embedding env vars.
- **Import errors** — run `pip install -r requirements.txt` in a clean venv.

---

## 7. Contributing

Open issues and pull requests on GitHub with a short description of the change and how you tested it.
