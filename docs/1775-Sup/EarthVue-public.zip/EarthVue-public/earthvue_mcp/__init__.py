"""
EarthVue MCP package: server and tools for IDE and dashboard agent.
Run the server from repo root: python -m earthvue_mcp.server
"""
