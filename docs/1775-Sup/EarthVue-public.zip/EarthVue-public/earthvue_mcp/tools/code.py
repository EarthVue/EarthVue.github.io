"""
Code execution and visualization tools.
"""

from __future__ import annotations

import json
import re
from services.code_executor import execute_code_safely, generate_visualization


def generate_code_tool(
    description: str,
    purpose: str = "visualization",
    context: str | None = None,
) -> str:
    """
    Generate Python code from a natural language description. Use this to produce code
    that you can then pass to execute_code or generate_visualization. purpose can be
    'visualization', 'analysis', or 'data_load'. context is optional (e.g. dataset id, variable names).

    Note: This tool uses a nested LLM call (chat_non_streaming), so it adds roughly one full
    API round-trip of latency. For faster results, the main model can generate code in the
    same turn and call execute_code(code=...) instead.
    """
    try:
        from services.langchain_client import chat_non_streaming
        system = (
            "You are a Python code generator for climate data. Return ONLY valid Python code, no markdown, "
            "no ``` wrapper, no explanation. Use intake for NEX-GDDP-CMIP6, matplotlib for plots. "
            "One block of code only. "
            "For 'example visualization' or 'show me an example' of the data: load a minimal subset so it runs in under ~15 seconds—e.g. one variable, one timestamp (or one day), and optional small lat_range/lon_range; avoid loading long time series or full global grids. "
            "If the request does not include exact model/date values, choose the first available model/date values from dataset metadata (e.g. list_models/list_timeranges) and include those explicit values in the generated code."
        )
        user = f"Generate Python code for: {description}"
        if purpose:
            user += f"\nPurpose: {purpose}."
        if context:
            user += f"\nContext: {context}."
        out = chat_non_streaming(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            temperature=0.2,
            max_tokens=1500,
            request_timeout=180,
        )
        if not out:
            return json.dumps({"error": "No code generated", "code": ""})
        # Strip markdown code block if present
        code = out.strip()
        for pattern in (r"^```(?:python)?\s*\n?", r"\n?```\s*$"):
            code = re.sub(pattern, "", code).strip()
        return json.dumps({"code": code, "description": description})
    except Exception as e:
        return json.dumps({"error": str(e), "code": ""})


def execute_code_tool(code: str, timeout_seconds: int = 30) -> str:
    """Execute provided Python code and return output and errors."""
    result = execute_code_safely(code, timeout=timeout_seconds)
    out = {
        "success": result["success"],
        "output": result.get("output", ""),
        "error": result.get("error", ""),
        "execution_time_seconds": result.get("execution_time", 0),
        "variables": result.get("variables", {}),
        "images_count": len(result.get("images", [])),
    }
    if result.get("images"):
        out["images_base64"] = result["images"]
    return json.dumps(out, indent=2, default=str)


def generate_visualization_tool(code: str, output_format: str = "png", timeout_seconds: int = 90) -> str:
    """Run code that produces matplotlib figures and return images. Uses 90s timeout for intake/plot."""
    result = generate_visualization(code, output_format=output_format, timeout=timeout_seconds)
    if result["success"]:
        return json.dumps(
            {
                "success": True,
                "images_base64": result.get("images", []),
                "format": result.get("format", output_format),
                "count": result.get("count", 0),
            },
            indent=2,
        )
    return json.dumps(
        {
            "success": False,
            "error": result.get("error", "No visualization generated"),
            "output": result.get("output", ""),
        },
        indent=2,
    )


def statistical_analysis_tool(code: str, timeout_seconds: int = 30) -> str:
    """Execute Python code for statistical analysis and return results as JSON."""
    result = execute_code_safely(code, timeout=timeout_seconds)
    if not result["success"]:
        return json.dumps(
            {
                "success": False,
                "error": result.get("error", "Execution failed"),
                "output": result.get("output", ""),
            },
            indent=2,
        )
    return json.dumps(
        {
            "success": True,
            "output": result.get("output", ""),
            "variables": result.get("variables", {}),
            "execution_time_seconds": result.get("execution_time", 0),
        },
        indent=2,
        default=str,
    )
