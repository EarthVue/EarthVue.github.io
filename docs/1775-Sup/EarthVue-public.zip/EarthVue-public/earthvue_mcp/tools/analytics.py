"""
Analytics tools: LLM-as-a-judge, reasoning step extraction.
"""

from __future__ import annotations

import json


def llm_judge_tool(prompt: str, response_format: str = "json") -> str:
    """
    Use an LLM as a judge: send a prompt and get back structured JSON.
    Use for evaluating a response, comparing options, or any structured analysis.
    """
    try:
        from services.analytics_service import analyze_with_llm
        result = analyze_with_llm(prompt, response_format=response_format)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps(
            {"error": str(e), "message": "LLM judge unavailable (check API keys / JUDGE_DEPLOYMENT_NAME)."},
            indent=2,
        )


def extract_reasoning_steps_tool(
    user_query: str,
    response_content: str,
    conversation_history_json: str | None = None,
) -> str:
    """
    Extract structured reasoning steps from a user query and model response.
    Returns a JSON array of steps with: step, type, action, description, confidence.
    """
    try:
        from services.analytics_service import extract_reasoning_steps
        history = None
        if conversation_history_json:
            try:
                history = json.loads(conversation_history_json)
            except json.JSONDecodeError:
                pass
        steps = extract_reasoning_steps(user_query, response_content, conversation_history=history)
        return json.dumps(steps, indent=2, default=str)
    except Exception as e:
        return json.dumps(
            {"error": str(e), "steps": [], "message": "Reasoning extraction failed (check LLM config)."},
            indent=2,
        )
