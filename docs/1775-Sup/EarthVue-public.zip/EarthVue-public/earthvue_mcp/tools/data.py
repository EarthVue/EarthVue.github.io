"""
Data registry tools: list datasets, list variables, load dataset metadata.
"""

from __future__ import annotations

from services.data_registry import get_sources, get_registry_context_for_prompt


def list_datasets() -> str:
    """List all datasets available in the registry."""
    sources = get_sources()
    if not sources:
        return "No datasets registered. Add entries to data_registry.yml."
    lines = ["Available datasets:", ""]
    for sid, meta in sources.items():
        name = meta.get("name", sid)
        desc = (meta.get("description") or "").strip()
        lines.append(f"- **{name}** (id: `{sid}`): {desc}")
    return "\n".join(lines)


def list_variables(source_id: str) -> str:
    """List variables and parameters for a given dataset by source_id."""
    sources = get_sources()
    if source_id not in sources:
        return f"Unknown dataset: {source_id}. Use list_datasets() to see valid IDs."
    meta = sources[source_id]
    name = meta.get("name", source_id)
    lines = [f"Dataset: **{name}** (`{source_id}`)", ""]
    vars_list = meta.get("variables", [])
    if isinstance(vars_list, list) and vars_list:
        lines.append("Variables:")
        for v in vars_list:
            if isinstance(v, dict):
                vid = v.get("id", "")
                vdesc = v.get("description", "")
                lines.append(f"  - `{vid}`: {vdesc}")
            else:
                lines.append(f"  - `{v}`")
        lines.append("")
    params = meta.get("parameters", [])
    if params:
        lines.append("Parameters: " + ", ".join(f"`{p}`" for p in params))
        lines.append("")
    usage = (meta.get("usage") or "").strip()
    if usage:
        lines.append("Usage (snippet):")
        for u in usage.split("\n")[:8]:
            lines.append(f"  {u.strip()}")
    return "\n".join(lines)


def load_dataset(source_id: str) -> str:
    """Load dataset metadata and access information for a given source_id."""
    context = get_registry_context_for_prompt(only_source_ids=[source_id])
    if not context.strip():
        return f"Dataset not found: {source_id}. Use list_datasets() to see valid IDs."
    return context
