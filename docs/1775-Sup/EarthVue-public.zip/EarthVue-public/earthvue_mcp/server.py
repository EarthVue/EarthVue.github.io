"""
FastMCP server exposing EarthVue tools for IDE.
Run from repo root: python -m earthvue_mcp.server
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure repo root is on path when run as python -m earthvue_mcp.server
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from fastmcp import FastMCP
from earthvue_mcp.tools import (
    list_datasets,
    list_variables,
    load_dataset,
    execute_code_tool,
    generate_code_tool,
    generate_visualization_tool,
    statistical_analysis_tool,
    llm_judge_tool,
    extract_reasoning_steps_tool,
)

mcp = FastMCP(name="Unified AI Data & Analytics")


@mcp.tool(description="List all registered datasets with their IDs, names, and short descriptions.")
def mcp_list_datasets() -> str:
    return list_datasets()


@mcp.tool(
    description="List variables (and parameters) for a dataset. Pass the dataset source_id from list_datasets."
)
def mcp_list_variables(source_id: str) -> str:
    return list_variables(source_id)


@mcp.tool(
    description="Get full metadata and access details for a dataset (catalog URL, access pattern, usage)."
)
def mcp_load_dataset(source_id: str) -> str:
    return load_dataset(source_id)


@mcp.tool(
    description="Execute Python code in a sandbox. Allowed: numpy, pandas, matplotlib, xarray, intake, scipy, sklearn, seaborn, plotly. Returns stdout, stderr, and any generated matplotlib figures as base64."
)
def mcp_execute_code(code: str, timeout_seconds: int = 30) -> str:
    return execute_code_tool(code, timeout_seconds=timeout_seconds)


@mcp.tool(
    description="Generate Python code from a natural language description. Use for visualization, analysis, or data_load. Returns JSON with 'code'. For 'show me', 'visualize', or 'how does X look' requests, always call this then generate_visualization—do not reply with code only."
)
def mcp_generate_code(
    description: str,
    purpose: str = "visualization",
    context: str | None = None,
) -> str:
    return generate_code_tool(description, purpose=purpose, context=context)


@mcp.tool(
    description="Run Python code that creates matplotlib figures; returns base64 PNG images. For plot/visualization requests, call generate_code first then this tool so the user sees the figure(s); you may also include the code in your reply so they have both."
)
def mcp_generate_visualization(code: str, output_format: str = "png", timeout_seconds: int = 90) -> str:
    return generate_visualization_tool(code, output_format=output_format, timeout_seconds=timeout_seconds)


@mcp.tool(
    description="Run statistical analysis by executing Python code (e.g. pandas, scipy, numpy). Use execute_code for general code; this tool is for stats summaries, correlations, distributions."
)
def mcp_statistical_analysis(code: str, timeout_seconds: int = 30) -> str:
    return statistical_analysis_tool(code, timeout_seconds=timeout_seconds)


@mcp.tool(
    description="Use an LLM as a judge: send a prompt and get back structured JSON (e.g. scores, criteria, reasoning). Use for evaluating a response, comparing options, or any structured analysis. Prompt should ask for JSON only."
)
def mcp_llm_judge(prompt: str, response_format: str = "json") -> str:
    return llm_judge_tool(prompt, response_format=response_format)


@mcp.tool(
    description="Extract structured reasoning steps from a user query and model response. Optionally pass conversation_history_json (JSON string of prior messages). Returns a JSON array of steps: step, type, action, description, confidence. Step types: query_understanding, data_retrieval, analysis, reasoning, validation."
)
def mcp_extract_reasoning_steps(
    user_query: str,
    response_content: str,
    conversation_history_json: str | None = None,
) -> str:
    return extract_reasoning_steps_tool(user_query, response_content, conversation_history_json)


if __name__ == "__main__":
    mcp.run()
