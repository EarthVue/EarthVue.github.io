"""Triple extraction, curation, and evaluation helpers for Knowledge Graph enrichment."""

from __future__ import annotations

import re
import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from services.data_registry import get_sources


_VARIABLE_ALIASES = {
    "temperature": "tas",
    "temp": "tas",
    "air temperature": "tas",
    "rain": "pr",
    "rainfall": "pr",
    "precipitation": "pr",
    "humidity": "hurs",
    "relative humidity": "hurs",
    "wind": "sfcWind",
    "wind speed": "sfcWind",
}

_INTENT_PATTERNS = {
    "plot": [r"\bplot\b", r"\bvisuali[sz]e\b", r"\bgraph\b", r"\bchart\b", r"\bmap\b"],
    "compare": [r"\bcompare\b", r"\bcontrast\b", r"\bversus\b", r"\bvs\b"],
    "analyze": [r"\banaly[sz]e\b", r"\binspect\b", r"\bexplore\b", r"\bevaluate\b"],
    "summarize": [r"\bsummarize\b", r"\bsummary\b", r"\boverview\b"],
    "forecast": [r"\bforecast\b", r"\bproject\b", r"\bprojection\b", r"\bpredict\b"],
}

_LOCATION_ALIASES = {
    "la": "Los Angeles",
    "l.a.": "Los Angeles",
    "los angeles": "Los Angeles",
    "nyc": "New York City",
    "new york": "New York City",
    "sf": "San Francisco",
    "san francisco": "San Francisco",
}

_ALLOWED_NODE_TYPES = {
    "dataset",
    "variable",
    "model",
    "scenario",
    "query",
    "intent",
    "location",
    "concept",
}

_ALLOWED_SOURCE_KINDS = {"query", "response", "retrieved_docs"}

_ALLOWED_PREDICATES = {
    "queried_with",
    "provides",
    "alternative_source_for",
    "expresses_intent",
    "targets_location",
    "uses_dataset",
    "requests_variable",
    "mentions",
    "supports",
    "related_to",
}

_PREDICATE_TYPE_RULES = {
    "queried_with": {("dataset", "variable")},
    "provides": {("dataset", "variable")},
    "alternative_source_for": {("dataset", "variable")},
    "expresses_intent": {("query", "intent")},
    "targets_location": {("query", "location")},
    "uses_dataset": {("query", "dataset")},
    "requests_variable": {("query", "variable")},
}


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", (value or "").strip().lower()).strip("_")


def _find_mentions(text: str, sources: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, str]], List[Tuple[str, str]]]:
    q = (text or "").lower()

    dataset_mentions: List[Tuple[str, str]] = []
    variable_mentions: List[Tuple[str, str]] = []

    for source_id, meta in sources.items():
        ds_label = meta.get("name") or source_id
        sid_slug = _slug(source_id)
        sid_hyphen = source_id.replace("_", "-").lower()

        # Build lightweight aliases so partial mentions (e.g., "cmip6") can be matched.
        aliases = {
            source_id.lower(),
            sid_hyphen,
            ds_label.lower(),
        }
        aliases.update(
            token for token in re.split(r"[^a-z0-9]+", source_id.lower()) if len(token) >= 4
        )
        aliases.update(
            token for token in re.split(r"[^a-z0-9]+", ds_label.lower()) if len(token) >= 4
        )

        if any(alias and re.search(rf"\b{re.escape(alias)}\b", q) for alias in aliases):
            dataset_mentions.append((sid_slug, ds_label))

        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                var_id = str(var.get("id") or "").strip()
                var_label = var_id
            else:
                var_id = str(var).strip()
                var_label = var_id
            if not var_id:
                continue
            var_id_l = var_id.lower()
            has_var_match = re.search(rf"\b{re.escape(var_id_l)}\b", q) is not None

            if not has_var_match:
                for alias, canonical in _VARIABLE_ALIASES.items():
                    if canonical != var_id_l:
                        continue
                    if re.search(rf"\b{re.escape(alias)}\b", q):
                        has_var_match = True
                        break

            if has_var_match:
                variable_mentions.append((_slug(var_id), var_label))

    # Stable unique
    dataset_mentions = list({(sid, lbl) for sid, lbl in dataset_mentions})
    variable_mentions = list({(vid, lbl) for vid, lbl in variable_mentions})
    return dataset_mentions, variable_mentions


def _canonical_predicate(value: str) -> str:
    rel = (value or "related_to").strip().lower()
    mapping = {
        "requested_for": "queried_with",
        "supports_variable": "provides",
        "alternative_for": "alternative_source_for",
        "uses": "uses_dataset",
        "mentions": "mentions",
        "asks_for": "requests_variable",
    }
    return mapping.get(rel, rel)


def _extract_intents(text: str) -> List[str]:
    q = (text or "").lower()
    intents: List[str] = []
    for intent, patterns in _INTENT_PATTERNS.items():
        if any(re.search(pat, q) for pat in patterns):
            intents.append(intent)
    return sorted(set(intents))


def _extract_locations(text: str) -> List[Tuple[str, str]]:
    q = (text or "").lower()
    found = set()

    for alias, label in _LOCATION_ALIASES.items():
        if re.search(rf"\b{re.escape(alias.lower())}\b", q):
            found.add((f"location_{_slug(label)}", label))

    # Very lightweight phrase capture for patterns like "in <place>" and "for <place>".
    for pat in [r"\bin\s+([a-z][a-z\s\-.]{1,40})", r"\bfor\s+([a-z][a-z\s\-.]{1,40})"]:
        for match in re.finditer(pat, q):
            phrase = (match.group(1) or "").strip(" .,")
            if not phrase:
                continue
            # Ignore common non-location tails.
            if any(stop in phrase for stop in ["using", "with", "data", "model", "scenario", "temperature", "precipitation"]):
                continue
            pretty = " ".join(x.capitalize() for x in phrase.split())
            found.add((f"location_{_slug(pretty)}", pretty))

    return sorted(found)


def _build_query_node(query_text: str) -> Tuple[str, str]:
    normalized = re.sub(r"\s+", " ", (query_text or "").strip())
    compact = _slug(normalized)[:72] or "query"
    return f"query_{compact}", (normalized[:96] + "...") if len(normalized) > 96 else normalized


def _build_registry_alias_index(
    sources: Dict[str, Dict[str, Any]],
) -> Tuple[Dict[str, Tuple[str, str]], Dict[str, Tuple[str, str]]]:
    dataset_alias_to_entity: Dict[str, Tuple[str, str]] = {}
    variable_alias_to_entity: Dict[str, Tuple[str, str]] = {}

    for source_id, meta in sources.items():
        ds_id = _slug(source_id)
        ds_label = str(meta.get("name") or source_id)

        ds_aliases = {
            source_id.lower(),
            source_id.replace("_", "-").lower(),
            ds_label.lower(),
        }
        ds_aliases.update(
            token for token in re.split(r"[^a-z0-9]+", source_id.lower()) if len(token) >= 4
        )
        ds_aliases.update(
            token for token in re.split(r"[^a-z0-9]+", ds_label.lower()) if len(token) >= 4
        )

        for alias in ds_aliases:
            if alias:
                dataset_alias_to_entity[alias] = (ds_id, ds_label)

        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                var_id = str(var.get("id") or "").strip()
            else:
                var_id = str(var).strip()
            if not var_id:
                continue

            var_slug = _slug(var_id)
            var_label = var_id
            var_aliases = {var_id.lower(), var_slug.lower()}
            for alias, canonical in _VARIABLE_ALIASES.items():
                if canonical.lower() == var_id.lower():
                    var_aliases.add(alias.lower())

            for alias in var_aliases:
                if alias:
                    variable_alias_to_entity[alias] = (var_slug, var_label)

    return dataset_alias_to_entity, variable_alias_to_entity


def _coerce_confidence(value: Any, default: float = 0.5) -> float:
    try:
        out = float(value)
    except Exception:
        out = default
    return max(0.0, min(1.0, out))


def _is_predicate_type_valid(predicate: str, subject_type: str, object_type: str) -> bool:
    rules = _PREDICATE_TYPE_RULES.get(predicate)
    if not rules:
        return True
    return (subject_type, object_type) in rules


def _normalize_entity(
    *,
    node_type: str,
    node_id: str,
    node_label: str,
    query_id: str,
    query_label: str,
    dataset_alias_to_entity: Dict[str, Tuple[str, str]],
    variable_alias_to_entity: Dict[str, Tuple[str, str]],
) -> Optional[Tuple[str, str, str]]:
    ntype = (node_type or "concept").strip().lower()
    if ntype not in _ALLOWED_NODE_TYPES:
        ntype = "concept"

    label = (node_label or node_id or "").strip()
    rid = (node_id or "").strip()

    if ntype == "query":
        return query_id, (label or query_label or "User Query"), "query"

    if ntype == "dataset":
        key_candidates = [rid.lower(), label.lower(), _slug(label).lower()]
        for key in key_candidates:
            if key in dataset_alias_to_entity:
                ds_id, ds_label = dataset_alias_to_entity[key]
                return ds_id, ds_label, "dataset"
        return None

    if ntype == "variable":
        key_candidates = [rid.lower(), label.lower(), _slug(label).lower()]
        for key in key_candidates:
            if key in variable_alias_to_entity:
                var_id, var_label = variable_alias_to_entity[key]
                return var_id, var_label, "variable"
        return None

    if ntype == "intent":
        final_label = label or rid or "Intent"
        return f"intent_{_slug(final_label)}", final_label, "intent"

    if ntype == "location":
        final_label = label or rid or "Location"
        return f"location_{_slug(final_label)}", final_label, "location"

    final_label = label or rid or "Entity"
    return (_slug(rid or final_label) or _slug(final_label), final_label, ntype)


def _llm_extract_triples(
    *,
    user_id: str,
    session_uuid: str,
    reasoning_trace_id: Optional[str],
    query_text: str,
    response_text: str,
    sources: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    if not query_text.strip() and not response_text.strip():
        return []

    try:
        from langchain_core.messages import HumanMessage, SystemMessage
        from services.langchain_client import DEPLOYMENT_NAME, get_llm_for
    except Exception:
        return []

    dataset_alias_to_entity, variable_alias_to_entity = _build_registry_alias_index(sources)
    query_id, query_label = _build_query_node(query_text)

    schema_hint = {
        "triples": [
            {
                "subject": {"id": "string", "label": "string", "type": "dataset|variable|query|intent|location|model|scenario|concept"},
                "predicate": "string",
                "object": {"id": "string", "label": "string", "type": "dataset|variable|query|intent|location|model|scenario|concept"},
                "confidence": 0.0,
                "source_kind": "query|response",
                "evidence": "short substring from input",
            }
        ]
    }

    allowed_ds = sorted({v[1] for v in dataset_alias_to_entity.values()})[:80]
    allowed_vars = sorted({v[1] for v in variable_alias_to_entity.values()})[:120]

    system_prompt = (
        "You extract knowledge-graph triples from a climate chat turn. "
        "Return ONLY valid JSON matching the schema. "
        "Do not include markdown. "
        "Only return triples grounded in explicit query/response text. "
        "If unsure, skip the triple."
    )

    user_prompt = (
        f"Schema: {json.dumps(schema_hint)}\n"
        f"Allowed predicates: {sorted(_ALLOWED_PREDICATES)}\n"
        f"Known datasets (labels): {allowed_ds}\n"
        f"Known variables (ids): {allowed_vars}\n"
        f"User query: {query_text}\n"
        f"Assistant response: {response_text}\n"
        "Return at most 16 triples."
    )

    try:
        llm = get_llm_for(DEPLOYMENT_NAME, preferred_temperature=0)
        raw = llm.invoke([SystemMessage(content=system_prompt), HumanMessage(content=user_prompt)])
        content = (getattr(raw, "content", "") or "").strip()
        if not content:
            return []
        start = content.find("{")
        end = content.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return []
        parsed = json.loads(content[start : end + 1])
    except Exception:
        return []

    triples = parsed.get("triples") if isinstance(parsed, dict) else None
    if not isinstance(triples, list):
        return []

    out: List[Dict[str, Any]] = []
    for item in triples[:24]:
        if not isinstance(item, dict):
            continue

        subj_raw = item.get("subject")
        obj_raw = item.get("object")
        subj: Dict[str, Any] = subj_raw if isinstance(subj_raw, dict) else {}
        obj: Dict[str, Any] = obj_raw if isinstance(obj_raw, dict) else {}

        pred = _canonical_predicate(str(item.get("predicate") or "related_to"))
        if pred not in _ALLOWED_PREDICATES:
            pred = "related_to"

        source_kind = str(item.get("source_kind") or "query").strip().lower()
        if source_kind not in _ALLOWED_SOURCE_KINDS:
            source_kind = "query"

        subj_norm = _normalize_entity(
            node_type=str(subj.get("type") or "concept"),
            node_id=str(subj.get("id") or ""),
            node_label=str(subj.get("label") or ""),
            query_id=query_id,
            query_label=query_label,
            dataset_alias_to_entity=dataset_alias_to_entity,
            variable_alias_to_entity=variable_alias_to_entity,
        )
        obj_norm = _normalize_entity(
            node_type=str(obj.get("type") or "concept"),
            node_id=str(obj.get("id") or ""),
            node_label=str(obj.get("label") or ""),
            query_id=query_id,
            query_label=query_label,
            dataset_alias_to_entity=dataset_alias_to_entity,
            variable_alias_to_entity=variable_alias_to_entity,
        )

        if not subj_norm or not obj_norm:
            continue

        subj_id, subj_label, subj_type = subj_norm
        obj_id, obj_label, obj_type = obj_norm

        if subj_id == obj_id:
            continue
        if not _is_predicate_type_valid(pred, subj_type, obj_type):
            continue

        evidence = str(item.get("evidence") or "").strip()
        excerpt = evidence[:400] or (query_text[:400] if source_kind == "query" else response_text[:400])

        out.append(
            {
                "user_id": str(user_id),
                "session_uuid": session_uuid,
                "reasoning_trace_id": reasoning_trace_id,
                "subject_id": subj_id,
                "subject_label": subj_label,
                "subject_type": subj_type,
                "predicate": pred,
                "object_id": obj_id,
                "object_label": obj_label,
                "object_type": obj_type,
                "confidence": _coerce_confidence(item.get("confidence"), default=0.65),
                "extraction_method": "llm_v1",
                "extractor_version": "triple-candidate-llm-0.1",
                "source_kind": source_kind,
                "source_excerpt": excerpt,
                "source_payload": {
                    "query_text": query_text[:1200],
                    "response_text": response_text[:1200],
                    "llm_evidence": evidence[:600],
                },
            }
        )

    return out


def _dedupe_payloads(payloads: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dedup: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for p in payloads:
        p["predicate"] = _canonical_predicate(p.get("predicate", ""))
        key = (
            p["user_id"],
            p["session_uuid"],
            p["reasoning_trace_id"],
            p["subject_id"],
            p["predicate"],
            p["object_id"],
            p["subject_type"],
            p["object_type"],
            p["source_kind"],
        )
        if key not in dedup or _coerce_confidence(p.get("confidence"), 0.0) > _coerce_confidence(
            dedup[key].get("confidence"), 0.0
        ):
            dedup[key] = p
    return list(dedup.values())


def _build_candidate_payloads(
    *,
    user_id: str,
    session_uuid: str,
    reasoning_trace_id: Optional[str],
    query_text: str,
    response_text: str,
    sources: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    payloads: List[Dict[str, Any]] = []

    q_datasets, q_vars = _find_mentions(query_text, sources)
    r_datasets, r_vars = _find_mentions(response_text, sources)

    # 1) Query-driven intent triples
    for ds_id, ds_label in q_datasets:
        for var_id, var_label in q_vars:
            payloads.append(
                {
                    "user_id": str(user_id),
                    "session_uuid": session_uuid,
                    "reasoning_trace_id": reasoning_trace_id,
                    "subject_id": ds_id,
                    "subject_label": ds_label,
                    "subject_type": "dataset",
                    "predicate": "queried_with",
                    "object_id": var_id,
                    "object_label": var_label,
                    "object_type": "variable",
                    "confidence": 0.70,
                    "extraction_method": "heuristic_v1",
                    "extractor_version": "triple-candidate-0.1",
                    "source_kind": "query",
                    "source_excerpt": query_text[:400],
                    "source_payload": {
                        "query_text": query_text,
                        "response_text": response_text[:500],
                    },
                }
            )

    # 1b) Explicit query entity graph: query -> intent/location/dataset/variable
    query_id, query_label = _build_query_node(query_text)

    for intent in _extract_intents(query_text):
        payloads.append(
            {
                "user_id": str(user_id),
                "session_uuid": session_uuid,
                "reasoning_trace_id": reasoning_trace_id,
                "subject_id": query_id,
                "subject_label": query_label or "User Query",
                "subject_type": "query",
                "predicate": "expresses_intent",
                "object_id": f"intent_{_slug(intent)}",
                "object_label": intent.replace("_", " ").title(),
                "object_type": "intent",
                "confidence": 0.80,
                "extraction_method": "heuristic_v2",
                "extractor_version": "triple-candidate-0.2",
                "source_kind": "query",
                "source_excerpt": query_text[:400],
                "source_payload": {
                    "query_text": query_text,
                    "match": "intent_pattern",
                },
            }
        )

    for loc_id, loc_label in _extract_locations(query_text):
        payloads.append(
            {
                "user_id": str(user_id),
                "session_uuid": session_uuid,
                "reasoning_trace_id": reasoning_trace_id,
                "subject_id": query_id,
                "subject_label": query_label or "User Query",
                "subject_type": "query",
                "predicate": "targets_location",
                "object_id": loc_id,
                "object_label": loc_label,
                "object_type": "location",
                "confidence": 0.75,
                "extraction_method": "heuristic_v2",
                "extractor_version": "triple-candidate-0.2",
                "source_kind": "query",
                "source_excerpt": query_text[:400],
                "source_payload": {
                    "query_text": query_text,
                    "match": "location_pattern",
                },
            }
        )

    for ds_id, ds_label in q_datasets:
        payloads.append(
            {
                "user_id": str(user_id),
                "session_uuid": session_uuid,
                "reasoning_trace_id": reasoning_trace_id,
                "subject_id": query_id,
                "subject_label": query_label or "User Query",
                "subject_type": "query",
                "predicate": "uses_dataset",
                "object_id": ds_id,
                "object_label": ds_label,
                "object_type": "dataset",
                "confidence": 0.80,
                "extraction_method": "heuristic_v2",
                "extractor_version": "triple-candidate-0.2",
                "source_kind": "query",
                "source_excerpt": query_text[:400],
                "source_payload": {
                    "query_text": query_text,
                },
            }
        )

    for var_id, var_label in q_vars:
        payloads.append(
            {
                "user_id": str(user_id),
                "session_uuid": session_uuid,
                "reasoning_trace_id": reasoning_trace_id,
                "subject_id": query_id,
                "subject_label": query_label or "User Query",
                "subject_type": "query",
                "predicate": "requests_variable",
                "object_id": var_id,
                "object_label": var_label,
                "object_type": "variable",
                "confidence": 0.80,
                "extraction_method": "heuristic_v2",
                "extractor_version": "triple-candidate-0.2",
                "source_kind": "query",
                "source_excerpt": query_text[:400],
                "source_payload": {
                    "query_text": query_text,
                },
            }
        )

    # 2) Response-driven support triples
    for ds_id, ds_label in r_datasets:
        for var_id, var_label in r_vars:
            payloads.append(
                {
                    "user_id": str(user_id),
                    "session_uuid": session_uuid,
                    "reasoning_trace_id": reasoning_trace_id,
                    "subject_id": ds_id,
                    "subject_label": ds_label,
                    "subject_type": "dataset",
                    "predicate": "provides",
                    "object_id": var_id,
                    "object_label": var_label,
                    "object_type": "variable",
                    "confidence": 0.75,
                    "extraction_method": "heuristic_v1",
                    "extractor_version": "triple-candidate-0.1",
                    "source_kind": "response",
                    "source_excerpt": response_text[:400],
                    "source_payload": {
                        "query_text": query_text[:500],
                        "response_text": response_text,
                    },
                }
            )

    # 3) Alternative-source opportunities (for curation and decision support)
    var_to_datasets: Dict[str, List[Tuple[str, str]]] = {}
    for sid, meta in sources.items():
        ds_slug = _slug(sid)
        ds_label = meta.get("name") or sid
        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                var_id = str(var.get("id") or "").strip()
                var_label = var_id
            else:
                var_id = str(var).strip()
                var_label = var_id
            if not var_id:
                continue
            var_to_datasets.setdefault(_slug(var_id), []).append((ds_slug, ds_label))

    selected_ds = {sid for sid, _ in (q_datasets or r_datasets)}
    selected_var = {vid: lbl for vid, lbl in (q_vars or r_vars)}

    for var_id, var_label in selected_var.items():
        for ds_id, ds_label in var_to_datasets.get(var_id, []):
            if ds_id in selected_ds:
                continue
            payloads.append(
                {
                    "user_id": str(user_id),
                    "session_uuid": session_uuid,
                    "reasoning_trace_id": reasoning_trace_id,
                    "subject_id": ds_id,
                    "subject_label": ds_label,
                    "subject_type": "dataset",
                    "predicate": "alternative_source_for",
                    "object_id": var_id,
                    "object_label": var_label,
                    "object_type": "variable",
                    "confidence": 0.60,
                    "extraction_method": "heuristic_v1",
                    "extractor_version": "triple-candidate-0.1",
                    "source_kind": "query",
                    "source_excerpt": query_text[:400],
                    "source_payload": {
                        "query_text": query_text,
                        "selected_dataset_ids": sorted(selected_ds),
                    },
                }
            )

    return _dedupe_payloads(payloads)


def extract_and_store_candidate_triples(
    *,
    user_id: str,
    session_uuid: str,
    reasoning_trace_id: Optional[str],
    query_text: str,
    response_text: str,
) -> Dict[str, Any]:
    """Extract candidate triples from query/response and persist auditable records."""
    from models import KnowledgeTriple

    sources = get_sources(force_reload=True) or {}
    if not sources:
        return {"created": 0, "updated": 0, "total_candidates": 0}

    heuristic_payloads = _build_candidate_payloads(
        user_id=user_id,
        session_uuid=session_uuid,
        reasoning_trace_id=reasoning_trace_id,
        query_text=query_text,
        response_text=response_text,
        sources=sources,
    )

    llm_payloads = _llm_extract_triples(
        user_id=user_id,
        session_uuid=session_uuid,
        reasoning_trace_id=reasoning_trace_id,
        query_text=query_text,
        response_text=response_text,
        sources=sources,
    )

    payloads = _dedupe_payloads([*heuristic_payloads, *llm_payloads])

    created = 0
    updated = 0

    for payload in payloads:
        existing = KnowledgeTriple.objects(  # type: ignore[attr-defined]
            user_id=payload["user_id"],
            session_uuid=payload["session_uuid"],
            reasoning_trace_id=payload.get("reasoning_trace_id"),
            subject_id=payload["subject_id"],
            predicate=payload["predicate"],
            object_id=payload["object_id"],
            source_kind=payload["source_kind"],
        ).first()

        if existing:
            if payload["confidence"] > (existing.confidence or 0):
                existing.confidence = payload["confidence"]
            if payload.get("source_excerpt"):
                existing.source_excerpt = payload["source_excerpt"]
            existing.source_payload = payload.get("source_payload") or {}
            existing.updated_at = datetime.now()
            existing.save()
            updated += 1
            continue

        triple = KnowledgeTriple(**payload)
        triple.save()
        created += 1

    return {
        "created": created,
        "updated": updated,
        "total_candidates": len(payloads),
        "llm_candidates": len(llm_payloads),
        "heuristic_candidates": len(heuristic_payloads),
    }


def evaluate_decision_impact(user_id: str, days: int = 30) -> Dict[str, Any]:
    """Compute decision-quality proxy metrics to evaluate curation impact."""
    from models import DataAccessEvent, KnowledgeTriple

    cutoff = datetime.now() - timedelta(days=max(1, int(days)))
    sources = get_sources(force_reload=True) or {}

    # Build dataset->variables index for mismatch checks
    dataset_to_vars: Dict[str, set] = {}
    for sid, meta in sources.items():
        ds_slug = _slug(sid)
        vars_set = set()
        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                vid = str(var.get("id") or "").strip()
            else:
                vid = str(var).strip()
            if vid:
                vars_set.add(_slug(vid))
        dataset_to_vars[ds_slug] = vars_set

    events = list(
        DataAccessEvent.objects(user_id=str(user_id), timestamp__gte=cutoff)  # type: ignore[attr-defined]
        .order_by("-timestamp")[:300]
    )

    total_events = len(events)
    mismatches = 0
    evaluated_events = 0

    for event in events:
        query = (event.query_text or "").strip()
        ds_mentions, var_mentions = _find_mentions(query, sources)
        if not ds_mentions or not var_mentions:
            continue
        evaluated_events += 1

        ds_ids = [_slug(x[0]) for x in ds_mentions]
        var_ids = [_slug(x[0]) for x in var_mentions]

        for dsid in ds_ids:
            available = dataset_to_vars.get(dsid, set())
            if available and any(var not in available for var in var_ids):
                mismatches += 1
                break

    approved = list(
        KnowledgeTriple.objects(user_id=str(user_id), status="approved")  # type: ignore[attr-defined]
        .order_by("-updated_at")[:400]
    )

    approved_alt = [t for t in approved if t.predicate == "alternative_source_for"]
    approved_supports = [t for t in approved if t.predicate in ("provides", "queried_with")]

    mismatch_rate = float(mismatches) / float(max(1, evaluated_events))

    # Projected improvement proxy: more approved alternatives implies higher chance to reduce mismatch/overreliance.
    projected_reduction = min(0.5, 0.05 * len(approved_alt))
    projected_mismatch_rate = max(0.0, mismatch_rate * (1.0 - projected_reduction))

    return {
        "window_days": int(days),
        "total_events": total_events,
        "evaluated_events": evaluated_events,
        "baseline": {
            "semantic_mismatch_count": mismatches,
            "semantic_mismatch_rate": round(mismatch_rate, 3),
        },
        "curation": {
            "approved_total": len(approved),
            "approved_alternative_for": len(approved_alt),
            "approved_support_triples": len(approved_supports),
        },
        "projected_with_curated_triples": {
            "semantic_mismatch_rate": round(projected_mismatch_rate, 3),
            "assumption": "Proxy estimate based on approved alternative_for relations.",
        },
    }


def _status_rank(status: str) -> int:
    order = {
        "approved": 3,
        "candidate": 2,
        "rejected": 1,
    }
    return order.get((status or "").strip().lower(), 0)


def merge_legacy_triple_predicates(user_id: str, dry_run: bool = False) -> Dict[str, Any]:
    """Canonicalize legacy relation words and merge duplicate triples after rewrite."""
    from models import KnowledgeTriple

    triples = list(
        KnowledgeTriple.objects(user_id=str(user_id)).order_by("-updated_at")  # type: ignore[attr-defined]
    )

    unchanged = 0
    rewritten = 0
    merged = 0
    deleted = 0

    for t in triples:
        old_pred = (t.predicate or "").strip()
        new_pred = _canonical_predicate(old_pred)

        if new_pred == old_pred:
            unchanged += 1
            continue

        # Find potential duplicate target after canonical rewrite.
        dup = KnowledgeTriple.objects(  # type: ignore[attr-defined]
            user_id=str(user_id),
            session_uuid=t.session_uuid,
            reasoning_trace_id=t.reasoning_trace_id,
            subject_id=t.subject_id,
            object_id=t.object_id,
            source_kind=t.source_kind,
            predicate=new_pred,
            id__ne=t.id,
        ).first()

        if dup:
            merged += 1
            if dry_run:
                continue

            # Keep strongest confidence and most advanced status.
            dup.confidence = max(float(dup.confidence or 0.0), float(t.confidence or 0.0))
            if _status_rank(t.status) > _status_rank(dup.status):
                dup.status = t.status
                dup.reviewer_user_id = t.reviewer_user_id or dup.reviewer_user_id
                dup.reviewer_note = t.reviewer_note or dup.reviewer_note
                dup.reviewed_at = t.reviewed_at or dup.reviewed_at

            # Preserve richer source excerpt/context.
            if (t.source_excerpt or "") and len(t.source_excerpt or "") > len(dup.source_excerpt or ""):
                dup.source_excerpt = t.source_excerpt
            if t.source_payload:
                merged_payload = dict(dup.source_payload or {})
                merged_payload.update(t.source_payload)
                dup.source_payload = merged_payload

            dup.updated_at = datetime.now()
            dup.save()
            t.delete()
            deleted += 1
            continue

        rewritten += 1
        if dry_run:
            continue

        t.predicate = new_pred
        t.updated_at = datetime.now()
        t.save()

    return {
        "user_id": str(user_id),
        "dry_run": bool(dry_run),
        "total_triples": len(triples),
        "unchanged": unchanged,
        "rewritten": rewritten,
        "merged": merged,
        "deleted": deleted,
    }
