"""
Secure code execution engine for running Python code and generating visualizations.
"""

import os
import sys
import io
import traceback
import base64
import logging
from typing import Dict, Optional, List, Any
from datetime import datetime
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import numpy as np

logger = logging.getLogger(__name__)

# Allowed imports for code execution
# Base modules - submodules of these are automatically allowed
ALLOWED_IMPORTS = {
    'numpy', 'np', 'pandas', 'pd', 'matplotlib', 'plt', 'xarray', 'xr','s3fs',
    'intake', 'json', 'math', 'datetime', 'time', 'os', 'sys', 'io','intake','intake-nexgddp',
    'base64', 'collections', 'itertools', 'functools', 'operator',
    'scipy', 'sklearn', 'seaborn', 'plotly','intake', 'OpenVisus', 'openvisuspy',
    'planetary_computer', 'pystac_client', 'odc', 'odc.stac',
    'cartopy', 'cartopy.crs', 'ccrs'  # Additional scientific libraries
}

# Blocked operations
BLOCKED_KEYWORDS = [
    'import os.system', 'import subprocess', '__import__', 'exec(', 'eval(',
    'file(', 'input(', 'raw_input(', 'compile(', '__builtins__'
]


class CodeExecutionError(Exception):
    """Error during code execution"""
    pass


class SecurityError(CodeExecutionError):
    """Security violation in code"""
    pass


def validate_code_security(code: str) -> bool:
    """
    Validate that code doesn't contain dangerous operations.
    
    Args:
        code: Python code to validate
    
    Returns:
        True if safe, raises SecurityError if not
    
    Raises:
        SecurityError: If code contains dangerous operations
    """
    code_lower = code.lower()
    
    # Check for blocked keywords
    for blocked in BLOCKED_KEYWORDS:
        if blocked.lower() in code_lower:
            raise SecurityError(f"Blocked operation detected: {blocked}")
    
    # Block direct builtin open() for file access.
    # Allow namespaced method calls like Client.open(...) used by safe libraries.
    dangerous_patterns = [
        r'open\s*\([^)]*[\'"]w',
        r'open\s*\([^)]*[\'"]a',
        r'(?<![\w.])open(?!_catalog)\s*\(\s*[\'"]',  # blocks direct open('...'), allows obj.open('...')
        r'__import__\s*\(',
        r'eval\s*\(',
        r'exec\s*\(',
    ]
    
    import re
    for pattern in dangerous_patterns:
        if re.search(pattern, code):
            raise SecurityError(f"Potentially dangerous operation detected: {pattern}")
    
    return True


def execute_code_safely(code: str, timeout: int = 30, 
                       capture_output: bool = True) -> Dict[str, Any]:
    """
    Execute Python code in a restricted environment.
    
    Args:
        code: Python code to execute
        timeout: Execution timeout in seconds
        capture_output: Whether to capture stdout/stderr
    
    Returns:
        Dictionary with execution results:
        - success: bool
        - output: str (stdout)
        - error: str (stderr if any)
        - execution_time: float (seconds)
        - variables: dict (variables defined in code)
        - images: list (base64-encoded images)
    
    Raises:
        SecurityError: If code contains dangerous operations
        CodeExecutionError: If execution fails
    """
    start_time = datetime.now()
    
    # Validate code security
    validate_code_security(code)
    
    # Safe import function that only allows whitelisted modules
    def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
        # Check if base module is allowed (e.g., 'matplotlib' in 'matplotlib.pyplot')
        base_module = name.split('.')[0]
        
        # Allow if base module is in allowed list (for submodules like matplotlib.pyplot)
        if base_module in ALLOWED_IMPORTS:
            try:
                return __import__(name, globals, locals, fromlist, level)
            except ImportError:
                # If full import fails, try importing base module and accessing submodule
                base = __import__(base_module, globals, locals, [], level)
                parts = name.split('.')[1:]
                for part in parts:
                    base = getattr(base, part)
                return base
        
        # Also check if the full name is in allowed imports
        if name in ALLOWED_IMPORTS:
            return __import__(name, globals, locals, fromlist, level)
        
        raise ImportError(f"Import of '{name}' is not allowed")
    
    # Create restricted globals
    restricted_globals = {
        '__builtins__': {
            'abs': abs, 'all': all, 'any': any, 'bool': bool, 'dict': dict,
            'float': float, 'int': int, 'len': len, 'list': list, 'max': max,
            'min': min, 'range': range, 'round': round, 'str': str, 'sum': sum,
            'tuple': tuple, 'type': type, 'zip': zip, 'enumerate': enumerate,
            'isinstance': isinstance, 'print': print, 'repr': repr,
            'set': set, 'frozenset': frozenset,
            # Common exception classes for normal try/except and raises in user code
            'Exception': Exception, 'RuntimeError': RuntimeError, 'ValueError': ValueError,
            'TypeError': TypeError, 'KeyError': KeyError, 'IndexError': IndexError,
            'NameError': NameError, 'ImportError': ImportError, 'AssertionError': AssertionError,
            '__import__': safe_import  # Add safe import function
        },
        'np': np,
        'plt': plt,
        'matplotlib': matplotlib,
    }
    
    # Add allowed imports directly
    for import_name in ALLOWED_IMPORTS:
        try:
            # Handle submodules (e.g., 'matplotlib.pyplot')
            if '.' in import_name:
                parts = import_name.split('.')
                module = __import__(parts[0])
                for part in parts[1:]:
                    module = getattr(module, part)
                restricted_globals[import_name] = module
            else:
                restricted_globals[import_name] = __import__(import_name)
        except (ImportError, AttributeError):
            pass
    
    # Also add common aliases and ensure plt is available
    if 'numpy' in restricted_globals:
        restricted_globals['np'] = restricted_globals['numpy']
    if 'pandas' in restricted_globals:
        restricted_globals['pd'] = restricted_globals['pandas']
    if 'matplotlib.pyplot' in restricted_globals:
        restricted_globals['plt'] = restricted_globals['matplotlib.pyplot']
    elif 'matplotlib' in restricted_globals:
        # If matplotlib is available, add pyplot as plt
        try:
            restricted_globals['plt'] = restricted_globals['matplotlib'].pyplot
        except AttributeError:
            pass
    if 'xarray' in restricted_globals:
        restricted_globals['xr'] = restricted_globals['xarray']
    if 'cartopy.crs' in restricted_globals:
        restricted_globals['ccrs'] = restricted_globals['cartopy.crs']
    
    restricted_locals = {}
    
    # Capture stdout/stderr
    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    
    images = []
    plotly_html = []
    captured_plotly_obj_ids = set()
    result = {
        'success': False,
        'output': '',
        'error': '',
        'execution_time': 0.0,
        'variables': {},
        'images': [],
        'plotly_html': []
    }

    def _is_plotly_figure(obj: Any) -> bool:
        """Best-effort detector for Plotly figure objects."""
        try:
            module_name = obj.__class__.__module__
            return module_name.startswith('plotly') and hasattr(obj, 'to_html')
        except Exception:
            return False

    def _figure_to_html(fig: Any) -> Optional[str]:
        """Convert a Plotly figure to embeddable HTML."""
        try:
            return fig.to_html(full_html=False, include_plotlyjs='cdn')
        except Exception:
            return None

    # Capture Plotly figures when user calls fig.show().
    original_pio_show = None
    original_basefigure_show = None
    patched_basefigure_cls = None
    try:
        import plotly.io as _pio
        from plotly.basedatatypes import BaseFigure as _BaseFigure

        original_pio_show = getattr(_pio, 'show', None)
        original_basefigure_show = getattr(_BaseFigure, 'show', None)
        patched_basefigure_cls = _BaseFigure

        def _capture_plotly_show(fig, *args, **kwargs):
            html = _figure_to_html(fig)
            if html:
                plotly_html.append(html)
                captured_plotly_obj_ids.add(id(fig))
            return None

        def _capture_basefigure_show(self, *args, **kwargs):
            html = _figure_to_html(self)
            if html:
                plotly_html.append(html)
                captured_plotly_obj_ids.add(id(self))
            return None

        _pio.show = _capture_plotly_show
        _BaseFigure.show = _capture_basefigure_show
    except Exception:
        # Plotly is optional; proceed without monkeypatching if unavailable.
        pass
    
    try:
        # Redirect stdout/stderr
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = stdout_capture
        sys.stderr = stderr_capture
        
        # Execute code
        exec(compile(code, '<string>', 'exec'), restricted_globals, restricted_locals)
        
        # Capture any matplotlib figures
        figures = plt.get_fignums()
        for fig_num in figures:
            fig = plt.figure(fig_num)
            img_buffer = io.BytesIO()
            fig.savefig(img_buffer, format='png', bbox_inches='tight')
            img_buffer.seek(0)
            img_base64 = base64.b64encode(img_buffer.read()).decode('utf-8')
            images.append(img_base64)
            plt.close(fig)

        # Fallback Plotly capture: inspect variables for figure objects.
        seen_ids = set()
        for scope in (restricted_locals, restricted_globals):
            for value in scope.values():
                if not _is_plotly_figure(value):
                    continue
                obj_id = id(value)
                if obj_id in captured_plotly_obj_ids:
                    continue
                if obj_id in seen_ids:
                    continue
                seen_ids.add(obj_id)
                html = _figure_to_html(value)
                if html:
                    plotly_html.append(html)

        # Deduplicate exact HTML fragments while preserving order.
        deduped_plotly_html = []
        seen_html = set()
        for html in plotly_html:
            if html in seen_html:
                continue
            seen_html.add(html)
            deduped_plotly_html.append(html)
        
        result['success'] = True
        result['output'] = stdout_capture.getvalue()
        result['variables'] = {k: str(v)[:1000] for k, v in restricted_locals.items() 
                               if not k.startswith('_')}
        result['images'] = images
        result['plotly_html'] = deduped_plotly_html
        
    except SecurityError as e:
        result['error'] = f"Security violation: {str(e)}"
        logger.warning(f"Security violation in code execution: {e}")
    except Exception as e:
        result['error'] = traceback.format_exc()
        logger.error(f"Code execution error: {e}")
    finally:
        # Restore Plotly show behavior if it was patched.
        try:
            if original_pio_show is not None:
                import plotly.io as _pio
                _pio.show = original_pio_show
            if patched_basefigure_cls is not None and original_basefigure_show is not None:
                patched_basefigure_cls.show = original_basefigure_show
        except Exception:
            pass

        # Restore stdout/stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        
        # Close any remaining figures
        plt.close('all')
    
    result['execution_time'] = (datetime.now() - start_time).total_seconds()
    
    return result


def generate_visualization(code: str, output_format: str = 'png', timeout: int = 90) -> Dict[str, Any]:
    """
    Generate visualization from code.

    Args:
        code: Python code that generates plots
        output_format: Output format ('png', 'svg', 'pdf')
        timeout: Execution timeout in seconds (default 90 for intake/plot workloads)

    Returns:
        Dictionary with visualization data
    """
    result = execute_code_safely(code, timeout=timeout)
    
    if result['success'] and result['images']:
        return {
            'success': True,
            'images': result['images'],
            'format': output_format,
            'count': len(result['images'])
        }
    else:
        return {
            'success': False,
            'error': result.get('error', 'No visualization generated'),
            'output': result.get('output', '')
        }


def export_results(data: Any, format: str = 'json') -> str:
    """
    Export execution results to various formats.
    
    Args:
        data: Data to export
        format: Export format ('json', 'csv', 'txt')
    
    Returns:
        Exported data as string
    """
    import json
    import csv
    import io
    
    if format == 'json':
        return json.dumps(data, indent=2, default=str)
    elif format == 'csv':
        if isinstance(data, (list, tuple)) and len(data) > 0:
            output = io.StringIO()
            if isinstance(data[0], dict):
                writer = csv.DictWriter(output, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
            else:
                writer = csv.writer(output)
                writer.writerows(data)
            return output.getvalue()
        else:
            return str(data)
    else:
        return str(data)
