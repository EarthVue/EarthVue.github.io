"""
LLM-based dynamic classifier utilities.

This module provides `LLMClassifier`, a thin wrapper around an LLM used to
classify queries, assess response quality, extract reasoning steps, identify
uncertainties and biases, and generate recommendations or mitigation strategies.

Primary methods on `LLMClassifier`:
- classify_query_type(query): classify a user query (category, complexity, terms, data requirements).
- classify_response_quality(query, response, retrieved_docs=None): evaluate quality dimensions and produce JSON.
- identify_uncertainty_types(query, response): detect uncertainties present in a response.
- extract_reasoning_steps(query, response): extract the logical reasoning steps used by the model.
- identify_biases(query, response): detect possible biases in the response.
- generate_recommendations(query, response, issue_type): LLM-driven recommendations for improvement.
- generate_mitigation_strategies(uncertainty_type, query, response): propose mitigation actions.

All methods call the configured LLM and expect JSON-formatted outputs.
"""

import json
import logging
from typing import Dict, List, Any, Optional
from openai import AzureOpenAI
from dotenv import load_dotenv
import os

load_dotenv()

logger = logging.getLogger(__name__)


class LLMClassifier:
    """
    Dynamic LLM-based classifier for climate data queries and responses.
    Uses actual LLM prompts for all classifications instead of hardcoded values.
    """
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.client = AzureOpenAI(
            azure_endpoint=os.getenv("ENDPOINT_URL"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version="2025-01-01-preview"
        )
        # Prefer the correctly spelled env var, but gracefully fall back to
        # the legacy misspelled one so evaluation scripts and the UI share
        # the same classifier model configuration.
        self.deployment_name = (
            os.getenv("DEPLOYMENT_NAME")
            or os.getenv("DEPLOYMEN_NAME")
            or "gpt-4"
        )
        self.model_name = "gpt-4"

    def _extract_json_robustly(self, text: str) -> Any:
        """Helper to robustly extract JSON from LLM output."""
        if not text:
            return {}
            
        original_text = text.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = original_text.find('{')
            end = original_text.rfind('}')
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(original_text[start:end+1])
                except json.JSONDecodeError:
                    pass
            raise ValueError(f"Could not parse JSON from response")
    
    def classify_query_type(self, query: str) -> Dict[str, Any]:
        """
        Classify query into categories using LLM.
        Returns detailed classification with reasoning.
        
        Args:
            query: User's query text
            
        Returns:
            Dict with classification details
        """
        prompt = f"""Analyze this climate data query and classify it into ONE primary category and additional attributes.

Query: "{query}"

Respond in JSON format:
{{
    "primary_category": "one of: [data_access, analysis_request, explanation_request, code_generation, comparison, trend_analysis, visualization_request, general_inquiry]",
    "sub_categories": ["list of applicable sub-categories"],
    "complexity_score": <float 1.0 to 5.0> (1=beginner, 5=advanced expert based on technical depth),
    "technical_terms": ["list of identified technical terms"],
    "data_requirements": {{
        "datasets": ["expected datasets or null"],
        "temporal_scope": "historical|future|both|unspecified",
        "spatial_scope": "global|regional|local|unspecified",
        "variables": ["list of climate variables or null"]
    }},
    "reasoning": "Brief explanation of classification"
}}

Ensure response is valid JSON only."""

        try:
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert classifier for climate data science queries. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2000,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            # Extract JSON more robustly
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()
            
            try:
                classification = json.loads(result_text)
            except json.JSONDecodeError:
                start = result_text.find('{')
                end = result_text.rfind('}')
                if start != -1 and end != -1 and end > start:
                    classification = json.loads(result_text[start:end+1])
                else:
                    raise
                    
            return classification
            
        except Exception as e:
            logger.error(f"Error classifying query: {e}")
            return {
                "primary_category": "general_inquiry",
                "sub_categories": [],
                "complexity_score": 1.0,
                "technical_terms": [],
                "data_requirements": {},
                "reasoning": "Error in classification",
                "error": str(e)
            }
    
    def classify_response_quality(self, query: str, response: str, retrieved_docs: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Classify response quality dimensions using LLM evaluation.
        
        Args:
            query: Original user query
            response: AI-generated response
            retrieved_docs: Documents used for RAG
            
        Returns:
            Dict with quality assessment
        """
        doc_context = f"\nRetrieved {len(retrieved_docs)} documents" if retrieved_docs else "\nNo documents retrieved"
        
        prompt = f"""Evaluate the quality of this AI response to a climate data query.

Query: "{query}"

Response: "{response[:2000]}..."

{doc_context}

Respond in JSON format:
{{
    "quality_dimensions": {{
        "factual_accuracy": {{
            "score": 0.0-1.0,
            "assessment": "explanation",
            "evidence": ["specific examples from response"]
        }},
        "completeness": {{
            "score": 0.0-1.0,
            "assessment": "explanation",
            "missing_elements": ["what's missing"]
        }},
        "clarity": {{
            "score": 0.0-1.0,
            "assessment": "explanation"
        }},
        "technical_accuracy": {{
            "score": 0.0-1.0,
            "assessment": "explanation",
            "technical_issues": ["any issues found"]
        }},
        "relevance": {{
            "score": 0.0-1.0,
            "assessment": "explanation"
        }}
    }},
    "overall_quality": 0.0-1.0,
    "strengths": ["list of response strengths"],
    "weaknesses": ["list of response weaknesses"],
    "recommendations": ["suggestions for improvement"]
}}

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert evaluator of climate data science responses. Provide detailed quality assessments. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            assessment = self._extract_json_robustly(result_text)
            return assessment
            
        except Exception as e:
            logger.error(f"Error assessing response quality: {e}")
            return {
                "quality_dimensions": {},
                "overall_quality": 0.0,
                "error": str(e)
            }
    
    def identify_uncertainty_types(self, query: str, response: str) -> Dict[str, Any]:
        """
        Dynamically identify uncertainty types in the response.
        No hardcoded categories.
        
        Args:
            query: User query
            response: AI response
            
        Returns:
            Dict with identified uncertainties
        """
        prompt = f"""Analyze this response for sources and types of uncertainty.

Query: "{query}"

Response: "{response[:2000]}..."

Identify ALL types of uncertainty present. Be specific and grounded in the response content.

Respond in JSON format:
{{
    "uncertainties": [
        {{
            "type": "identified uncertainty type",
            "source": "where it comes from in the response",
            "description": "detailed description",
            "severity": "low|medium|high",
            "confidence_in_assessment": 0.0-1.0,
            "mitigation_strategies": ["how to address this uncertainty"],
            "evidence": ["specific text from response supporting this"]
        }}
    ],
    "overall_uncertainty_level": "low|medium|high",
    "uncertainty_summary": "overall assessment of response reliability given uncertainties"
}}

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in identifying and characterizing uncertainty in scientific responses. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            uncertainties = self._extract_json_robustly(result_text)
            return uncertainties
            
        except Exception as e:
            logger.error(f"Error identifying uncertainties: {e}")
            # Return a safe, structured fallback so callers can continue
            return {
                "uncertainties": [],
                "overall_uncertainty_level": "unknown",
                "uncertainty_summary": "Failed to parse LLM output",
                "error": str(e)
            }
            return {
                "uncertainties": [],
                "overall_uncertainty_level": "medium",
                "error": str(e)
            }
    
    def extract_reasoning_steps(self, query: str, response: str) -> Dict[str, Any]:
        """
        Extract the actual reasoning steps from response.
        
        Args:
            query: User query
            response: AI response
            
        Returns:
            Dict with extracted reasoning
        """
        prompt = f"""Extract the reasoning steps evident in this AI response.

Query: "{query}"

Response: "{response[:2000]}..."

Identify the logical steps the AI took to generate this response. Go beyond surface-level.

Respond in JSON format:
{{
    "reasoning_steps": [
        {{
            "step_number": 1,
            "category": "query_analysis|knowledge_retrieval|planning|execution|validation|synthesis",
            "action": "what was done",
            "reasoning": "why it was done",
            "inputs_used": ["what information was used"],
            "outputs_generated": ["what was produced"],
            "confidence": 0.0-1.0,
            "depends_on": []
        }}
    ],
    "overall_reasoning_quality": "poor|fair|good|excellent",
    "logical_coherence": 0.0-1.0,
    "gaps_in_reasoning": ["identified gaps"]
}}

For each step, include "depends_on" as an array of prior step_number values when that step combines or relies on multiple earlier steps; use [] or omit when the flow is a simple linear sequence.

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert at analyzing and extracting reasoning processes from AI-generated text. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            reasoning = self._extract_json_robustly(result_text)
            return reasoning
            
        except Exception as e:
            logger.error(f"Error extracting reasoning: {e}")
            return {
                "reasoning_steps": [],
                "error": str(e)
            }
    
    def analyze_dataset_selection(self, query: str, response: str) -> Dict[str, Any]:
        """
        Analyze the logic behind dataset selection using the LLM.
        """
        prompt = f"""Analyze the dataset selection logic in this AI response.

Query: "{query}"

Response: "{response[:2000]}..."

Return a JSON object containing:
{{
    "primary_factors": [
        {{
            "factor": "e.g., Geographic Scope, Temporal Resolution, Variable availability",
            "value": "e.g., Global, Daily, tasmax",
            "weight": 0.0-1.0
        }}
    ],
    "constraints_considered": ["list of constraints mentioned or implied"],
    "alternatives_evaluated": ["list of alternative datasets considered"],
    "recommendation_confidence": 0.0-1.0
}}

Ensure response is valid JSON only."""

        try:
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert at analyzing dataset selection logic in climate data discussions. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=1500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            return self._extract_json_robustly(result_text)
            
        except Exception as e:
            logger.error(f"Error analyzing dataset selection: {e}")
            return {
                "primary_factors": [],
                "constraints_considered": [],
                "alternatives_evaluated": [],
                "recommendation_confidence": 0.0,
                "error": str(e)
            }
            
    def identify_biases(self, query: str, response: str) -> Dict[str, Any]:
        """
        Identify potential biases in the response.
        
        Args:
            query: User query
            response: AI response
            
        Returns:
            Dict with identified biases
        """
        prompt = f"""Identify potential biases in this climate data response.

Query: "{query}"

Response: "{response[:2000]}..."

Look for: geographic bias, temporal bias, dataset bias, methodological bias, demographic bias.

Respond in JSON format:
{{
    "identified_biases": [
        {{
            "type": "bias category",
            "description": "what bias was detected",
            "severity": "low|medium|high",
            "evidence": ["specific examples from response"],
            "impact": "how this affects response reliability",
            "recommendations": ["how to mitigate"]
        }}
    ],
    "overall_bias_assessment": "low|medium|high",
    "balance_assessment": "assessment of perspective balance"
}}

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert at identifying biases in scientific and technical responses. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content
            biases = self._extract_json_robustly(result_text)
            return biases
            
        except Exception as e:
            logger.error(f"Error identifying biases: {e}")
            return {
                "identified_biases": [],
                "error": str(e)
            }
    
    def generate_recommendations(self, query: str, response: str, issue_type: str) -> Dict[str, Any]:
        """
        Generate LLM-based recommendations for quality improvements.
        
        Args:
            query: User query
            response: AI response
            issue_type: Type of issue to recommend for (quality, bias, uncertainty, etc.)
            
        Returns:
            Dict with recommendations
        """
        prompt = f"""Based on this climate data query and response, generate specific, actionable recommendations to improve the response.

Query: "{query}"

Response: "{response[:2000]}..."

Issue Type: {issue_type}

Respond in JSON format:
{{
    "recommendations": [
        {{
            "recommendation": "specific improvement suggestion",
            "rationale": "why this would improve the response",
            "implementation": "how to implement this",
            "priority": "high|medium|low"
        }}
    ],
    "summary": "brief overall improvement summary"
}}

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in climate data science. Generate practical, specific recommendations for improvement. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content.strip() if api_response.choices[0].message.content else ""
            recommendations = self._extract_json_robustly(result_text)
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {e}")
            return {
                "recommendations": [],
                "error": str(e)
            }
    
    def generate_mitigation_strategies(self, uncertainty_type: str, query: str, response: str) -> List[str]:
        """
        Generate LLM-based mitigation strategies for uncertainties.
        
        Args:
            uncertainty_type: Type of uncertainty
            query: User query
            response: AI response
            
        Returns:
            List of mitigation strategies
        """
        prompt = f"""Generate 2-3 specific mitigation strategies for this {uncertainty_type} uncertainty in a climate data response.

Query: "{query}"

Response: "{response[:1500]}..."

Respond in JSON format:
{{
    "strategies": ["strategy 1", "strategy 2", "strategy 3"]
}}

Ensure response is valid JSON only."""

        try:
            response_text = response[:3000] if len(response) > 3000 else response
            
            api_response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in uncertainty quantification in climate science. Generate practical mitigation strategies. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.2,
                max_tokens=2500,
                response_format={"type": "json_object"}
            )
            
            result_text = api_response.choices[0].message.content.strip() if api_response.choices[0].message.content else ""
            strategies = self._extract_json_robustly(result_text)
            return strategies.get('strategies', [])
            
        except Exception as e:
            logger.error(f"Error generating mitigation strategies: {e}")
            return []
