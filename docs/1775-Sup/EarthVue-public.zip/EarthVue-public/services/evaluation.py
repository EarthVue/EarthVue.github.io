"""
AI Reasoning & Uncertainty Evaluation using TruLens and RAGAS.

This module provides structured evaluation of model responses for the climate
data domain. It returns an `EvaluationResult` with reasoning steps,
confidence scores, uncertainty identifications, quality metrics, bias
indicators, dataset-selection logic, provenance, and model parameters.

Primary symbols:
- EvaluationResult: dataclass holding structured evaluation outputs.
- ClimateDataEvaluator: orchestrates evaluation using optional TruLens,
  RAGAS, and the `LLMClassifier` for dynamic reasoning and uncertainty
  extraction. Key methods include:
  - __init__(api_key=None, enable_trulens=True): initialize evaluator.
  - evaluate_response(user_query, response_content, retrieved_docs=None, processing_time_ms=0): return an `EvaluationResult`.
  - _extract_reasoning_steps(...): extract reasoning steps via LLMClassifier.
  - _calculate_confidence(...): compute confidence dimensions.
  - _identify_uncertainties(...): identify uncertainties using LLMClassifier.
  - _assess_quality(...): compute quality scores (coherence, accuracy, completeness).
  - _detect_biases(...): detect potential biases.
  - _analyze_dataset_selection(...): analyze dataset-selection logic.
  - _build_provenance_chain(...): collect provenance from retrieved docs.
  - _get_model_parameters(): return current model/provenance config.

The implementation prefers dynamic LLM-based analysis and falls back to
lightweight heuristics if optional dependencies are not available.
"""

import json
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
from functools import wraps

try:
    from trulens_eval import Tru, Feedback
    from trulens_eval.feedback.provider import OpenAI
    TRULENS_AVAILABLE = True
except ImportError:
    TRULENS_AVAILABLE = False
    logging.warning("TruLens not available. Install with: pip install trulens-eval")

try:
    from ragas import evaluate
    from ragas.metrics import context_precision, context_recall, faithfulness, answer_relevancy
    RAGAS_AVAILABLE = True
except ImportError:
    RAGAS_AVAILABLE = False
    logging.warning("RAGAS not available. Install with: pip install ragas")

logger = logging.getLogger(__name__)


@dataclass
class EvaluationResult:
    """Structured evaluation result"""
    reasoning_steps: List[Dict[str, Any]]
    confidence_scores: Dict[str, float]
    uncertainty_factors: List[Dict[str, Any]]
    quality_scores: Dict[str, float]
    bias_indicators: List[Dict[str, Any]]
    dataset_selection_logic: Dict[str, Any]
    provenance: List[Dict[str, Any]]
    processing_time_ms: int
    retrieved_documents: List[str]
    model_parameters: Dict[str, Any]
    timestamp: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), default=str)


class ClimateDataEvaluator:
    """
    Evaluator for climate data-related responses using TruLens, RAGAS, and LLM-based classification.
    Provides real evaluation instead of hardcoded values.
    """
    
    def __init__(self, api_key: Optional[str] = None, enable_trulens: bool = True):
        """
        Initialize evaluator.
        
        Args:
            api_key: Azure OpenAI API key for evaluation
            enable_trulens: Whether to use TruLens for evaluation
        """
        self.enable_trulens = enable_trulens and TRULENS_AVAILABLE
        self.enable_ragas = RAGAS_AVAILABLE
        self.provider = None
        self.feedback_functions = {}
        self.tru = None
        
        # Import and initialize LLM classifier for dynamic classification
        try:
            from services.llm_classifier import LLMClassifier
            self.classifier = LLMClassifier()
        except Exception as e:
            logger.error(f"Failed to initialize LLM classifier: {e}")
            self.classifier = None
        
        if self.enable_trulens:
            self._setup_trulens(api_key)
            self._setup_feedback_functions()
    
    def _setup_trulens(self, api_key: Optional[str]):
        """Initialize TruLens session"""
        try:
            from trulens_eval import Tru
            self.tru = Tru()
            logger.info("TruLens initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize TruLens: {e}")
            self.enable_trulens = False
    
    def _setup_feedback_functions(self):
        """Setup TruLens feedback functions for climate domain"""
        if not self.enable_trulens:
            return
        
        try:
            self.provider = OpenAI()
            
            # Relevance feedback
            self.feedback_functions['relevance'] = (
                Feedback(
                    self.provider.relevance_with_cot_reasons,
                    name="Dataset Relevance"
                )
            )
            
            logger.info("Feedback functions initialized")
        except Exception as e:
            logger.error(f"Failed to setup feedback functions: {e}")
    
    def evaluate_response(
        self,
        user_query: str,
        response_content: str,
        retrieved_docs: Optional[List[str]] = None,
        processing_time_ms: int = 0
    ) -> EvaluationResult:
        """
        Evaluate AI response with real metrics.
        
        Args:
            user_query: Original user query
            response_content: AI-generated response
            retrieved_docs: Documents used for RAG
            processing_time_ms: Time taken to generate response
        
        Returns:
            EvaluationResult with actual evaluation metrics
        """
        reasoning_steps = self._extract_reasoning_steps(user_query, response_content)
        confidence_scores = self._calculate_confidence(response_content, retrieved_docs)
        uncertainty_factors = self._identify_uncertainties(user_query, response_content, retrieved_docs)
        quality_scores = self._assess_quality(response_content, user_query, retrieved_docs)
        bias_indicators = self._detect_biases(user_query, response_content, retrieved_docs)
        dataset_logic = self._analyze_dataset_selection(user_query, response_content)
        provenance = self._build_provenance_chain(response_content, retrieved_docs)
        model_params = self._get_model_parameters()
        
        return EvaluationResult(
            reasoning_steps=reasoning_steps,
            confidence_scores=confidence_scores,
            uncertainty_factors=uncertainty_factors,
            quality_scores=quality_scores,
            bias_indicators=bias_indicators,
            dataset_selection_logic=dataset_logic,
            provenance=provenance,
            processing_time_ms=processing_time_ms,
            retrieved_documents=retrieved_docs or [],
            model_parameters=model_params,
            timestamp=datetime.now().isoformat()
        )
    
    def _extract_reasoning_steps(
        self,
        user_query: str,
        response_content: str
    ) -> List[Dict[str, Any]]:
        """
        Extract reasoning steps using LLM classifier.
        Dynamic extraction based on LLM analysis.
        """
        # Use LLM classifier for dynamic reasoning extraction
        if self.classifier:
            try:
                llm_reasoning = self.classifier.extract_reasoning_steps(user_query, response_content)
                if 'reasoning_steps' in llm_reasoning:
                    return llm_reasoning.get('reasoning_steps', [])
            except Exception as e:
                logger.error(f"LLM reasoning extraction failed: {e}")
        
        # No classifier available - return empty list instead of hardcoded patterns
        logger.warning("LLMClassifier not available; no reasoning steps extracted")
        return []
    
    def _calculate_confidence(
        self,
        response_content: str,
        retrieved_docs: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """Calculate confidence scores based on real indicators using LLM judge"""
        # We rely on the LLM classifier to assess confidence metrics rather than hardcoded heuristics.
        if self.classifier:
            try:
                llm_assessment = self.classifier.classify_response_quality("confidence evaluation", response_content, retrieved_docs)
                if 'quality_dimensions' in llm_assessment:
                    dims = llm_assessment['quality_dimensions']
                    return {
                        'factual_grounding': dims.get('factual_accuracy', {}).get('score', 0.0),
                        'technical_accuracy': dims.get('technical_accuracy', {}).get('score', 0.0),
                        'completeness': dims.get('completeness', {}).get('score', 0.0),
                        'dataset_appropriateness': dims.get('relevance', {}).get('score', 0.0),
                        'clarity': dims.get('clarity', {}).get('score', 0.0),
                        'overall': llm_assessment.get('overall_quality', 0.0)
                    }
            except Exception as e:
                logger.error(f"LLM confidence calculation failed: {e}")
        
        # Safe fallback if LLM is unavailable
        return {
            'factual_grounding': 0.0,
            'technical_accuracy': 0.0,
            'completeness': 0.0,
            'dataset_appropriateness': 0.0,
            'clarity': 0.0,
            'overall': 0.0
        }
    
    def _identify_uncertainties(
        self,
        user_query: str,
        response_content: str,
        retrieved_docs: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Identify real sources of uncertainty using LLM classifier."""
        # Use LLM classifier for dynamic identification
        if self.classifier:
            try:
                llm_uncertainties = self.classifier.identify_uncertainty_types(user_query, response_content)
                if 'uncertainties' in llm_uncertainties:
                    uncertainties = llm_uncertainties.get('uncertainties', [])
                    
                    # Generate mitigation strategies using LLM for each uncertainty
                    for uncertainty in uncertainties:
                        if 'mitigation_strategy' not in uncertainty or not uncertainty.get('mitigation_strategy'):
                            strategies = self.classifier.generate_mitigation_strategies(
                                uncertainty_type=uncertainty.get('type', 'unknown'),
                                query=user_query,
                                response=response_content
                            )
                            uncertainty['mitigation_strategy'] = '; '.join(strategies) if strategies else 'Monitor closely'
                    
                    return uncertainties
            except Exception as e:
                logger.error(f"LLM uncertainty identification failed: {e}")
        
        # No classifier available - return empty list instead of hardcoded fallbacks
        logger.warning("LLMClassifier not available; no uncertainties identified")
        return []
    
    def _assess_quality(
        self,
        response_content: str,
        user_query: str,
        retrieved_docs: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """Assess multiple dimensions of response quality using LLM judge"""
        if self.classifier:
            try:
                llm_assessment = self.classifier.classify_response_quality(user_query, response_content, retrieved_docs)
                if 'quality_dimensions' in llm_assessment:
                    dims = llm_assessment['quality_dimensions']
                    return {
                        'coherence': dims.get('clarity', {}).get('score', 0.0),
                        'accuracy': dims.get('factual_accuracy', {}).get('score', 0.0),
                        'completeness': dims.get('completeness', {}).get('score', 0.0),
                        'specificity': dims.get('relevance', {}).get('score', 0.0),
                        'documentation': dims.get('technical_accuracy', {}).get('score', 0.0)
                    }
            except Exception as e:
                logger.error(f"LLM quality assessment failed: {e}")
        
        # Fallback if LLM fails
        return {
            'coherence': 0.0,
            'accuracy': 0.0,
            'completeness': 0.0,
            'specificity': 0.0,
            'documentation': 0.0
        }
    
    def _detect_biases(
        self,
        user_query: str,
        response_content: str,
        retrieved_docs: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Detect potential biases using LLM classifier."""
        # Use LLM classifier for dynamic bias identification
        if self.classifier:
            try:
                llm_biases = self.classifier.identify_biases(user_query, response_content)
                if 'identified_biases' in llm_biases:
                    biases = llm_biases.get('identified_biases', [])
                    
                    # Generate recommendations using LLM for each bias
                    for bias in biases:
                        if 'recommendation' not in bias or not bias.get('recommendation'):
                            recommendations = self.classifier.generate_recommendations(
                                query=user_query,
                                response=response_content,
                                issue_type=bias.get('type', 'bias')
                            )
                            if recommendations.get('recommendations'):
                                bias['recommendation'] = recommendations['recommendations'][0].get('recommendation', 'Review response carefully')
                    
                    return biases
            except Exception as e:
                logger.error(f"LLM bias identification failed: {e}")
        
        # No classifier available - return empty list instead of hardcoded patterns
        logger.warning("LLMClassifier not available; no biases identified")
        return []
    
    def _analyze_dataset_selection(
        self,
        user_query: str,
        response_content: str
    ) -> Dict[str, Any]:
        """Analyze reasoning behind dataset selection using LLM classifier."""
        # Use LLM classifier to truly analyze the selection logic
        if self.classifier:
            try:
                llm_analysis = self.classifier.analyze_dataset_selection(user_query, response_content)
                if 'primary_factors' in llm_analysis:
                    return llm_analysis
            except Exception as e:
                logger.error(f"LLM dataset analysis failed: {e}")
        
        # Safe fallback without assuming arbitrary variables
        return {
            'primary_factors': [],
            'constraints_considered': [],
            'alternatives_evaluated': [],
            'recommendation_confidence': 0.0
        }
    
    def _build_provenance_chain(
        self,
        response_content: str,
        retrieved_docs: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Build provenance chain showing response generation steps"""
        chain = []
        
        chain.append({
            'step': 1,
            'type': 'input_received',
            'description': 'User query received and processed',
            'timestamp': datetime.now().isoformat()
        })
        
        if retrieved_docs:
            chain.append({
                'step': 2,
                'type': 'retrieval',
                'description': f"Retrieved {len(retrieved_docs)} documents from knowledge base",
                'documents_count': len(retrieved_docs),
                'timestamp': datetime.now().isoformat()
            })
        
        chain.append({
            'step': 3 if retrieved_docs else 2,
            'type': 'analysis',
            'description': 'Response generated using language model',
            'timestamp': datetime.now().isoformat()
        })
        
        chain.append({
            'step': 4 if retrieved_docs else 3,
            'type': 'quality_check',
            'description': 'Response quality validated',
            'timestamp': datetime.now().isoformat()
        })
        
        return chain
    
    def _get_model_parameters(self) -> Dict[str, Any]:
        """Get current model configuration"""
        return {
            'model': 'azure-openai',
            'temperature': 0.2,
            'max_tokens': 2000,
            'top_p': 0.95,
            'frequency_penalty': 0.0,
            'presence_penalty': 0.0,
            'search_enabled': True,
            'search_documents': 5
        }
    
    # Helper methods

def with_evaluation(evaluator: Optional[ClimateDataEvaluator] = None):
    """
    Decorator to add evaluation to any response-generating function.
    
    Usage:
        @with_evaluation()
        def my_chat_function(query):
            return response
    """
    if evaluator is None:
        evaluator = ClimateDataEvaluator()
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            
            # Expect result to be a dict with query, response, docs
            if isinstance(result, dict):
                user_query = result.get('query', '')
                response = result.get('response', '')
                docs = result.get('retrieved_docs', [])
                processing_time = result.get('processing_time_ms', 0)
                
                # Run evaluation
                evaluation = evaluator.evaluate_response(
                    user_query=user_query,
                    response_content=response,
                    retrieved_docs=docs,
                    processing_time_ms=processing_time
                )
                
                result['evaluation'] = evaluation.to_dict()
            
            return result
        
        return wrapper
    
    return decorator
