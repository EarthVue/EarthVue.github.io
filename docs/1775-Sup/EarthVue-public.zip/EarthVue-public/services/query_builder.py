"""
AI-powered query builder for constructing structured queries visually.
"""

import json
import logging
from typing import Dict, List, Optional, Any
from services.langchain_client import chat_non_streaming, get_llm_for

logger = logging.getLogger(__name__)


class QueryBuilder:
    """AI-powered query builder for climate data queries"""
    
    def __init__(self):
        self.query_templates = {
            'dataset_exploration': {
                'name': 'Dataset Exploration',
                'description': 'Explore available datasets and their variables',
                'example': 'What datasets are available for temperature data?'
            },
            'model_comparison': {
                'name': 'Model Comparison',
                'description': 'Compare different climate models',
                'example': 'Compare temperature projections between CMIP6 models'
            },
            'trend_analysis': {
                'name': 'Trend Analysis',
                'description': 'Analyze trends over time',
                'example': 'Show temperature trends for California from 2020 to 2050'
            },
            'spatial_analysis': {
                'name': 'Spatial Analysis',
                'description': 'Analyze data for specific regions',
                'example': 'What is the average precipitation in Southeast Asia?'
            },
            'anomaly_detection': {
                'name': 'Anomaly Detection',
                'description': 'Find anomalies or extreme events',
                'example': 'Find temperature anomalies in 2023'
            },
            'data_access': {
                'name': 'Data Access',
                'description': 'Get code to access specific data',
                'example': 'How do I access CMIP6 temperature data using Python?'
            }
        }
    
    def suggest_query_structure(self, natural_language_query: str) -> Dict[str, Any]:
        """
        Convert natural language query to structured query format.
        
        Args:
            natural_language_query: User's natural language query
        
        Returns:
            Structured query dictionary
        """
        prompt = f"""Convert this natural language query about climate data into a structured format.

Query: "{natural_language_query}"

Return a JSON object with:
- intent: one of [dataset_exploration, model_comparison, trend_analysis, spatial_analysis, anomaly_detection, data_access]
- variables: list of climate variables mentioned (e.g., ['temperature', 'precipitation'])
- models: list of climate models mentioned (e.g., ['CMIP6', 'LOCA'])
- scenarios: list of scenarios mentioned (e.g., ['ssp585', 'ssp245'])
- temporal_range: dict with 'start' and 'end' years if mentioned
- spatial_region: string describing geographic region if mentioned
- complexity: integer 1-5 indicating query complexity
- suggested_query: improved version of the query

Respond with ONLY valid JSON, no markdown, no code blocks."""
        
        try:
            llm = get_llm_for(deployment_name=None, preferred_temperature=0.1)
            messages = [
                {"role": "system", "content": "You are a query structuring assistant. Always respond with ONLY valid JSON."},
                {"role": "user", "content": prompt}
            ]
            response = chat_non_streaming(messages, temperature=0.1, max_tokens=500)
            
            # Clean response
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.startswith("```"):
                response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()
            
            # Find JSON
            start_idx = response.find('{')
            end_idx = response.rfind('}')
            if start_idx != -1 and end_idx != -1:
                structured = json.loads(response[start_idx:end_idx+1])
                return structured
        except Exception as e:
            logger.error(f"Query structuring failed: {e}")
        
        # Fallback
        return {
            'intent': 'general',
            'variables': [],
            'models': [],
            'scenarios': [],
            'temporal_range': None,
            'spatial_region': None,
            'complexity': 2,
            'suggested_query': natural_language_query
        }
    
    def generate_query_suggestions(self, partial_query: str, context: Optional[List[Dict]] = None) -> List[str]:
        """
        Generate query suggestions based on partial input.
        
        Args:
            partial_query: Partial query text
            context: Optional conversation context
        
        Returns:
            List of suggested queries
        """
        context_str = ""
        if context:
            recent = context[-3:] if len(context) > 3 else context
            context_str = "\nRecent conversation:\n"
            for msg in recent:
                if isinstance(msg, dict):
                    context_str += f"- {msg.get('role', 'user')}: {msg.get('content', '')[:100]}\n"
        
        prompt = f"""Generate 3-5 query suggestions for a climate data exploration system.

Partial query: "{partial_query}"
{context_str}

Suggestions should be:
- Specific and actionable
- Related to climate datasets (CMIP6, LOCA, etc.)
- Varied in complexity
- Helpful follow-ups or completions

Return JSON array of strings: ["suggestion1", "suggestion2", ...]"""
        
        try:
            llm = get_llm_for(deployment_name=None, preferred_temperature=0.3)
            messages = [
                {"role": "system", "content": "You are a helpful assistant. Return ONLY a JSON array of strings."},
                {"role": "user", "content": prompt}
            ]
            response = chat_non_streaming(messages, temperature=0.3, max_tokens=300)
            
            # Clean and parse
            response = response.strip()
            start_idx = response.find('[')
            end_idx = response.rfind(']')
            if start_idx != -1 and end_idx != -1:
                suggestions = json.loads(response[start_idx:end_idx+1])
                if isinstance(suggestions, list):
                    return suggestions[:5]  # Limit to 5
        except Exception as e:
            logger.error(f"Query suggestion generation failed: {e}")
        
        # Fallback suggestions
        return [
            "What datasets are available for temperature analysis?",
            "How do I access CMIP6 data using Python?",
            "Compare temperature projections between different models"
        ]
    
    def get_query_templates(self) -> Dict[str, Dict]:
        """Get available query templates"""
        return self.query_templates
    
    def build_query_from_template(self, template_name: str, parameters: Dict[str, Any]) -> str:
        """
        Build a query from a template with parameters.
        
        Args:
            template_name: Name of the template
            parameters: Parameters to fill in
        
        Returns:
            Complete query string
        """
        template = self.query_templates.get(template_name)
        if not template:
            return ""
        
        # Use LLM to fill template
        prompt = f"""Fill in this query template with the provided parameters.

Template: {template['example']}
Parameters: {json.dumps(parameters)}

Generate a complete, natural language query."""
        
        try:
            llm = get_llm_for(deployment_name=None, preferred_temperature=0.2)
            messages = [
                {"role": "user", "content": prompt}
            ]
            query = chat_non_streaming(messages, temperature=0.2, max_tokens=200)
            return query.strip()
        except Exception as e:
            logger.error(f"Template filling failed: {e}")
            return template['example']
    
    def validate_query(self, query: str) -> Dict[str, Any]:
        """
        Validate a query and provide feedback.
        
        Args:
            query: Query to validate
        
        Returns:
            Validation result with feedback
        """
        if not query or len(query.strip()) < 3:
            return {
                'valid': False,
                'feedback': 'Query is too short. Please provide more details.',
                'suggestions': []
            }
        
        # Check for common issues
        issues = []
        suggestions = []
        
        query_lower = query.lower()
        
        # Check if query is too vague
        vague_indicators = ['data', 'information', 'stuff', 'things']
        if any(indicator in query_lower for indicator in vague_indicators) and len(query.split()) < 5:
            issues.append('Query may be too vague')
            suggestions.append('Try specifying: what variable, which model, what time period, or what region?')
        
        # Check if query mentions climate-related terms
        climate_terms = ['temperature', 'precipitation', 'climate', 'cmip6', 'model', 'scenario', 'variable']
        if not any(term in query_lower for term in climate_terms):
            issues.append('Query may not be related to climate data')
            suggestions.append('Try mentioning climate variables, models, or datasets')
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'suggestions': suggestions,
            'complexity': self._estimate_complexity(query)
        }
    
    def _estimate_complexity(self, query: str) -> int:
        """Estimate query complexity (1-5)"""
        complexity = 1
        
        # More words = higher complexity
        word_count = len(query.split())
        if word_count > 20:
            complexity += 1
        
        # Multiple variables/models = higher complexity
        if query.lower().count(' and ') > 0 or query.lower().count('compare') > 0:
            complexity += 1
        
        # Code generation = higher complexity
        if any(term in query.lower() for term in ['code', 'python', 'how to', 'access', 'retrieve']):
            complexity += 1
        
        # Analysis terms = higher complexity
        if any(term in query.lower() for term in ['analyze', 'calculate', 'trend', 'anomaly', 'correlation']):
            complexity += 1
        
        return min(5, complexity)
