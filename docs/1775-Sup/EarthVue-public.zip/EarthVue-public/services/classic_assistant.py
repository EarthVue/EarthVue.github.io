"""
Classic assistant helper functions.

This module provides utilities used by `app.py` to handle dataset previews,
accessibility analytics, user profiles, AI reasoning tracking, and on-the-fly
code generation via a retrieval-augmented LLM.

Functions:
- track_data_access_event(db, DataAccessEvent, user_id, session_uuid, query_text, datasets_found=None, success_score=None):
    Record user data access interactions for accessibility research.
- calculate_query_complexity(db, query_text):
    Compute a 1-5 complexity score for a user query (LLM-based fallback).
- identify_accessibility_barriers(db, query_text, datasets_found):
    Identify accessibility barriers from a query using an LLM classifier.
- update_user_expertise(db, UserExpertiseProfile, user_id, successful_query=None, dataset_used=None):
    Update or create a user's expertise profile based on interactions.
- track_ai_reasoning(db, AIReasoningTrace, AIUncertaintyEvent, ...):
    Persist AI reasoning traces, uncertainties, provenance and evaluation metrics.
- generate_dataset_preview(dataset_info, preview_type, expertise_level):
    Use RAG+LLM to produce adaptive dataset previews and full runnable code.
- generate_spatial_viz_code(dataset_name, expertise_level):
    Generate spatial visualization code (full script) via the LLM (with safe fallback).
- generate_temporal_viz_code(dataset_name, expertise_level):
    Generate temporal visualization code (full script) via the LLM (with safe fallback).
- generate_sampling_code(dataset_name, expertise_level):
    Generate sampling/example extraction code (full script) via the LLM (with safe fallback).
- run_code(code, globals_map=None):
    Execute provided Python code in a minimal sandbox and capture output/images.
- generate_adaptive_query_suggestions(partial_query, expertise_level, profile):
    Produce adaptive query suggestions tailored to user expertise.
- get_complexity_hints(expertise_level):
    Return short hints about query complexity for the UI.
"""
import json
import logging
from datetime import datetime
from collections import defaultdict
import os

from services.langchain_client import chat_with_retrieval, chat_non_streaming, get_model_config

logger = logging.getLogger(__name__)

# -- Data access tracking ---------------------------------------------------

def track_data_access_event(db, DataAccessEvent, user_id, session_uuid, query_text, datasets_found=None, success_score=None, model=None):
    """Track user data access patterns for accessibility research"""
    try:
        event = DataAccessEvent(
            user_id=user_id,
            session_uuid=session_uuid,
            query_text=query_text,
            datasets_mentioned=json.dumps(datasets_found or []),
            model_used=(model or None),
            success_score=success_score,
            complexity_level=calculate_query_complexity(db, query_text),
            accessibility_barriers=json.dumps(identify_accessibility_barriers(db, query_text, datasets_found))
        )
        db.session.add(event)
        db.session.commit()
        return event
    except Exception as e:
        print(f"Error tracking data access event: {e}")
        return None

# -- Query complexity & accessibility -------------------------------------

def calculate_query_complexity(db, query_text):
    """
    Calculate complexity score (1-5) using LLM classifier if available.
    Falls back to simple 1 if classifier unavailable.
    """
    try:
        from services.llm_classifier import LLMClassifier
        classifier = LLMClassifier()
        classification = classifier.classify_query_type(query_text)

        return float(classification.get('complexity_score', 1.0))
    except Exception as e:
        logger.warning(f"LLM complexity calculation failed, returning default: {e}")
        return 1


def identify_accessibility_barriers(db, query_text, datasets_found):
    """
    Identify accessibility barriers using LLM analysis. Returns empty list if classifier unavailable.
    """
    try:
        from services.llm_classifier import LLMClassifier
        classifier = LLMClassifier()
        classification = classifier.classify_query_type(query_text)

        barriers = []
        if not datasets_found:
            barriers.append("no_datasets_found")

        technical_terms = classification.get('technical_terms', [])
        if technical_terms and not datasets_found:
            barriers.append("technical_jargon")

        return barriers
    except Exception as e:
        logger.warning(f"LLM barrier identification failed: {e}")
        return []

# -- User expertise profile update ----------------------------------------

def update_user_expertise(db, UserExpertiseProfile, user_id, successful_query=None, dataset_used=None):
    """Update user expertise profile based on successful interactions"""
    try:
        from services.analytics_service import analyze_with_llm
        profile = UserExpertiseProfile.query.filter_by(user_id=user_id).first()
        if not profile:
            profile = UserExpertiseProfile(user_id=user_id)
            db.session.add(profile)

        if profile.expertise_level is None:
            profile.expertise_level = 1.0

        if successful_query:
            prompt = f"""A user with current climate data expertise level {profile.expertise_level:.1f} (scale 1.0 to 5.0) just successfully executed this query:
"{successful_query}"

Analyze the technical complexity of this query (use of xarray, specific climate variables, spatial/temporal logic).
Determine their new expertise level. It should gradually increase if the query demonstrates advanced knowledge, or stay the same if it's basic.

Return JSON:
{{
    "new_expertise_level": <float 1.0 to 5.0>,
    "reasoning": "brief explanation"
}}"""
            result = analyze_with_llm(prompt)
            new_level = result.get("new_expertise_level")
            if isinstance(new_level, (int, float)) and 1.0 <= new_level <= 5.0:
                profile.expertise_level = float(new_level)

        if dataset_used:
            prefs = json.loads(profile.preferred_datasets or '[]')
            if dataset_used not in prefs:
                prefs.insert(0, dataset_used)
                profile.preferred_datasets = json.dumps(prefs[:10])

        profile.last_updated = datetime.now()
        db.session.commit()
        return profile
    except Exception as e:
        print(f"Error updating user expertise: {e}")
        return None

# -- AI reasoning tracking -------------------------------------------------

def track_ai_reasoning(db, AIReasoningTrace, AIUncertaintyEvent, UserModel, ChatSessionModel, user_id, session_uuid, user_query, response_content, retrieved_docs=None, processing_time_ms=0, evaluator=None):
    """Capture comprehensive AI reasoning trace using real evaluation metrics"""
    try:
        if evaluator is None:
            from services.evaluation import ClimateDataEvaluator
            evaluator = ClimateDataEvaluator()

        evaluation = evaluator.evaluate_response(
            user_query=user_query,
            response_content=response_content,
            retrieved_docs=retrieved_docs or [],
            processing_time_ms=processing_time_ms
        )

        # Ensure referenced ChatSession exists to satisfy FK constraint on session_uuid
        try:
            # Verify user exists
            user_obj = UserModel.query.get(user_id)
            if not user_obj:
                logger.error(f"track_ai_reasoning: user_id {user_id} not found; aborting trace insertion")
                return None

            cs = ChatSessionModel.query.filter_by(session_uuid=session_uuid).first()
            if not cs:
                # Create a lightweight ChatSession record so FK constraints are satisfied
                cs = ChatSessionModel(session_uuid=session_uuid, user_id=user_id)
                db.session.add(cs)
                db.session.commit()
        except Exception as e:
            logger.warning(f"Could not ensure ChatSession exists: {e}")

        reasoning_trace = AIReasoningTrace(
            session_uuid=session_uuid,
            user_id=user_id,
            user_query=user_query,
            reasoning_steps=json.dumps(evaluation.reasoning_steps),
            dataset_selection_logic=json.dumps(evaluation.dataset_selection_logic),
            confidence_scores=json.dumps(evaluation.confidence_scores),
            uncertainty_factors=json.dumps(evaluation.uncertainty_factors),
            retrieved_documents=json.dumps(evaluation.retrieved_documents),
            model_parameters=json.dumps(evaluation.model_parameters),
            processing_time_ms=processing_time_ms,
            response_coherence_score=evaluation.quality_scores.get('coherence', 0.0),
            factual_accuracy_score=evaluation.quality_scores.get('accuracy', 0.0),
            completeness_score=evaluation.quality_scores.get('completeness', 0.0),
            bias_indicators=json.dumps(evaluation.bias_indicators)
        )

        db.session.add(reasoning_trace)
        db.session.commit()

        for uncertainty in evaluation.uncertainty_factors:
            uncertainty_event = AIUncertaintyEvent(
                reasoning_trace_id=reasoning_trace.id,
                uncertainty_type=uncertainty.get('type', 'unknown'),
                uncertainty_source=uncertainty.get('description', ''),
                confidence_level=uncertainty.get('confidence_level', 0.0),
                impact_assessment=uncertainty.get('impact_assessment', 'medium'),
                mitigation_strategy=uncertainty.get('mitigation_strategy', ''),
                user_notified=uncertainty.get('user_notified', False)
            )
            db.session.add(uncertainty_event)

        db.session.commit()
        return reasoning_trace

    except Exception as e:
        print(f"Error tracking AI reasoning: {e}")
        return None

# -- Dataset preview & code generation ------------------------------------

def generate_dataset_preview(dataset_info, preview_type, expertise_level):
    """Generate adaptive dataset previews based on user expertise"""
    # Use RAG-enabled LLM to generate a tailored preview and code on-the-fly.
    dataset_name = dataset_info.get('name', 'Unknown Dataset')
    short_meta = f"name: {dataset_name}; vars: {', '.join(dataset_info.get('variables', []))}; time_range: {dataset_info.get('time_range','1950-2100')}; spatial: {dataset_info.get('spatial_coverage','Global')}"

    # Build a prompt depending on preview type
    if preview_type == 'summary':
        user_prompt = (
            f"Produce a concise, expertise-adapted summary for the dataset with metadata: {short_meta}. "
            f"Adapt the summary dynamically for a user with expertise_level {expertise_level} (scale 1.0=beginner to 5.0=advanced expert). "
            f"For beginners, provide simple practical tips. For advanced users, include technical access recommendations (xarray/intake). "
            "Return plain text."
        )
    elif preview_type == 'spatial':
        user_prompt = (
            f"Provide a spatial preview for dataset ({short_meta}). Recommend regions, resolution, and return a full runnable Python script using xarray/intake/OpenVisus to produce a simple map. "
            f"Adapt the complexity of the code dynamically for a user with expertise_level {expertise_level} (scale 1.0 to 5.0). Use the project's RAG index (cmip6_catalog.yml) for details."
        )
    elif preview_type == 'temporal':
        user_prompt = (
            f"Provide a temporal preview for dataset ({short_meta}). Recommend periods to analyze and return a full runnable Python script to compute a spatial average time series using xarray. "
            f"Adapt the complexity dynamically for expertise_level {expertise_level} (scale 1.0 to 5.0) and prefer reproducible examples using the project's catalog."
        )
    else:  # sample
        user_prompt = (
            f"Return a compact sampling recipe and Python code to extract a representative sample from dataset ({short_meta}). "
            f"Include recommended sample size and any stratification approach dynamically adapted for expertise_level {expertise_level} (scale 1.0 to 5.0)."
        )

    try:
        rag_result = chat_with_retrieval(user_prompt, conversation_history=None, top_k_docs=5)
        answer = rag_result.get('answer', '')
        docs = rag_result.get('docs', [])

        result = {
            'success': True,
            'dataset_name': dataset_name,
            'preview_type': preview_type,
            'expertise_adapted': True,
            'preview_text': answer,
            'retrieved_docs': docs
        }

        # For spatial/temporal/sample types also attempt to extract code blocks (simple heuristic)
        if preview_type in ('spatial', 'temporal', 'sample'):
            # naive extraction of fenced code
            if '```' in answer:
                parts = answer.split('```')
                # code is likely in odd-index parts
                code_blocks = [parts[i] for i in range(1, len(parts), 2)]
                result['code'] = code_blocks[0] if code_blocks else ''
            else:
                result['code'] = answer  # best-effort

        return result
    except Exception as e:
        logger.warning(f"RAG preview generation failed: {e}")
        # Fallback to local generator
        dataset_name = dataset_info.get('name', 'Unknown Dataset')
        if preview_type == 'summary':
            return {'success': True, 'dataset_name': dataset_name, 'preview_type': preview_type, 'preview_text': f"{dataset_name}: quick summary (fallback)", 'retrieved_docs': []}
        if preview_type == 'spatial':
            return {'success': True, 'dataset_name': dataset_name, 'preview_type': preview_type, 'visualization_suggestion': generate_spatial_viz_code(dataset_name, expertise_level), 'retrieved_docs': []}
        if preview_type == 'temporal':
            return {'success': True, 'dataset_name': dataset_name, 'preview_type': preview_type, 'visualization_suggestion': generate_temporal_viz_code(dataset_name, expertise_level), 'retrieved_docs': []}
        return {'success': True, 'dataset_name': dataset_name, 'preview_type': preview_type, 'sample_code': generate_sampling_code(dataset_name, expertise_level), 'retrieved_docs': []}


def generate_spatial_viz_code(dataset_name, expertise_level):
    # Use RAG + LLM to synthesize a spatial visualization script
    prompt = (
        f"Write a full runnable Python script to create a spatial map for dataset '{dataset_name}'. "
        f"Use xarray/intake/OpenVisus (prefer intake with cmip6_catalog.yml) and adapt complexity for expertise_level={expertise_level}. "
        "Do not return a snippet. Include imports and dataset loading so it runs end-to-end."
    )
    try:
        res = chat_with_retrieval(prompt, conversation_history=None, top_k_docs=5)
        answer = res.get('answer', '')
        # Extract code fence if present
        if '```' in answer:
            parts = answer.split('```')
            code_blocks = [parts[i] for i in range(1, len(parts), 2)]
            return code_blocks[0] if code_blocks else answer
        return answer
    except Exception as e:
        logger.warning(f"RAG spatial code generation failed: {e}")
        return f"# Code generation failed: {e}"

def generate_temporal_viz_code(dataset_name, expertise_level):
    prompt = (
        f"Write a full runnable Python script to compute a spatially-averaged time series and plot it for dataset '{dataset_name}'. "
        f"Adapt code for expertise_level={expertise_level}. Use xarray/intake, include imports and dataset loading, and include comments briefly explaining steps."
    )
    try:
        res = chat_with_retrieval(prompt, conversation_history=None, top_k_docs=5)
        answer = res.get('answer', '')
        if '```' in answer:
            parts = answer.split('```')
            code_blocks = [parts[i] for i in range(1, len(parts), 2)]
            return code_blocks[0] if code_blocks else answer
        return answer
    except Exception as e:
        logger.warning(f"RAG temporal code generation failed: {e}")
        return f"# Code generation failed: {e}"
        

def generate_sampling_code(dataset_name, expertise_level):
    prompt = (
        f"Provide a full runnable Python script to extract a representative spatial sample from dataset '{dataset_name}'. "
        f"Adapt method to expertise_level={expertise_level} and prefer stratified or clustering-based sampling for advanced users. Include imports and dataset loading."
    )
    try:
        res = chat_with_retrieval(prompt, conversation_history=None, top_k_docs=5)
        answer = res.get('answer', '')
        if '```' in answer:
            parts = answer.split('```')
            code_blocks = [parts[i] for i in range(1, len(parts), 2)]
            return code_blocks[0] if code_blocks else answer
        return answer
    except Exception as e:
        logger.warning(f"RAG sampling code generation failed: {e}")
        return f"# Sampling code generation failed: {e}"


# -- Adaptive suggestions & complexity hints -------------------------------

def generate_adaptive_query_suggestions(partial_query, expertise_level, profile):
    """Generate dynamic query suggestions using LLM based on user expertise."""
    
    preferred_context = ""
    if profile and getattr(profile, 'preferred_datasets', None):
        try:
            preferred = json.loads(profile.preferred_datasets)
            if preferred:
                preferred_context = f"The user frequently uses these datasets: {', '.join(preferred[:3])}."
        except Exception:
            pass

    prompt = f"""Generate 5 highly relevant climate data query suggestions for a user.
User Expertise Level: {expertise_level} (1.0 = beginner, 5.0 = advanced).
Partial query typed so far: "{partial_query}"
{preferred_context}

Return exactly 5 suggestions that match their expertise level and complete their partial query if provided.
Format as JSON:
{{
    "suggestions": ["query 1", "query 2", "query 3", "query 4", "query 5"]
}}
"""
    try:
        res = chat_non_streaming([{"role": "user", "content": prompt}], temperature=0.7)
        
        # Simple JSON extraction
        if "```json" in res:
            res = res.split("```json")[1].split("```")[0].strip()
        elif "```" in res:
            res = res.split("```")[1].split("```")[0].strip()
            
        data = json.loads(res)
        return data.get("suggestions", [])
    except Exception as e:
        logger.warning(f"Failed to generate dynamic suggestions: {e}")
        return ["Show me temperature data", "What datasets are available?"]


def get_complexity_hints(expertise_level):
    """Generate dynamic complexity hints and tips using LLM."""
    prompt = f"""Generate UI hints and tips for a climate data user with expertise level {expertise_level} (1.0 = beginner, 5.0 = advanced expert).
    
Return JSON:
{{
    "current_level": "Beginner|Intermediate|Advanced (choose based on score)",
    "tips": ["3 practical tips for their specific level using climate data tools like xarray/intake if advanced"],
    "next_steps": "1 suggested next step for them to learn"
}}"""
    
    try:
        res = chat_non_streaming([{"role": "user", "content": prompt}], temperature=0.5)
        
        if "```json" in res:
            res = res.split("```json")[1].split("```")[0].strip()
        elif "```" in res:
            res = res.split("```")[1].split("```")[0].strip()
            
        data = json.loads(res)
        return data
    except Exception as e:
        logger.warning(f"Failed to generate complexity hints: {e}")
        return {
            "current_level": "Unknown",
            "tips": ["Try asking a simple question first."],
            "next_steps": "Explore the datasets."
        }
