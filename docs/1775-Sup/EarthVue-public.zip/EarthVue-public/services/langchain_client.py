"""
LangChain wrapper for Azure OpenAI with RAG support.

This module exposes simple interfaces for streaming and non-streaming chat
and a retrieval-enabled chat helper. It also initializes optional embeddings
and an Azure Search retriever when environment variables and dependencies
are present.

Key classes/functions:
- StreamingTokenHandler: callback handler used when streaming tokens.
- convert_messages_to_langchain(messages): convert simple dict messages to LangChain messages.
- chat_stream(messages, temperature=0.2, max_tokens=2000): stream model output in chunks.
- chat_non_streaming(messages, temperature=0.2, max_tokens=2000): return a single response string.
- chat_with_retrieval(query, conversation_history=None, top_k_docs=5): run a RAG-enabled QA chain and return both answer and source docs.
- get_model_config(): return current model and retriever configuration for provenance.
- update_llm_temperature(temperature) / update_llm_max_tokens(max_tokens): runtime config helpers.
"""

import os
import base64
import json
import uuid
from typing import List, Dict, Any, Generator, Optional
from datetime import datetime

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import (
    HumanMessage,
    SystemMessage,
    AIMessage,
    BaseMessage,
    ToolMessage,
)
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.tools import StructuredTool
from langchain_openai import OpenAIEmbeddings
# Azure Search integration (if available)
try:
    from langchain_community.vectorstores import AzureSearch
    from langchain_community.chains import ConversationalRetrievalChain
    from langchain_core.memory import ConversationBufferMemory
except ImportError:
    AzureSearch = None
    ConversationalRetrievalChain = None
    ConversationBufferMemory = None

# Environment variables
# Support both ENDPOINT_URL and AZURE_OPENAI_ENDPOINT for compatibility
ENDPOINT_URL = os.getenv("ENDPOINT_URL") or os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
DEPLOYMENT_NAME = os.getenv("DEPLOYMENT_NAME")
SEARCH_ENDPOINT = os.getenv("SEARCH_ENDPOINT")
SEARCH_KEY = os.getenv("SEARCH_KEY")
SEARCH_INDEX_NAME = os.getenv("SEARCH_INDEX_NAME")
API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")
ROUTER_MODEL = os.getenv("ROUTER_MODEL", "model-router-demo")

# Initialize LangChain Azure Chat Model
# Will only fail at runtime if credentials are missing, not at import time
llm = None
llm_cache = {}
def get_llm_for(
    deployment_name: Optional[str],
    preferred_temperature: Optional[float] = None,
    request_timeout: Optional[int] = None,
) -> AzureChatOpenAI:
    """Return a cached AzureChatOpenAI instance for the given deployment name.

    If deployment_name is None, falls back to the module-level DEPLOYMENT_NAME.
    `preferred_temperature` overrides the default. Special-case 'o4-mini' to
    always use temperature=1. For other models default to 0.3 when not provided.
    If request_timeout is set, returns a one-off instance with that timeout (not cached).
    """
    name = deployment_name or DEPLOYMENT_NAME
    if not name:
        raise ValueError("No deployment name provided and DEPLOYMENT_NAME is not set")

    timeout_sec = request_timeout if request_timeout is not None else 105

    if request_timeout is not None:
        # One-off client with custom timeout (e.g. for code generation); do not cache
        temp_to_use = (
            preferred_temperature
            if preferred_temperature is not None
            else (1 if (name.lower() == "o4-mini" or "o4-mini" in name.lower()) else 0.2)
        )
        return AzureChatOpenAI(
            deployment_name=name,
            model_name=name,
            azure_endpoint=ENDPOINT_URL,
            azure_ad_token=None,
            api_key=AZURE_API_KEY,
            api_version=API_VERSION,
            temperature=temp_to_use,
            max_tokens=2000,
            timeout=timeout_sec,
        )

    if name in llm_cache:
        return llm_cache[name]

    # Decide temperature: prefer explicit, otherwise special-case or default
    if preferred_temperature is not None:
        temp_to_use = preferred_temperature
    else:
        if name.lower() == 'o4-mini' or 'o4-mini' in name.lower():
            temp_to_use = 1
        else:
            temp_to_use = 0.2

    try:
        inst = AzureChatOpenAI(
            deployment_name=name,
            model_name=name,
            azure_endpoint=ENDPOINT_URL,
            azure_ad_token=None,
            api_key=AZURE_API_KEY,
            api_version=API_VERSION,
            temperature=temp_to_use,
            max_tokens=2000,
            timeout=105,
        )
        llm_cache[name] = inst
        return inst
    except Exception as e:
        # Some deployments (e.g. newer smaller models like o4-mini) may not accept
        # explicit `temperature`/`max_tokens` parameters or may only accept the
        # default temperature (1). Attempt a retry with temperature=1 if the
        # error indicates an unsupported temperature value, otherwise fall back
        # to creating the client without temperature/max_tokens.
        err_str = str(e).lower()
        if 'temperature' in err_str or 'unsupported value' in err_str:
            # If initial attempt failed due to temperature, try with a safer
            # temperature value: use 1 for o4-mini, otherwise try 0.3
            try_temp = 1 if (name.lower() == 'o4-mini' or 'o4-mini' in name.lower()) else 0.3
            try:
                inst = AzureChatOpenAI(
                    deployment_name=name,
                    model_name=name,
                    azure_endpoint=ENDPOINT_URL,
                    azure_ad_token=None,
                    api_key=AZURE_API_KEY,
                    api_version=API_VERSION,
                    temperature=try_temp,
                    max_tokens=2000,
                    timeout=105,
                    stream_usage=True
                )
                llm_cache[name] = inst
                return inst
            except Exception:
                # fall through to a no-temperature attempt
                pass

        try:
            inst = AzureChatOpenAI(
                deployment_name=name,
                model_name=name,
                azure_endpoint=ENDPOINT_URL,
                azure_ad_token=None,
                api_key=AZURE_API_KEY,
                api_version=API_VERSION,
                temperature=0.2,
                timeout=105,
                stream_usage=True
            )
            llm_cache[name] = inst
            return inst
        except Exception as e2:
            raise RuntimeError(f"Could not initialize AzureChatOpenAI for '{name}': {e} ; fallback failed: {e2}")

# Optional: Initialize embeddings for retrieval (if using Azure Search)
try:
    embeddings = OpenAIEmbeddings(
        deployment=os.getenv("EMBEDDING_DEPLOYMENT_NAME")
        or os.getenv("EMBEDDING_DEPLOYMENT")
        or "text-embedding-ada-002",
        model=os.getenv("EMBEDDING_MODEL_NAME", "text-embedding-ada-002"),
        azure_endpoint=ENDPOINT_URL,
        azure_ad_token=None,
        api_key=AZURE_API_KEY,
        api_version=API_VERSION,
    )
except Exception as e:
    print(f"Warning: Could not initialize embeddings: {e}")
    embeddings = None

# Optional: Initialize Azure Search retriever
try:
    if SEARCH_ENDPOINT and SEARCH_KEY and SEARCH_INDEX_NAME and embeddings:
        # Verify embeddings has embed_query method
        if not hasattr(embeddings, 'embed_query') or not callable(embeddings.embed_query):
            raise ValueError("Embeddings object does not have callable embed_query method")
        
        vector_store = AzureSearch(
            azure_search_endpoint=SEARCH_ENDPOINT,
            azure_search_key=SEARCH_KEY,
            index_name=SEARCH_INDEX_NAME,
            embedding_function=embeddings.embed_query,
        )
        retriever = vector_store.as_retriever(search_kwargs={"k": 5})
    else:
        retriever = None
        vector_store = None
except Exception as e:
    print(f"Warning: Could not initialize Azure Search retriever: {e}")
    retriever = None
    vector_store = None


def _last_user_query_text(messages: List[Dict[str, str]]) -> str:
    for m in reversed(messages or []):
        if (m.get("role") or "").lower() == "user":
            c = m.get("content")
            return str(c).strip() if c is not None else ""
    return ""


def _append_azure_search_to_provenance_sink(
    sink: Optional[List[Dict[str, Any]]],
    messages: List[Dict[str, str]],
    top_k: int = 5,
    round_index: int = 0,
) -> None:
    """
    Run Azure AI Search retrieval for the latest user turn and append chunks to
    provenance_sink so Mongo traces / provenance graph include RAG (not only MCP tools).
    """
    if sink is None or retriever is None:
        return
    q = _last_user_query_text(messages)
    if len(q) < 2:
        return
    docs_out: List[Any] = []
    try:
        if hasattr(retriever, "invoke"):
            raw = retriever.invoke(q)
            docs_out = raw if isinstance(raw, list) else ([raw] if raw is not None else [])
        else:
            docs_out = list(retriever.get_relevant_documents(q))
    except Exception:
        try:
            docs_out = list(retriever.get_relevant_documents(q))
        except Exception:
            return
    if not docs_out:
        return
    seen: set = set()
    for doc in docs_out[:top_k]:
        try:
            event_ts = datetime.utcnow().isoformat() + "Z"
            page = getattr(doc, "page_content", None) or ""
            md = getattr(doc, "metadata", None) or {}
            if not isinstance(md, dict):
                md = {}
            key = (str(page)[:160], str(md.get("id") or md.get("chunk_id") or md.get("source") or ""))
            if key in seen:
                continue
            seen.add(key)
            title = (
                md.get("title")
                or md.get("name")
                or md.get("source")
                or md.get("filepath")
                or md.get("id")
                or "Azure AI Search"
            )
            meta: Dict[str, Any] = {
                "provenance_kind": "rag_chunk",
                "source": "azure_ai_search",
                "retrieval_engine": "azure_ai_search",
                "search_index": SEARCH_INDEX_NAME or "",
                "event_id": f"pv_evt_{uuid.uuid4().hex[:12]}",
                "event_timestamp_utc": event_ts,
                "tool_round_index": int(round_index),
            }
            for k, v in list(md.items())[:18]:
                if k in meta or v is None:
                    continue
                try:
                    meta[str(k)[:80]] = str(v)[:1200]
                except Exception:
                    pass
            sink.append(
                {
                    "title": str(title)[:500],
                    "content": str(page)[:4000],
                    "metadata": meta,
                }
            )
            if len(sink) > 200:
                sink.pop(0)
        except Exception:
            continue


class StreamingTokenHandler(BaseCallbackHandler):
    """Callback handler to stream tokens as they are generated."""

    def __init__(self):
        self.token_buffer = ""

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        """Called when a new token is generated."""
        self.token_buffer += token


def convert_messages_to_langchain(messages: List[Dict[str, str]]) -> List[BaseMessage]:
    """
    Convert standard message dicts (role/content) to LangChain message objects.

    Args:
        messages: List of dicts with 'role' and 'content' keys

    Returns:
        List of LangChain message objects
    """
    lc_messages = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            lc_messages.append(SystemMessage(content=content))
        elif role == "user":
            lc_messages.append(HumanMessage(content=content))
        elif role == "assistant":
            lc_messages.append(AIMessage(content=content))

    return lc_messages


def _get_earthvue_tools() -> List[StructuredTool]:
    """Build LangChain tools that call the shared EarthVue tool implementations (MCP-style)."""
    from services.earthvue_tools import (
        list_datasets,
        list_variables,
        load_dataset,
        execute_code_tool,
        statistical_analysis_tool,
        llm_judge_tool,
        extract_reasoning_steps_tool,
    )

    def _execute_code(code: str, timeout_seconds: int = 45) -> str:
        """Wrapper around execute_code_tool for LangChain StructuredTool."""
        return execute_code_tool(code, timeout_seconds=timeout_seconds)

    def _statistical_analysis(code: str, timeout_seconds: int = 30) -> str:
        return statistical_analysis_tool(code, timeout_seconds=timeout_seconds)

    return [
        StructuredTool.from_function(
            func=list_datasets,
            name="list_datasets",
            description="List all registered datasets with their IDs, names, and short descriptions.",
        ),
        StructuredTool.from_function(
            func=list_variables,
            name="list_variables",
            description="List variables and parameters for a dataset. Pass the dataset source_id from list_datasets.",
        ),
        StructuredTool.from_function(
            func=load_dataset,
            name="load_dataset",
            description="Get full metadata and access details for a dataset (catalog URL, access pattern, usage).",
        ),
        StructuredTool.from_function(
            func=_execute_code,
            name="execute_code",
            description="Execute Python code in a sandbox (numpy, pandas, matplotlib, xarray, intake, scipy, sklearn, etc.). Returns JSON with success, output, error, and optional images_base64. For visualizations, analysis, or any code: generate the code in this turn and call execute_code(code='your full code here'). Use timeout_seconds=60 for simple plots; timeout_seconds=90 for multi-scenario or multi-year intake loads (e.g. global means across SSPs/years). If execution fails, fix the code and call execute_code again (up to 5 retries). If using OpenVisus and the user provides X, Y, Z coordinates/ranges, pass those directly in `.read(...)` as x/y/z and do not trim or clamp the returned data afterward. Multi-year work: if >20 timesteps total across years would be needed with naive sampling, use one aligned timestep per year (same calendar date or day-of-year) unless the user explicitly asked for all timesteps.",
        ),
        StructuredTool.from_function(
            func=_statistical_analysis,
            name="statistical_analysis",
            description="Run statistical analysis using Python code (e.g. pandas, scipy, numpy). For stats summaries, correlations, distributions.",
        ),
        StructuredTool.from_function(
            func=llm_judge_tool,
            name="llm_judge",
            description="Use an LLM as a judge: send a prompt and get back structured JSON (e.g. scores, criteria, reasoning). Use for evaluating a response, comparing options, or any structured analysis. Prompt should ask for JSON only.",
        ),
        StructuredTool.from_function(
            func=extract_reasoning_steps_tool,
            name="extract_reasoning_steps",
            description="Extract structured reasoning steps from a user query and model response. Optionally pass conversation_history_json (JSON string of prior messages). Returns a JSON array of steps: step, type, action, description, confidence. Step types: query_understanding, data_retrieval, analysis, reasoning, validation.",
        ),
    ]


def _summarize_tool_result_for_provenance(tool_name: str, content_str: str) -> str:
    """Truncate / strip heavy fields for persisted provenance (no huge base64)."""
    if not content_str:
        return ""
    if tool_name == "execute_code":
        try:
            p = json.loads(content_str)
            safe: Dict[str, Any] = {}
            for k in ("success", "error"):
                if k in p:
                    safe[k] = p[k]
            out = p.get("output") or p.get("stdout") or ""
            if isinstance(out, str):
                safe["output_preview"] = out[:1200]
            imgs = p.get("images_base64") or p.get("images") or []
            if isinstance(imgs, list) and imgs:
                safe["figure_count"] = len(imgs)
            return json.dumps(safe, default=str)[:2500]
        except (json.JSONDecodeError, TypeError):
            return content_str[:2000]
    return content_str[:2500]


def chat_stream_with_tools(
    messages: List[Dict[str, str]],
    temperature: float = 0.3,
    max_tokens: int = 2000,
    deployment_name: Optional[str] = None,
    max_tool_rounds: int = 14,
    provenance_sink: Optional[List[Dict[str, Any]]] = None,
) -> Generator[str, None, None]:
    """
    Stream chat completions with MCP-style tools. The agent can call list_datasets,
    list_variables, load_dataset, execute_code, statistical_analysis.
    Runs an agent loop until the model returns a final answer, then yields the response in chunks.

    If provenance_sink is a list, each tool call appends a dict
    {title, content, metadata} for persistence (retrieved_documents / provenance graph).
    """
    import time
    lc_messages = convert_messages_to_langchain(messages)
    tools = _get_earthvue_tools()
    tool_map = {t.name: t for t in tools}
    max_attempts = 5
    for attempt in range(max_attempts):
        try:
            llm_local = get_llm_for(deployment_name, preferred_temperature=temperature)
            llm_with_tools = llm_local.bind_tools(tools)
            current_messages = list(lc_messages)
            final_content = ""
            tools_used = []
            images_from_tools = []  # collect png images from execute_code for frontend
            plotly_html_from_tools = []  # collect interactive plotly html fragments
            provenance_chunks: List[Dict[str, Any]] = []  # tool I/O for provenance graph
            sink = provenance_sink if provenance_sink is not None else provenance_chunks
            _append_azure_search_to_provenance_sink(sink, messages, round_index=0)
            for round_index in range(max_tool_rounds):
                response = llm_with_tools.invoke(current_messages)
                if not isinstance(response, AIMessage):
                    final_content = str(response)
                    break
                if response.tool_calls:
                    current_messages.append(response)
                    tool_names = []
                    for tc in response.tool_calls:
                        name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", None)
                        if name:
                            tool_names.append(name)
                    if tool_names:
                        yield f"\n<!--PROGRESS:Using tools: {', '.join(tool_names)}-->\n"
                    code_failed_in_round = False
                    for tc in response.tool_calls:
                        name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", None)
                        args = tc.get("args") if isinstance(tc, dict) else getattr(tc, "args", None) or {}
                        tid = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None) or ""
                        if name:
                            tools_used.append(name)
                        if not name or name not in tool_map:
                            tool_result = f"Unknown tool: {name}"
                        else:
                            try:
                                # Stream marker so the chat UI can show "Open in code editor" while execute_code runs
                                if name == "execute_code" and isinstance(args, dict):
                                    _c = args.get("code")
                                    if isinstance(_c, str) and _c.strip():
                                        _payload = base64.b64encode(
                                            json.dumps(_c).encode("utf-8")
                                        ).decode("ascii")
                                        yield f"\n<!--LIVE_TOOL_CODE_B64:{_payload}-->\n"
                                tool_result = tool_map[name].invoke(args)
                            except Exception as e:
                                tool_result = f"Tool error: {str(e)}"
                        raw_tool_str = str(tool_result)
                        content_str = raw_tool_str
                        if name == "execute_code":
                            try:
                                _parsed = json.loads(raw_tool_str)
                                if _parsed.get("success") is False:
                                    code_failed_in_round = True
                                    content_str = (
                                        raw_tool_str
                                        + "\n\n[Execution failed — fix the code and call execute_code "
                                        "again with corrected Python; do not end your turn with only prose.]"
                                    )
                            except (json.JSONDecodeError, TypeError, ValueError):
                                pass
                        if name:
                            try:
                                args_ser = (
                                    args if isinstance(args, dict) else {}
                                )
                                event_ts = datetime.utcnow().isoformat() + "Z"
                                sink.append(
                                    {
                                        "title": name,
                                        "content": _summarize_tool_result_for_provenance(
                                            name, content_str
                                        ),
                                        "metadata": {
                                            "tool": name,
                                            "args": args_ser,
                                            "encoding": "utf-8",
                                            "source": "earthvue_tool_plane",
                                            "provenance_kind": "mcp_tool",
                                            "mcp_plane": "earthvue_agent_tools",
                                            "event_id": f"pv_evt_{uuid.uuid4().hex[:12]}",
                                            "event_timestamp_utc": event_ts,
                                            "tool_round_index": int(round_index),
                                        },
                                    }
                                )
                                # Keep a large window so provenance shows every tool round-trip
                                if len(sink) > 200:
                                    sink.pop(0)
                            except Exception:
                                pass
                        # Collect images from execute_code (parse raw JSON only; never the hint suffix)
                        if name == "execute_code" and raw_tool_str:
                            try:
                                parsed = json.loads(raw_tool_str)
                                imgs = parsed.get("images_base64") or parsed.get("images") or []
                                if isinstance(imgs, list):
                                    images_from_tools.extend(imgs)
                                plotly_html = parsed.get("plotly_html") or []
                                if isinstance(plotly_html, list):
                                    plotly_html_from_tools.extend(plotly_html)
                            except (json.JSONDecodeError, TypeError):
                                pass
                        current_messages.append(
                            ToolMessage(content=content_str[:32000], tool_call_id=tid or name)
                        )
                    if code_failed_in_round:
                        current_messages.append(
                            HumanMessage(
                                content=(
                                    "The execute_code run above failed. Call execute_code again "
                                    "with corrected Python until it succeeds. Use the error output "
                                    "to fix imports, paths, and data loading. Do not answer with only "
                                    "explanatory text while the code still errors."
                                )
                            )
                        )
                    continue
                final_content = response.content or ""
                break
            if not final_content and current_messages:
                last = current_messages[-1]
                if isinstance(last, AIMessage):
                    final_content = last.content or ""
            chunk_size = 320
            for i in range(0, len(final_content), chunk_size):
                yield final_content[i : i + chunk_size]
            if tools_used:
                yield f"\n\n<!--TOOLS_USED:{json.dumps(tools_used)}-->"
            if images_from_tools:
                yield f"\n<!--VIZ_IMAGES:{json.dumps(images_from_tools)}-->"
            if plotly_html_from_tools:
                yield f"\n<!--VIZ_PLOTLY_HTML:{json.dumps(plotly_html_from_tools)}-->"
            return
        except Exception as e:
            err_str = str(e).lower()
            if attempt < max_attempts - 1 and (
                "429" in err_str or "rate limit" in err_str or "too many requests" in err_str
            ):
                sleep_time = (2 ** attempt) + 1
                print(f"Rate limit in chat_stream_with_tools, retrying in {sleep_time}s...")
                time.sleep(sleep_time)
            else:
                print(f"Error in chat_stream_with_tools: {e}")
                yield f"Error: {str(e)}"
                return
    yield "Error: Max retries exceeded"


def chat_stream(
    messages: List[Dict[str, str]],
    temperature: float = 0.3,
    max_tokens: int = 2000,
    deployment_name: Optional[str] = None,
) -> Generator[str, None, None]:
    """
    Stream chat completions from Azure OpenAI via LangChain.
    Yields text chunks as they arrive.

    Args:
        messages: Conversation history (list of role/content dicts)
        temperature: Model temperature (0.0-1.0)
        max_tokens: Maximum tokens to generate

    Yields:
        Text chunks from the model response
    """
    lc_messages = convert_messages_to_langchain(messages)
    max_attempts = 5
    import time
    for attempt in range(max_attempts):
        try:
            llm_local = get_llm_for(deployment_name, preferred_temperature=temperature)
            response = llm_local.generate([lc_messages])
            if response.generations:
                text = response.generations[0][0].text
                chunk_size = 50
                for i in range(0, len(text), chunk_size):
                    yield text[i : i + chunk_size]
            return
        except Exception as e:
            err_str = str(e).lower()
            if attempt < max_attempts - 1 and ("429" in err_str or "rate limit" in err_str or "too many requests" in err_str):
                sleep_time = (2 ** attempt) + 1
                print(f"Rate limit hit in chat_stream, retrying in {sleep_time}s... (Attempt {attempt+1}/{max_attempts})")
                time.sleep(sleep_time)
            else:
                print(f"Error in chat_stream: {e}")
                yield f"Error: {str(e)}"
                return


def chat_non_streaming(
    messages: List[Dict[str, str]],
    temperature: float = 0.2,
    max_tokens: int = 2000,
    deployment_name: Optional[str] = None,
    request_timeout: Optional[int] = None,
) -> str:
    """
    Non-streaming chat completion (used for title/followup generation).

    Args:
        messages: Conversation history (list of role/content dicts)
        temperature: Model temperature (0.0-1.0)
        max_tokens: Maximum tokens to generate
        request_timeout: Optional timeout in seconds for this request (e.g. 180 for code generation).

    Returns:
        Complete response text
    """
    lc_messages = convert_messages_to_langchain(messages)
    import time
    # Use fewer retries for timeout so the caller gets an error sooner; more retries for rate limits
    max_attempts = 5
    for attempt in range(max_attempts):
        try:
            llm_local = get_llm_for(
                deployment_name,
                preferred_temperature=temperature,
                request_timeout=request_timeout,
            )
            response = llm_local.generate([lc_messages])
            if response.generations:
                return response.generations[0][0].text
            return ""
        except Exception as e:
            err_str = str(e).lower()
            is_timeout = "timed out" in err_str or "timeout" in err_str
            is_rate_limit = "429" in err_str or "rate limit" in err_str or "too many requests" in err_str
            is_retryable = is_rate_limit or is_timeout
            # For timeouts, do not retry so the stream can return an error to the user quickly
            max_effective = 1 if is_timeout else max_attempts
            if attempt < max_effective - 1 and is_retryable:
                sleep_time = (2 ** attempt) + 1
                print(f"chat_non_streaming retrying in {sleep_time}s... (Attempt {attempt+1}/{max_effective}): {e}")
                time.sleep(sleep_time)
            else:
                print(f"Error in chat_non_streaming: {e}")
                return f"Error: {str(e)}"
    return "Error: Max retries exceeded"


def chat_with_retrieval(
    query: str,
    conversation_history: Optional[List[Dict[str, str]]] = None,
    top_k_docs: int = 5,
    deployment_name: Optional[str] = None,
    temperature: float = 0.2,
) -> Dict[str, Any]:
    """
    Chat with optional RAG retrieval from Azure Search.
    Returns both the answer and the retrieved documents.

    Args:
        query: User query
        conversation_history: Prior conversation (list of role/content dicts)
        top_k_docs: Number of documents to retrieve

    Returns:
        Dict with 'answer' and 'docs' keys
    """
    if not retriever:
        # Fallback to non-streaming chat if retriever not available
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
        ]
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": query})

        answer = chat_non_streaming(messages, temperature=temperature, deployment_name=deployment_name)
        return {"answer": answer, "docs": []}

    max_attempts = 5
    import time
    for attempt in range(max_attempts):
        try:
            # Create a ConversationalRetrievalChain
            memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

            # Add prior history to memory
            if conversation_history:
                for msg in conversation_history:
                    if msg.get("role") == "user":
                        memory.chat_memory.add_user_message(msg.get("content", ""))
                    elif msg.get("role") == "assistant":
                        memory.chat_memory.add_ai_message(msg.get("content", ""))

            llm_local = get_llm_for(deployment_name, preferred_temperature=temperature)
            qa = ConversationalRetrievalChain.from_llm(
                llm=llm_local,
                retriever=retriever,
                memory=memory,
                return_source_documents=True,
                verbose=False,
            )

            result = qa({"question": query})
            return {
                "answer": result.get("answer", ""),
                "docs": [
                    {
                        "title": doc.metadata.get("source", "Unknown"),
                        "source": doc.metadata.get("source", "Unknown"),
                        "content": doc.page_content[:500],  # Truncate for storage
                        "metadata": {
                            "provenance_kind": "rag_chunk",
                            "source": doc.metadata.get("source", "Unknown"),
                        },
                    }
                    for doc in result.get("source_documents", [])
                ],
            }
        except Exception as e:
            err_str = str(e).lower()
            if attempt < max_attempts - 1 and ("429" in err_str or "rate limit" in err_str or "too many requests" in err_str):
                sleep_time = (2 ** attempt) + 1
                print(f"Rate limit hit in chat_with_retrieval, retrying in {sleep_time}s... (Attempt {attempt+1}/{max_attempts})")
                time.sleep(sleep_time)
            else:
                print(f"Error in chat_with_retrieval: {e}")
                return {"answer": f"Error: {str(e)}", "docs": []}
    return {"answer": "Error: Max retries exceeded", "docs": []}


def get_model_config() -> Dict[str, Any]:
    """Get current model configuration for provenance tracking."""
    return {
        "model": DEPLOYMENT_NAME,
        "temperature": 0.2,
        "max_tokens": 2000,
        "api_version": API_VERSION,
        "search_enabled": retriever is not None,
        "search_documents": 5 if retriever else 0,
        "framework": "langchain",
    }


def list_available_deployments() -> List[str]:
    """Return a list of deployment names discovered from environment variables.

    Scans for env vars that start with 'DEPLOYMENT_NAME' and returns their values.
    """
    names = []
    for k, v in os.environ.items():
        # Support both the correct and legacy misspelled prefixes so that
        # values like DEPLOYMENT_NAME1 and DEPLOYMEN_NAME1 are both picked up.
        if (k.startswith("DEPLOYMENT_NAME") or k.startswith("DEPLOYMEN_NAME")) and v:
            names.append(v)
    # dedupe while preserving order
    seen = set()
    out = []
    for n in names:
        if n not in seen:
            out.append(n)
            seen.add(n)
    return out


def update_llm_temperature(temperature: float) -> None:
    """Update the LLM temperature for subsequent calls."""
    # Update cached LLM instances where temperature attribute exists
    for name, inst in llm_cache.items():
        try:
            if hasattr(inst, 'temperature'):
                inst.temperature = temperature
        except Exception:
            pass


def update_llm_max_tokens(max_tokens: int) -> None:
    """Update the max tokens for subsequent calls."""
    for name, inst in llm_cache.items():
        try:
            if hasattr(inst, 'max_tokens'):
                inst.max_tokens = max_tokens
        except Exception:
            pass
