"""
Load data_registry.yml and provide a formatted block for system prompts.
Single source of truth for which datasets exist and how to access them.
"""
import logging
import re
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

logger = logging.getLogger(__name__)

_REGISTRY_PATH = Path(__file__).resolve().parent.parent / "data_registry.yml"
_loaded_registry = None


def _load_registry(force_reload=False):
    global _loaded_registry
    if force_reload:
        _loaded_registry = None
    if _loaded_registry is not None:
        return _loaded_registry
    if not yaml:
        logger.warning("PyYAML not installed; data registry will be empty.")
        _loaded_registry = {"sources": {}}
        return _loaded_registry
    if not _REGISTRY_PATH.is_file():
        logger.warning("data_registry.yml not found at %s", _REGISTRY_PATH)
        _loaded_registry = {"sources": {}}
        return _loaded_registry
    try:
        with open(_REGISTRY_PATH, "r", encoding="utf-8") as f:
            _loaded_registry = yaml.safe_load(f) or {"sources": {}}
        if "sources" not in _loaded_registry:
            _loaded_registry["sources"] = {}
    except Exception as e:
        logger.exception("Failed to load data_registry.yml: %s", e)
        _loaded_registry = {"sources": {}}
    return _loaded_registry


def get_registry_context_for_prompt(only_source_ids=None, force_reload=False):
    """
    Build the "Available data sources (use ONLY these)" block from data_registry.yml
    for injection into the chat (or visualization) system prompt.
    """
    reg = _load_registry(force_reload=force_reload)
    sources = reg.get("sources") or {}
    if not sources:
        return ""

    if only_source_ids is not None:
        only = {str(x) for x in (only_source_ids or []) if x is not None}
        sources = {k: v for k, v in sources.items() if k in only}
        if not sources:
            return ""

    lines = [
        "",
        "Available data sources (use ONLY these when the user asks about these datasets):",
        "",
    ]
    for source_id, meta in sources.items():
        name = meta.get("name", source_id)
        desc = meta.get("description", "")
        lines.append(f"- **{name}** ({source_id}): {desc}")
        access_pattern = meta.get("access_pattern")
        if access_pattern:
            lines.append(f"  Access pattern: {access_pattern}")
        usage = meta.get("usage", "").strip()
        if usage:
            for u in usage.split("\n"):
                lines.append(f"  {u.strip()}")
        catalog_url = meta.get("catalog_url")
        if catalog_url:
            lines.append(f"  Catalog: {catalog_url}")
        # Surface base URLs (some sources use multiple base_url* fields)
        for k in sorted([k for k in meta.keys() if k.startswith("base_url")]):
            v = meta.get(k)
            if not v:
                continue
            if k == "base_url":
                lines.append(f"  Base URL: {v}")
            else:
                lines.append(f"  {k}: {v}")
        url_template = meta.get("url_template")
        if url_template:
            lines.append(f"  URL template: {url_template}")
        params = meta.get("parameters", [])
        if params:
            lines.append(f"  Parameters: {', '.join(params)}")
        vars_list = meta.get("variables", [])
        if isinstance(vars_list, list) and vars_list:
            var_strs = []
            for v in vars_list:
                if isinstance(v, dict) and "id" in v:
                    var_strs.append(v["id"])
                elif isinstance(v, str):
                    var_strs.append(v)
            if var_strs:
                lines.append(f"  Variables: {', '.join(var_strs)}")
        lines.append("")
    return "\n".join(lines)


def get_sources(force_reload=False):
    """Return the raw sources dict from the registry (e.g. for tools)."""
    return _load_registry(force_reload=force_reload).get("sources") or {}


def _normalize_for_match(text):
    """Normalize text for matching dataset names/ids (lowercase, replace - and spaces with _)."""
    if not text:
        return ""
    return text.lower().replace("-", "_").replace(" ", "_")


def resolve_source_id_from_query(query: str):
    """
    If the user message clearly mentions a known dataset by name or id, return its source_id.
    E.g. 'NEX-GDDP-CMIP6' or 'nex-gddp-cmip6' -> 'nex_gddp_cmip6'. Returns None if ambiguous or not found.
    """
    if not query or not query.strip():
        return None
    sources = get_sources()
    if not sources:
        return None
    q = _normalize_for_match(query.strip())
    # Match when the query contains a known source_id (e.g. "nex_gddp_cmip6")
    for sid in sources:
        if _normalize_for_match(sid) in q:
            return sid
    # Match display name (e.g. "NEX-GDDP-CMIP6" or "nex gddp cmip6" in query)
    for sid, meta in sources.items():
        name = (meta.get("name") or "").strip()
        if name and _normalize_for_match(name) in q:
            return sid

    # Heuristic: multi-scenario + global temperature/average questions map to NEX-GDDP-CMIP6
    # so chat can pre-fetch registry context and skip list_datasets/list_variables/load_dataset.
    ql = query.strip().lower()
    if "nex_gddp_cmip6" in sources:
        has_scenario = "scenario" in ql or re.search(
            r"\b(ssp\d{3}|historical|rcp\d{2}\.\d)\b", ql
        )
        has_global = (
            "global region" in ql
            or "global mean" in ql
            or "global average" in ql
            or "worldwide" in ql
            or "entire globe" in ql
            or "whole globe" in ql
            or "planetwide" in ql
        )
        has_temp = any(
            t in ql
            for t in (
                "temperature",
                "near-surface",
                "near surface",
                "tasmax",
                "tasmin",
                "2 m air",
                "2m air",
            )
        ) or re.search(r"\btas\b", ql)
        if has_scenario and has_global and has_temp:
            return "nex_gddp_cmip6"

    return None


def get_prefetched_dataset_context(source_id: str) -> str:
    """
    Return the same context the model would get from calling list_datasets, list_variables,
    and load_dataset for this source. Used to pre-inject so the model skips those tool calls.
    """
    block = get_registry_context_for_prompt(only_source_ids=[source_id])
    if not block or not block.strip():
        return ""
    return (
        "\n\n**Pre-fetched dataset context (do NOT call list_datasets, list_variables, or load_dataset for this dataset; use the info below and go straight to execute_code with your generated code):**\n"
        + block
    )
