from __future__ import annotations

from typing import Any, Dict, List, Optional
import json
import math
import re


def _extract_json_block(text: str) -> Optional[Any]:
    """Extract a JSON object/array from a fenced block or inline content."""
    if not text:
        return None

    # Look for ```json ... ``` or ``` ... ``` blocks first
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        try:
            return json.loads(m.group(1).strip())
        except json.JSONDecodeError:
            pass

    # Fallback: try first object or array in the text
    for pattern in (r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", r"\[[\s\S]*\]"):
        for match in re.finditer(pattern, text):
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                continue

    return None


def _parse_response_as_spec(response_text: str, spec: Dict[str, Any]) -> Any:
    """
    Parse model response into a Python object consistent with output_spec.

    Supported types:
    - scalar: {"field": <float>}
    - table: list[dict]
    - array: list[float or dict]
    """
    parsed = _extract_json_block(response_text)
    if parsed is None:
        return None

    out_type = spec.get("type", "scalar")

    if out_type == "scalar":
        field = spec.get("field")
        if isinstance(parsed, dict) and field and field in parsed:
            try:
                return {field: float(parsed[field])}
            except (TypeError, ValueError):
                return None
        if isinstance(parsed, (int, float)):
            key = field or "value"
            return {key: float(parsed)}

    elif out_type == "table":
        if isinstance(parsed, list):
            return parsed
        if isinstance(parsed, dict):
            return [parsed]

    elif out_type == "array":
        if isinstance(parsed, list):
            return parsed

    return parsed


def _mae(a: List[float], b: List[float]) -> float:
    n = max(len(a), 1)
    return sum(abs(x - y) for x, y in zip(a, b)) / n


def _rmse(a: List[float], b: List[float]) -> float:
    n = max(len(a), 1)
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)) / n)


def _flatten_numeric(vals: Any) -> List[float]:
    """
    Flatten nested lists/dicts into a list of numeric values for comparison.
    Intended for small tables/arrays, not large tensors.
    """
    out: List[float] = []

    if isinstance(vals, list):
        for row in vals:
            if isinstance(row, dict):
                for v in row.values():
                    if isinstance(v, (int, float)):
                        out.append(float(v))
            elif isinstance(row, (int, float)):
                out.append(float(row))

    elif isinstance(vals, dict):
        for v in vals.values():
            if isinstance(v, (int, float)):
                out.append(float(v))

    return out


def evaluate_analytical_task(task: Dict[str, Any], response_text: str) -> Dict[str, Any]:
    """
    Evaluate an analytical task where the model returns numeric JSON.

    The task should define:
    - evaluation_type: "analytical"
    - output_spec: {type: "scalar" | "table" | "array", ...}
    - expected_output: ground truth (scalar dict, list of rows, or list of values)
    - scoring: {"method": "MAE"|"RMSE", "tolerance": <float>}
    """
    spec = task.get("output_spec", {}) or {}
    expected = task.get("expected_output")
    scoring = task.get("scoring", {}) or {}
    method = str(scoring.get("method", "MAE")).upper()
    tolerance = float(scoring.get("tolerance", 0.0))

    if expected is None:
        return {
            "evaluation_type": "analytical",
            "error": "Missing expected_output in task",
            "passed": False,
        }

    agent_out = _parse_response_as_spec(response_text, spec)
    if agent_out is None:
        return {
            "evaluation_type": "analytical",
            "error": "Could not parse numeric JSON from response",
            "passed": False,
        }

    out_type = spec.get("type", "scalar")
    mae_val: Optional[float] = None
    rmse_val: Optional[float] = None
    passed = False

    try:
        if out_type == "scalar":
            field = spec.get("field")
            if not field:
                # fall back to first key in expected
                if isinstance(expected, dict) and expected:
                    field = next(iter(expected.keys()))
                else:
                    return {
                        "evaluation_type": "analytical",
                        "error": "Scalar spec requires 'field' or dict expected_output",
                        "passed": False,
                    }
            ref_v = float(expected[field])
            agent_v = float(agent_out[field])
            err = abs(agent_v - ref_v)
            mae_val = err
            rmse_val = err
            passed = err <= tolerance

        elif out_type in ("table", "array"):
            ref_vals = _flatten_numeric(expected)
            agent_vals = _flatten_numeric(agent_out)
            n = min(len(ref_vals), len(agent_vals))
            if n == 0:
                return {
                    "evaluation_type": "analytical",
                    "error": "No comparable numeric values found",
                    "passed": False,
                }
            ref_vals = ref_vals[:n]
            agent_vals = agent_vals[:n]

            mae_val = _mae(agent_vals, ref_vals)
            rmse_val = _rmse(agent_vals, ref_vals)
            if method == "RMSE":
                passed = rmse_val <= tolerance
            else:
                passed = mae_val <= tolerance

        else:
            return {
                "evaluation_type": "analytical",
                "error": f"Unsupported output_spec.type='{out_type}'",
                "passed": False,
            }

    except Exception as exc:  # pragma: no cover - defensive
        return {
            "evaluation_type": "analytical",
            "error": f"Scoring failed: {exc}",
            "passed": False,
        }

    # Map numeric error to [0, 1] score (1 = perfect, 0 = error >= 2 * tolerance)
    if method == "RMSE" and rmse_val is not None:
        error = rmse_val
    else:
        error = mae_val if mae_val is not None else 0.0

    denom = max(tolerance * 2.0, 1e-6)
    score = max(0.0, min(1.0, 1.0 - error / denom))

    return {
        "evaluation_type": "analytical",
        "passed": passed,
        "metric": method,
        "tolerance": tolerance,
        "mae": mae_val,
        "rmse": rmse_val,
        "score": score,
        "agent_output_parsed": agent_out,
    }

