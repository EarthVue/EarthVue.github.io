"""
Session-level reasoning & provenance: smart aggregation (not a raw concat).

- Provenance: group MCP tools by name with counts + previews; bucket RAG by source.
- Reasoning: dedupe within turns; long sessions → overview node + recent steps tail.
- Uncertainties / biases: deduped then capped with severity-aware ordering.
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple

from models import AIReasoningTrace, AIUncertaintyEvent, DataProvenance

from services.provenance_graph import EARTHVUE_AGENT_TOOL_NAMES, merge_uncertainty_records

MAX_SESSION_TRACES = 250
# Summarized provenance output (graph + API)
MAX_TOOL_SUMMARY_ROWS = 14
MAX_RAG_BUCKET_ROWS = 12
MAX_OTHER_DOCS = 5
# Reasoning chain in graph
MAX_REASONING_STEPS_FULL = 22
MAX_REASONING_TAIL = 16
MAX_SINGLE_TRACE_DOCS = 72
MAX_SINGLE_TRACE_STEPS = 48
# Risk lists
MAX_UNCERTAINTIES = 36
MAX_BIASES = 28


def _safe_json_loads(s: Any, default):
    if s is None:
        return default
    if isinstance(s, (list, dict)):
        return s
    if isinstance(s, str):
        if not s.strip():
            return default
        try:
            return json.loads(s)
        except (json.JSONDecodeError, TypeError):
            return default
    return default


def get_session_traces_chronological(
    session_uuid: str, user_id: str, limit: int = MAX_SESSION_TRACES
) -> List[AIReasoningTrace]:
    """Oldest → newest. If the session exceeds `limit`, keep the most recent turns."""
    batch = list(
        AIReasoningTrace.objects(session_uuid=session_uuid, user_id=user_id)
        .order_by("-timestamp")
        .limit(limit)
    )
    batch.reverse()
    return batch


def _provenance_doc_fingerprint(doc: Any) -> Tuple[str, ...]:
    if not isinstance(doc, dict):
        return ("raw", str(doc)[:240])
    md = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    tool = md.get("tool") or doc.get("title")
    if tool:
        args = md.get("args")
        args_s = (
            json.dumps(args, sort_keys=True, default=str)
            if isinstance(args, dict)
            else str(args)
        )
        return ("tool", str(tool), args_s[:500])
    body = (doc.get("content") or doc.get("text") or doc.get("snippet") or "")[:160]
    title = str(doc.get("title") or doc.get("name") or "")
    return ("doc", title[:120], body)


def _is_mcp_style_doc(d: Dict[str, Any]) -> bool:
    md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
    if md.get("provenance_kind") == "mcp_tool":
        return True
    if md.get("source") == "earthvue_tool_plane":
        return True
    if md.get("tool"):
        return True
    title = (d.get("title") or "").strip()
    return title in EARTHVUE_AGENT_TOOL_NAMES


def _rag_bucket_key(d: Dict[str, Any]) -> str:
    md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
    for k in ("dataset_id", "dataset_name", "source", "index_name", "catalog"):
        v = md.get(k)
        if v is not None and str(v).strip():
            return f"{k}:{str(v)[:120]}"
    t = d.get("title") or d.get("name") or d.get("source")
    if t:
        return f"title:{str(t)[:100]}"
    body = (d.get("content") or d.get("text") or "")[:80]
    return f"body:{body}"


def _looks_like_rag(d: Dict[str, Any]) -> bool:
    if _is_mcp_style_doc(d):
        return False
    md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
    if md.get("provenance_kind") in ("rag_chunk", "retrieval", "azure_search"):
        return True
    if md.get("retrieval_engine") == "azure_ai_search":
        return True
    if str(md.get("source") or "").lower() in ("azure_ai_search", "azure_search"):
        return True
    return bool(
        d.get("page_content")
        or d.get("content")
        or d.get("text")
        or d.get("snippet")
    )


def _summarize_retrieved_documents(
    traces: List[AIReasoningTrace],
) -> Tuple[List[Any], Dict[str, Any]]:
    """
    Build a compact provenance list for the graph: per-tool rollups + top RAG buckets.
    """
    tool_groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    rag_buckets: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    other_seen: set = set()
    other_out: List[Dict[str, Any]] = []

    total_raw = 0
    for t in traces:
        docs = _safe_json_loads(t.retrieved_documents, [])
        if not isinstance(docs, list):
            continue
        for d in docs:
            total_raw += 1
            if not isinstance(d, dict):
                s = str(d)[:300]
                if s not in other_seen:
                    other_seen.add(s)
                    if len(other_out) < MAX_OTHER_DOCS:
                        other_out.append(
                            {
                                "title": "Context snippet",
                                "content": s,
                                "metadata": {"provenance_kind": "context_blob"},
                            }
                        )
                continue
            if _is_mcp_style_doc(d):
                name = str(
                    (d.get("metadata") or {}).get("tool")
                    or d.get("title")
                    or "tool"
                )
                tool_groups[name].append(d)
            elif _looks_like_rag(d):
                rag_buckets[_rag_bucket_key(d)].append(d)
            else:
                fp = _provenance_doc_fingerprint(d)
                if fp in other_seen:
                    continue
                other_seen.add(fp)
                if len(other_out) < MAX_OTHER_DOCS:
                    other_out.append(d)

    out: List[Any] = []

    # MCP: one card per tool, count + latest preview
    for name in sorted(tool_groups.keys())[:MAX_TOOL_SUMMARY_ROWS]:
        docs = tool_groups[name]
        n = len(docs)
        first = docs[0]
        latest = docs[-1]
        first_prev = str(first.get("content") or "")[:900]
        prev = str(latest.get("content") or "")[:900]
        if not first_prev.strip():
            first_prev = "(no text preview stored)"
        if not prev.strip():
            prev = "(no text preview stored)"
        drift_changed = first_prev.strip() != prev.strip()
        synthetic = {
            "title": name,
            "content": (
                f"Session aggregate: {n} call(s).\n"
                f"First result preview:\n{first_prev}\n\n"
                f"Most recent result preview:\n{prev}"
            )[:2500],
            "metadata": {
                "tool": name,
                "provenance_kind": "mcp_tool",
                "source": "earthvue_tool_plane",
                "session_aggregate": True,
                "session_invocation_count": n,
                "session_first_preview": first_prev,
                "session_latest_preview": prev,
                "session_output_drift": drift_changed,
            },
        }
        out.append(synthetic)

    # RAG: top buckets by volume
    rag_sorted = sorted(rag_buckets.items(), key=lambda x: -len(x[1]))
    for key, docs in rag_sorted[:MAX_RAG_BUCKET_ROWS]:
        n = len(docs)
        rep = dict(docs[-1])
        body = str(
            rep.get("content")
            or rep.get("text")
            or rep.get("snippet")
            or rep.get("page_content")
            or ""
        )[:650]
        rep["title"] = rep.get("title") or rep.get("name") or key[:80] or "RAG chunk"
        rep["content"] = (
            f"Merged {n} chunk(s) from this line of evidence in the session.\n\n{body}"
        )[:20000]
        md = dict(rep.get("metadata") or {})
        md["session_aggregate"] = True
        md["session_chunk_count"] = n
        md.setdefault("provenance_kind", "rag_chunk")
        rep["metadata"] = md
        out.append(rep)

    out.extend(other_out)

    summary = {
        "raw_document_events": total_raw,
        "synthesized_nodes": len(out),
        "unique_tools": len(tool_groups),
        "tool_calls_total": sum(len(v) for v in tool_groups.values()),
        "tool_output_drift_count": sum(
            1
            for docs in tool_groups.values()
            if docs
            and str(docs[0].get("content") or "").strip()
            != str(docs[-1].get("content") or "").strip()
        ),
        "rag_buckets": len(rag_buckets),
        "rag_chunk_instances": sum(len(v) for v in rag_buckets.values()),
        "paragraph": _provenance_paragraph(
            traces, tool_groups, rag_buckets, total_raw, len(out)
        ),
    }
    return out, summary


def _provenance_paragraph(
    traces: List[Any],
    tool_groups: Dict[str, List[Any]],
    rag_buckets: Dict[str, List[Any]],
    raw_total: int,
    synth_nodes: int,
) -> str:
    nt = len(traces)
    ut = len(tool_groups)
    tc = sum(len(v) for v in tool_groups.values())
    ri = sum(len(v) for v in rag_buckets.values())
    rb = len(rag_buckets)
    drift = sum(
        1
        for docs in tool_groups.values()
        if docs
        and str(docs[0].get("content") or "").strip()
        != str(docs[-1].get("content") or "").strip()
    )
    return (
        f"Across {nt} assistant turn(s): {raw_total} raw provenance record(s) collapsed to "
        f"{synth_nodes} graph node(s) — {tc} tool invocation(s) across {ut} tool(s), "
        f"{ri} retrieval chunk(s) in {rb} source bucket(s), "
        f"and output drift in {drift} tool(s) between first and latest call."
    )


def _step_key(step: Dict[str, Any]) -> str:
    return str(
        step.get("type") or step.get("category") or step.get("step") or "step"
    ).strip().lower()


def _summarize_reasoning_steps(
    traces: List[AIReasoningTrace], turn_index_base: int
) -> Tuple[List[Any], Dict[str, Any]]:
    flat: List[Dict[str, Any]] = []
    for offset, t in enumerate(traces):
        turn = turn_index_base + offset + 1
        steps = _safe_json_loads(t.reasoning_steps, [])
        if not isinstance(steps, list):
            continue
        for step in steps:
            if isinstance(step, dict):
                s2 = dict(step)
                s2["_session_turn"] = turn
                s2["_reasoning_trace_id"] = str(t.id)
                flat.append(s2)
            else:
                flat.append(
                    {
                        "type": "note",
                        "description": str(step)[:2000],
                        "_session_turn": turn,
                        "_reasoning_trace_id": str(t.id),
                    }
                )

    # Collapse consecutive same-type within the same turn
    compact: List[Dict[str, Any]] = []
    for s in flat:
        if (
            compact
            and compact[-1].get("_session_turn") == s.get("_session_turn")
            and _step_key(compact[-1]) == _step_key(s)
            and _step_key(s) not in ("", "step", "note")
        ):
            continue
        compact.append(s)

    total = len(compact)
    summary: Dict[str, Any] = {
        "total_steps_in_view": total,
        "turns": len(traces),
        "mode": "full",
    }

    if len(traces) == 1 and total <= MAX_SINGLE_TRACE_STEPS:
        summary["mode"] = "single_turn"
        return compact, summary

    if total <= MAX_REASONING_STEPS_FULL:
        return compact, summary

    ctr = Counter(_step_key(s) for s in compact)
    top_lines = ", ".join(f"{k}×{v}" for k, v in ctr.most_common(8))
    overview: Dict[str, Any] = {
        "type": "session_reasoning_overview",
        "category": "session_rollout",
        "description": (
            f"Session-wide pattern ({total} reasoning rows across {len(traces)} turn(s), "
            f"after deduping repeats per turn). Step mix: {top_lines}."
        )[:1200],
        "action": "summary",
        "_session_turn": None,
        "_reasoning_trace_id": None,
    }
    tail = compact[-MAX_REASONING_TAIL:]
    summary["mode"] = "overview_plus_tail"
    summary["tail_steps"] = len(tail)
    summary["dropped_for_brevity"] = total - len(tail)
    return [overview] + tail, summary


def _light_merge_single_trace(traces: List[AIReasoningTrace]) -> Tuple[List[Any], Dict[str, Any]]:
    """One turn (or first batch): richer detail, still capped."""
    seen: set = set()
    out: List[Any] = []
    raw_count = 0
    for t in traces[:1]:
        docs = _safe_json_loads(t.retrieved_documents, [])
        if not isinstance(docs, list):
            break
        raw_count = len(docs)
        for d in docs:
            fp = _provenance_doc_fingerprint(d)
            if fp in seen:
                continue
            seen.add(fp)
            out.append(d)
            if len(out) >= MAX_SINGLE_TRACE_DOCS:
                break
    tool_names: set = set()
    rag_chunks = 0
    for d in out:
        if isinstance(d, dict) and _is_mcp_style_doc(d):
            md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
            tool_names.add(str(md.get("tool") or d.get("title") or "tool"))
        elif isinstance(d, dict) and _looks_like_rag(d):
            rag_chunks += 1
    summary = {
        "raw_document_events": raw_count,
        "synthesized_nodes": len(out),
        "unique_tools": len(tool_names),
        "tool_calls_total": sum(
            1 for d in out if isinstance(d, dict) and _is_mcp_style_doc(d)
        ),
        "rag_buckets": rag_chunks,
        "rag_chunk_instances": rag_chunks,
        "paragraph": (
            f"Single-turn session: {raw_count} raw provenance row(s), "
            f"{len(out)} unique node(s) after dedupe (cap {MAX_SINGLE_TRACE_DOCS})."
        ),
    }
    return out, summary


def _merge_bias_indicators(traces: List[AIReasoningTrace]) -> List[Any]:
    seen: set = set()
    out: List[Any] = []
    for t in traces:
        items = _safe_json_loads(t.bias_indicators, [])
        if not isinstance(items, list):
            continue
        for b in items:
            fp = (
                json.dumps(b, sort_keys=True, default=str)
                if isinstance(b, dict)
                else str(b)
            )
            if fp in seen:
                continue
            seen.add(fp)
            out.append(b)
    return out


def _severity_rank(b: Any) -> int:
    if not isinstance(b, dict):
        return 3
    s = str(b.get("severity", "")).lower()
    return {"high": 0, "critical": 0, "medium": 1, "moderate": 1}.get(s, 2)


def _impact_rank(u: Dict[str, Any]) -> int:
    s = str(u.get("impact", "")).lower()
    return {"high": 0, "medium": 1, "low": 2}.get(s, 3)


def _latest_non_empty_dataset_logic(traces: List[AIReasoningTrace]) -> Any:
    for t in reversed(traces):
        logic = _safe_json_loads(t.dataset_selection_logic, {})
        if logic:
            return logic
    return {}


def _merge_uncertainty_factors_json(traces: List[AIReasoningTrace]) -> List[Any]:
    merged: List[Any] = []
    for t in traces:
        part = _safe_json_loads(t.uncertainty_factors, [])
        if isinstance(part, list):
            merged.extend(part)
    return merged


def _session_user_query_summary(
    traces: List[AIReasoningTrace], total_turn_count: Optional[int] = None
) -> str:
    n_total = total_turn_count if total_turn_count is not None else len(traces)
    if len(traces) == 1:
        return (traces[0].user_query or "").strip()
    lines: List[str] = []
    max_turns = 12
    start = max(0, len(traces) - max_turns)
    base = 0
    if total_turn_count is not None and total_turn_count > len(traces):
        base = total_turn_count - len(traces)
    for i in range(start, len(traces)):
        t = traces[i]
        q = (t.user_query or "").strip().replace("\n", " ")
        if not q:
            continue
        turn_no = base + i + 1
        lines.append(f"[Turn {turn_no}] {_truncate(q, 280)}")
    if total_turn_count is not None and total_turn_count > len(traces):
        header = (
            f"Session · {total_turn_count} turn(s) total; summarization uses the latest "
            f"{len(traces)} turn(s).\n\nRecent questions:\n\n"
        )
    else:
        header = f"Session · {n_total} turn(s). Recent questions:\n\n"
    return header + "\n\n".join(lines)


def _truncate(text: str, n: int) -> str:
    t = text.strip()
    if len(t) <= n:
        return t
    return t[: n - 1] + "…"


def _extract_model_name(model_parameters: Any) -> str:
    if not isinstance(model_parameters, dict):
        return ""
    for k in (
        "model",
        "model_name",
        "deployment_name",
        "deployment",
        "llm_model",
        "engine",
    ):
        v = model_parameters.get(k)
        if v is not None and str(v).strip():
            return str(v).strip()
    nested = model_parameters.get("model_config")
    if isinstance(nested, dict):
        for k in ("model", "model_name", "deployment_name", "deployment"):
            v = nested.get(k)
            if v is not None and str(v).strip():
                return str(v).strip()
    return ""


def _quality_scores_from_trace(trace: AIReasoningTrace) -> Dict[str, Any]:
    confidence_scores = _safe_json_loads(trace.confidence_scores, {})

    def _float(v, default=0.0):
        try:
            return float(v) if v is not None else default
        except (TypeError, ValueError):
            return default

    return {
        "coherence": _float(
            confidence_scores.get("coherence"),
            _float(getattr(trace, "response_coherence_score", 0)),
        ),
        "accuracy": _float(
            confidence_scores.get("accuracy"),
            _float(getattr(trace, "factual_accuracy_score", 0)),
        ),
        "completeness": _float(
            confidence_scores.get("completeness"),
            _float(getattr(trace, "completeness_score", 0)),
        ),
        "dataset_appropriateness": _float(
            confidence_scores.get("dataset_appropriateness"),
            _float(getattr(trace, "dataset_appropriateness_score", 0)),
        ),
        "overall": _float(confidence_scores.get("overall", 0)),
        "coherence_explanation": confidence_scores.get("coherence_explanation")
        or "No explanation provided.",
        "accuracy_explanation": confidence_scores.get("accuracy_explanation")
        or "No explanation provided.",
        "completeness_explanation": confidence_scores.get("completeness_explanation")
        or "No explanation provided.",
        "dataset_appropriateness_explanation": confidence_scores.get(
            "dataset_appropriateness_explanation"
        )
        or "No explanation provided.",
    }


def merged_data_provenance_rows(trace_ids: List[str]) -> List[Dict[str, Any]]:
    seen: set = set()
    rows: List[Dict[str, Any]] = []
    for tid in trace_ids:
        for p in DataProvenance.objects(reasoning_trace_id=tid):
            key = (p.dataset_name, p.source_origin or "")
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                {
                    "dataset_name": p.dataset_name,
                    "source_origin": p.source_origin or "",
                    "confidence_level": p.confidence_level,
                }
            )
    return rows


def _compose_session_summary_paragraph(
    prov_summary: Dict[str, Any],
    reasoning_summary: Dict[str, Any],
    u_count: int,
    u_shown: int,
    b_count: int,
    b_shown: int,
    total_turns: int,
    trace_batch: int,
) -> str:
    parts = [prov_summary.get("paragraph", "")]
    parts.append(
        f"Reasoning: {reasoning_summary.get('total_steps_in_view', 0)} step row(s) "
        f"({reasoning_summary.get('mode', 'full')})."
    )
    if u_count or b_count:
        parts.append(
            f"Risks: {u_shown} of {u_count} uncertainty factor(s); "
            f"{b_shown} of {b_count} bias flag(s) shown (deduped, severity-prioritized)."
        )
    if total_turns > trace_batch:
        parts.append(
            f"Oldest turns omitted from this batch: showing latest {trace_batch} of {total_turns}."
        )
    return " ".join(p for p in parts if p).strip()


def _build_turn_options(
    traces: List[AIReasoningTrace], total_turn_count: int
) -> List[Dict[str, Any]]:
    turn_index_base = max(0, total_turn_count - len(traces))
    options: List[Dict[str, Any]] = []
    for i, t in enumerate(traces):
        turn_no = turn_index_base + i + 1
        q = str((t.user_query or "")).strip().replace("\n", " ")
        options.append(
            {
                "reasoning_trace_id": str(t.id),
                "turn": turn_no,
                "query_preview": _truncate(q or "(no prompt captured)", 180),
                "timestamp": t.timestamp.isoformat()
                if getattr(t.timestamp, "isoformat", None)
                else None,
            }
        )
    return options


def build_session_aggregate(
    session_uuid: str, user_id: str
) -> Optional[Dict[str, Any]]:
    """
    Smart session rollup for provenance graph + reasoning API.
    """
    traces = get_session_traces_chronological(session_uuid, user_id)
    if not traces:
        return None

    total_turn_count = int(
        AIReasoningTrace.objects(session_uuid=session_uuid, user_id=user_id).count()
    )

    latest = traces[-1]
    trace_ids = [str(t.id) for t in traces]

    factors_merged = _merge_uncertainty_factors_json(traces)
    db_events = list(AIUncertaintyEvent.objects(reasoning_trace_id__in=trace_ids))
    uncertainties_full = merge_uncertainty_records(factors_merged, db_events)
    uncertainties_sorted = sorted(
        uncertainties_full,
        key=_impact_rank,
    )
    uncertainties = uncertainties_sorted[:MAX_UNCERTAINTIES]

    biases_full = _merge_bias_indicators(traces)
    biases_sorted = sorted(biases_full, key=_severity_rank)
    biases = biases_sorted[:MAX_BIASES]

    processing_ms = sum(int(getattr(t, "processing_time_ms", 0) or 0) for t in traces)

    turn_index_base = (
        total_turn_count - len(traces) if total_turn_count > len(traces) else 0
    )

    if len(traces) == 1:
        retrieved_docs, prov_summary = _light_merge_single_trace(traces)
    else:
        retrieved_docs, prov_summary = _summarize_retrieved_documents(traces)

    reasoning_steps, reasoning_summary = _summarize_reasoning_steps(
        traces, turn_index_base
    )

    session_summary = _compose_session_summary_paragraph(
        prov_summary,
        reasoning_summary,
        len(uncertainties_full),
        len(uncertainties),
        len(biases_full),
        len(biases),
        total_turn_count,
        len(traces),
    )

    return {
        "traces": traces,
        "trace_ids": trace_ids,
        "primary_trace_id": str(latest.id),
        "trace_count": len(traces),
        "user_query": _session_user_query_summary(traces, total_turn_count),
        "retrieved_documents": retrieved_docs,
        "dataset_logic": _latest_non_empty_dataset_logic(traces),
        "reasoning_steps": reasoning_steps,
        "quality_scores": _quality_scores_from_trace(latest),
        "uncertainties": uncertainties,
        "biases": biases,
        "data_provenance_rows": merged_data_provenance_rows(trace_ids),
        "model_parameters": _safe_json_loads(latest.model_parameters, {}) or {},
        "model_name": _extract_model_name(
            _safe_json_loads(latest.model_parameters, {}) or {}
        ),
        "processing_time_ms": processing_ms,
        "latest_timestamp": latest.timestamp,
        "first_timestamp": traces[0].timestamp,
        "total_turn_count": total_turn_count,
        "provenance_summary": prov_summary,
        "reasoning_summary": reasoning_summary,
        "session_summary": session_summary,
        "uncertainty_total": len(uncertainties_full),
        "uncertainty_shown": len(uncertainties),
        "bias_total": len(biases_full),
        "bias_shown": len(biases),
        "turn_options": _build_turn_options(traces, total_turn_count),
        "assistant_response": str(getattr(latest, "assistant_response", None) or ""),
    }


def build_reasoning_analysis_json(
    session_uuid: str, user_id: str, selected_trace_id: Optional[str] = None
) -> Tuple[bool, Dict[str, Any]]:
    """
    Match /api/reasoning_analysis shape. Returns (has_trace, payload).
    """
    agg = build_session_aggregate(session_uuid, user_id)
    if not agg:
        return False, {
            "session_id": session_uuid,
            "has_trace": False,
            "message": "No reasoning data for this session. Reasoning is recorded when you send messages in chat.",
            "timestamp": None,
            "user_query": "",
            "processing_time_ms": 0,
            "reasoning_steps": [],
            "dataset_logic": {},
            "confidence_scores": {},
            "uncertainties": [],
            "provenance": [],
            "biases": [],
            "reasoning_trace_id": None,
            "trace_count": 0,
            "session_merged": True,
            "quality_scores": {
                "coherence": 0.0,
                "accuracy": 0.0,
                "completeness": 0.0,
                "dataset_appropriateness": 0.0,
                "overall": 0.0,
                "coherence_explanation": "",
                "accuracy_explanation": "",
                "completeness_explanation": "",
                "dataset_appropriateness_explanation": "",
            },
            "turn_options": [],
            "selected_turn": None,
            "selected_trace_mode": False,
            "model_parameters": {},
            "model_name": "",
        }

    selected_trace = None
    if selected_trace_id:
        for t in agg["traces"]:
            if str(t.id) == str(selected_trace_id):
                selected_trace = t
                break
    if selected_trace is None:
        selected_trace = agg["traces"][-1]

    selected_mode = selected_trace_id is not None and str(selected_trace.id) == str(
        selected_trace_id
    )

    turn_map = {
        str(opt.get("reasoning_trace_id")): opt for opt in agg.get("turn_options", [])
    }
    selected_turn = turn_map.get(str(selected_trace.id))

    if selected_mode:
        # Per-turn interactive view for the prompt selector.
        turn_docs, _ = _light_merge_single_trace([selected_trace])
        turn_steps, _ = _summarize_reasoning_steps([selected_trace], 0)
        turn_unc_full = merge_uncertainty_records(
            _merge_uncertainty_factors_json([selected_trace]),
            list(AIUncertaintyEvent.objects(reasoning_trace_id=str(selected_trace.id))),
        )
        turn_unc = sorted(turn_unc_full, key=_impact_rank)[:MAX_UNCERTAINTIES]
        turn_bias_full = _merge_bias_indicators([selected_trace])
        turn_bias = sorted(turn_bias_full, key=_severity_rank)[:MAX_BIASES]
        conf = _safe_json_loads(selected_trace.confidence_scores, {})
    else:
        turn_docs = agg["retrieved_documents"]
        turn_steps = agg["reasoning_steps"]
        turn_unc = agg["uncertainties"]
        turn_bias = agg["biases"]
        conf = _safe_json_loads(selected_trace.confidence_scores, {})

    uncertainties_ui = [
        {
            "type": u.get("type", ""),
            "source": u.get("source", ""),
            "confidence": float(u.get("confidence", 0) or 0),
            "impact": u.get("impact", ""),
            "description": f"{u.get('type', '')} uncertainty from {u.get('source', '')}",
            "mitigation": u.get("mitigation", "") or "",
        }
        for u in turn_unc
    ]

    return True, {
        "session_id": session_uuid,
        "has_trace": True,
        "session_merged": True,
        "session_summary": agg["session_summary"],
        "provenance_summary": agg["provenance_summary"],
        "reasoning_summary": agg["reasoning_summary"],
        "trace_count": agg["trace_count"],
        "reasoning_trace_id": str(selected_trace.id),
        "reasoning_trace_ids": agg["trace_ids"],
        "selected_trace_mode": selected_mode,
        "selected_turn": selected_turn,
        "turn_options": agg.get("turn_options", []),
        "timestamp": selected_trace.timestamp.isoformat()
        if getattr(selected_trace.timestamp, "isoformat", None)
        else None,
        "session_first_timestamp": agg["first_timestamp"].isoformat()
        if getattr(agg["first_timestamp"], "isoformat", None)
        else None,
        "user_query": (
            str((selected_trace.user_query or "")).strip()
            if selected_mode
            else agg["user_query"]
        ),
        "processing_time_ms": (
            int(getattr(selected_trace, "processing_time_ms", 0) or 0)
            if selected_mode
            else agg["processing_time_ms"]
        ),
        "reasoning_steps": turn_steps,
        "dataset_logic": (
            _safe_json_loads(selected_trace.dataset_selection_logic, {})
            if selected_mode
            else agg["dataset_logic"]
        ),
        "confidence_scores": conf,
        "uncertainties": uncertainties_ui,
        "provenance": turn_docs,
        "retrieved_document_count": len(turn_docs) if isinstance(turn_docs, list) else 0,
        "biases": turn_bias,
        "model_parameters": (
            _safe_json_loads(selected_trace.model_parameters, {})
            if selected_mode
            else (agg.get("model_parameters") or {})
        ),
        "model_name": _extract_model_name(
            _safe_json_loads(selected_trace.model_parameters, {})
            if selected_mode
            else (agg.get("model_parameters") or {})
        ),
        "quality_scores": (
            _quality_scores_from_trace(selected_trace)
            if selected_mode
            else agg["quality_scores"]
        ),
        "total_turn_count": agg.get("total_turn_count", agg["trace_count"]),
        "uncertainty_total": agg.get("uncertainty_total", 0),
        "uncertainty_shown": agg.get("uncertainty_shown", 0),
        "bias_total": agg.get("bias_total", 0),
        "bias_shown": agg.get("bias_shown", 0),
    }


def build_selected_trace_aggregate(
    session_uuid: str, user_id: str, selected_trace_id: str
) -> Optional[Dict[str, Any]]:
    """
    Resolve one trace from a session and return a per-turn payload
    shaped like the session aggregate keys used by provenance/reasoning views.
    """
    agg = build_session_aggregate(session_uuid, user_id)
    if not agg:
        return None

    selected_trace = None
    for t in agg["traces"]:
        if str(t.id) == str(selected_trace_id):
            selected_trace = t
            break
    if selected_trace is None:
        return None

    turn_docs, _ = _light_merge_single_trace([selected_trace])
    turn_steps, _ = _summarize_reasoning_steps([selected_trace], 0)
    turn_unc_full = merge_uncertainty_records(
        _merge_uncertainty_factors_json([selected_trace]),
        list(AIUncertaintyEvent.objects(reasoning_trace_id=str(selected_trace.id))),
    )
    turn_unc = sorted(turn_unc_full, key=_impact_rank)[:MAX_UNCERTAINTIES]
    turn_bias_full = _merge_bias_indicators([selected_trace])
    turn_bias = sorted(turn_bias_full, key=_severity_rank)[:MAX_BIASES]

    return {
        "trace_id": str(selected_trace.id),
        "trace_ids": agg["trace_ids"],
        "trace_count": agg["trace_count"],
        "total_turn_count": agg.get("total_turn_count", agg["trace_count"]),
        "turn_options": agg.get("turn_options", []),
        "selected_turn": next(
            (
                o
                for o in agg.get("turn_options", [])
                if str(o.get("reasoning_trace_id")) == str(selected_trace.id)
            ),
            None,
        ),
        "user_query": str((selected_trace.user_query or "")).strip(),
        "retrieved_documents": turn_docs,
        "dataset_logic": _safe_json_loads(selected_trace.dataset_selection_logic, {}),
        "reasoning_steps": turn_steps,
        "quality_scores": _quality_scores_from_trace(selected_trace),
        "uncertainties": turn_unc,
        "biases": turn_bias,
        "data_provenance_rows": merged_data_provenance_rows([str(selected_trace.id)]),
        "model_parameters": _safe_json_loads(selected_trace.model_parameters, {}) or {},
        "model_name": _extract_model_name(
            _safe_json_loads(selected_trace.model_parameters, {}) or {}
        ),
        "processing_time_ms": int(getattr(selected_trace, "processing_time_ms", 0) or 0),
        "assistant_response": str(getattr(selected_trace, "assistant_response", None) or ""),
    }
