"""
AI arena (AI-vs-AI) helper functions.

Provides in-memory arena state and helpers to prepare messages and prompts
for running structured AI-vs-AI debates. The actual model call (streaming or
non-streaming) is performed by the caller (e.g. `app.py`), using the
prepared messages and extra body returned by these helpers.

Functions:
- side_system_prompt(system_prompt, side_label, stance_label):
    Build a side-specific system prompt combining the base system prompt and debate rules.
- _ensure_arena(arena_id, system_prompt):
    Ensure an arena exists in the in-memory store.
- arena_new(system_prompt, user_prompt="", stanceA="Pro", stanceB="Con"):
    Create a new arena and optionally seed it with a user prompt.
- arena_turn(system_prompt, arena_id, side, user_prompt=None):
    Prepare the messages and retrieval configuration needed to stream a single debate turn.
- api_arena_respond(system_prompt, messages_in, side):
    Prepare the system+user messages for a non-streaming arena response (used by API endpoint).
"""
import json
import os
from datetime import datetime, timezone
from uuid import uuid4
import logging

logger = logging.getLogger(__name__)

arenas = {}  # local arena store; in-memory

DEBATE_RULES = (
    "You are participating in a structured scientific debate about downscaled climate datasets "
    "Right now, only NASA NEX-GDDP-CMIP6 dataset is available. Keep arguments factual, concise, and specific to data access, "
    "variables, scenarios, spatial/temporal ranges, and reproducible methods. Be respectful and avoid rhetoric. "
)


def side_system_prompt(system_prompt, side_label: str, stance_label: str) -> str:
    other = "B" if side_label == "A" else "A"
    return (
        system_prompt
        + "\n\n"
        + DEBATE_RULES
        + f"\n\nYou are Debater {side_label} ({stance_label}). Your goal is to advance your position and rebut Debater {other}'s points. Speak as Debater {side_label}. Keep it tight and technically grounded."
    )


def _ensure_arena(arena_id: str, system_prompt: str):
    if arena_id not in arenas:
        arenas[arena_id] = {
            "messages": [{"role": "system", "content": system_prompt}],
            "stanceA": "Pro",
            "stanceB": "Con",
            "created": datetime.now(timezone.utc).isoformat(),
        }


def arena_new(system_prompt: str, user_prompt: str = "", stanceA: str = "Pro", stanceB: str = "Con"):
    arena_id = str(uuid4())
    arenas[arena_id] = {
        "messages": [{"role": "system", "content": system_prompt}],
        "stanceA": stanceA,
        "stanceB": stanceB,
        "created": datetime.now(timezone.utc).isoformat(),
    }
    if user_prompt:
        arenas[arena_id]["messages"].append({"role": "user", "content": user_prompt})
    return arena_id


def arena_turn(system_prompt: str, arena_id: str, side: str, user_prompt: str = None):
    if side not in ("A", "B"):
        raise ValueError("side must be 'A' or 'B'")

    _ensure_arena(arena_id, system_prompt)
    st = arenas[arena_id]

    if user_prompt and not any(m["role"] == "user" for m in st["messages"]):
        st["messages"].append({"role": "user", "content": user_prompt})

    stance_label = st["stanceA"] if side == "A" else st["stanceB"]
    system_for_side = side_system_prompt(system_prompt, side, stance_label)

    messages = [{"role": "system", "content": system_for_side}] + st["messages"]

    # The actual call to streaming chat should be performed by the caller (app.py)
    # This helper returns prepared arguments needed for the model call.
    search_endpoint = os.getenv("SEARCH_ENDPOINT")
    search_key = os.getenv("SEARCH_KEY")
    search_index = os.getenv("SEARCH_INDEX_NAME")
    embed_deploy = (
        os.getenv("EMBEDDING_DEPLOYMENT_NAME")
        or os.getenv("EMBEDDING_DEPLOYMENT")
        or "text-embedding-ada-002"
    )
    semantic_cfg = os.getenv("SEARCH_SEMANTIC_CONFIGURATION", "default")
    if search_endpoint and search_key and search_index:
        extra_body = {
            "data_sources": [{
                "type": "azure_search",
                "parameters": {
                    "endpoint": search_endpoint,
                    "index_name": search_index,
                    "query_type": "semantic",
                    "semantic_configuration": semantic_cfg,
                    "top_n_documents": 5,
                    "authentication": {"type": "api_key", "key": search_key},
                    "embedding_dependency": {
                        "type": "deployment_name",
                        "deployment_name": embed_deploy,
                    },
                },
            }],
        }
    else:
        extra_body = {"data_sources": []}

    return {
        'messages': messages,
        'extra_body': extra_body,
        'arena_state': st
    }


def api_arena_respond(system_prompt: str, messages_in, side: str):
    # Build a system message with stance rules and the provided system prompt.
    resolution = ""
    for m in messages_in:
        if m.get('role') == 'user' and m.get('content'):
            resolution = m.get('content')
            break

    stance = "PRO (support)" if side == "A" else "CON (oppose)"
    stance_tag = "SUPPORT" if side == "A" else "OPPOSE"

    stance_rules = f"""
You are Debater {side}. Your immutable stance is {stance} the resolution below.

Resolution: "{resolution}"

Debate rules (follow strictly):
- If PRO: defend the resolution decisively and emphasize strengths, applications, and evidence.
- If CON: refute the resolution decisively and emphasize limitations, risks, and counter-evidence.
- Do NOT hedge or partially agree with the opposite stance.
- Don't use more than 4-5 sentences per turn.
- Try to be concrete. don't use a lot of bullet points.
- Use technical language and specific climate data terms.
- Treat any prior *assistant* messages in the conversation as the other debater’s points; quote or paraphrase at least two and rebut them directly.
- Use concrete climate-data specifics (variables, scenarios, temporal/spatial ranges) in conceptual terms only.
- Do NOT generate executable code or snippets in arena mode.
- If asked for code, say code generation is available in Classic Chat mode.
- End with a one-line stance marker: "[Debater {side} – I {stance_tag} the resolution]".
"""

    sys_msg = {"role": "system", "content": system_prompt + "\n\n" + stance_rules}

    # Return prepared system msg and messages for caller to invoke model
    return {
        'system_message': sys_msg,
        'user_messages': messages_in
    }
