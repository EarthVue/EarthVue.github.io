"""Knowledge Graph Service for dataset/query/variable/spatial relationships."""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

from services.data_registry import get_sources

logger = logging.getLogger(__name__)


_CMIP6_CATALOG_PATH = Path(__file__).resolve().parent.parent / "cmip6_catalog.yml"


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", (value or "").strip().lower()).strip("_")


def _title_from_var_id(var_id: str) -> str:
    replacements = {
        "tas": "Air Temperature",
        "tasmin": "Min Air Temperature",
        "tasmax": "Max Air Temperature",
        "pr": "Precipitation",
        "hurs": "Relative Humidity",
        "rsds": "Shortwave Radiation",
        "sfcWind": "Surface Wind Speed",
    }
    if var_id in replacements:
        return replacements[var_id]
    return var_id.replace("_", " ").replace("-", " ").strip().title()


def _infer_variable_category(var_id: str, description: str) -> str:
    value = f"{var_id} {description}".lower()
    if any(k in value for k in ("temp", "precip", "humidity", "climate")):
        return "climate"
    if any(k in value for k in ("wind", "pressure", "atmosphere", "air")):
        return "atmospheric"
    if any(k in value for k in ("radiation", "solar", "wave")):
        return "radiation"
    if any(k in value for k in ("ocean", "salinity", "theta", "sea")):
        return "ocean"
    return "unknown"


def _new_graph() -> Dict[str, Any]:
    return {
        "nodes": [],
        "edges": [],
        "stats": {
            "node_count": 0,
            "edge_count": 0,
            "source": "live",
        },
    }


def _canonical_relationship(value: str) -> str:
    rel = (value or "related_to").strip().lower()
    mapping = {
        "supports_variable": "provides",
        "requested_for": "queried_with",
        "alternative_for": "alternative_source_for",
        "contains": "supports",
    }
    return mapping.get(rel, rel)


def _canonical_extraction_source(value: str) -> str:
    src = (value or "registry").strip().lower()
    if "llm" in src:
        return "llm"
    if "heuristic" in src:
        return "heuristic"
    if src in {"activity", "provenance", "registry", "curated", "merged"}:
        return src
    return "registry"


def _confidence_from_count(count: Optional[int], default: float = 0.60) -> float:
    if count is None:
        return max(0.0, min(1.0, float(default)))
    try:
        c = int(count)
    except Exception:
        return max(0.0, min(1.0, float(default)))
    # Saturates by around 10 observations.
    return max(0.15, min(1.0, float(c) / 10.0))


def _add_node(
    graph: Dict[str, Any],
    seen_nodes: set,
    *,
    node_id: str,
    label: str,
    node_type: str,
    category: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    if not node_id or node_id in seen_nodes:
        return
    graph["nodes"].append(
        {
            "data": {
                "id": node_id,
                "label": label,
                "type": node_type,
                "category": category,
                "metadata": metadata or {},
            }
        }
    )
    seen_nodes.add(node_id)


def _add_edge(
    graph: Dict[str, Any],
    seen_edges: set,
    *,
    source: str,
    target: str,
    relationship: str,
    count: Optional[int] = None,
    confidence: Optional[float] = None,
    edge_kind: str = "semantic",
    extraction_source: str = "registry",
) -> None:
    if not source or not target or source == target:
        return
    relationship = _canonical_relationship(relationship)
    edge_kind = (edge_kind or "semantic").strip().lower() or "semantic"
    if edge_kind not in {"semantic", "causal"}:
        edge_kind = "semantic"
    extraction_source = _canonical_extraction_source(extraction_source)
    if confidence is None:
        confidence = _confidence_from_count(count)
    confidence = max(0.0, min(1.0, float(confidence)))

    # Robust pair-level dedupe: keep only one semantic edge between same endpoints.
    for existing in graph.get("edges", []):
        data = existing.get("data", {})
        if data.get("source") == source and data.get("target") == target:
            if count is not None:
                prev = int(data.get("count") or 0)
                data["count"] = max(prev, int(count))
            prev_conf = float(data.get("confidence") or 0.0)
            data["confidence"] = max(prev_conf, float(confidence))
            prev_src = _canonical_extraction_source(data.get("extraction_source") or "registry")
            if prev_src != extraction_source:
                data["extraction_source"] = "merged"
            else:
                data["extraction_source"] = extraction_source
            data["edge_kind"] = "causal" if data.get("edge_kind") == "causal" else edge_kind
            # Keep existing canonical relationship label stable once created.
            data["relationship"] = _canonical_relationship(data.get("relationship") or relationship)
            return

    key = (source, target, relationship)
    if key in seen_edges:
        return
    data = {
        "source": source,
        "target": target,
        "relationship": relationship,
        "confidence": float(confidence),
        "edge_kind": edge_kind,
        "extraction_source": extraction_source,
    }
    if count is not None:
        data["count"] = count
    graph["edges"].append({"data": data})
    seen_edges.add(key)


def _finalize(graph: Dict[str, Any], *, source: str = "live") -> Dict[str, Any]:
    graph.setdefault("stats", {})
    graph["stats"].update(
        {
            "node_count": len(graph.get("nodes", [])),
            "edge_count": len(graph.get("edges", [])),
            "source": source,
        }
    )
    return graph


def _merge_approved_triples(
    graph: Dict[str, Any],
    seen_nodes: set,
    seen_edges: set,
    *,
    user_id: Optional[str],
) -> None:
    """Merge curated approved triples into the graph as auditable semantic edges."""
    try:
        from models import KnowledgeTriple
    except Exception:
        return

    try:
        qs = KnowledgeTriple.objects(status="approved")
        if user_id:
            qs = qs.filter(user_id=str(user_id))
        triples = list(qs.order_by("-updated_at")[:300])
    except Exception:
        return

    for t in triples:
        _add_node(
            graph,
            seen_nodes,
            node_id=t.subject_id,
            label=t.subject_label,
            node_type=t.subject_type,
            category="curated",
            metadata={
                "source": "curated_triple",
                "confidence": float(t.confidence or 0.0),
                "predicate": t.predicate,
            },
        )
        _add_node(
            graph,
            seen_nodes,
            node_id=t.object_id,
            label=t.object_label,
            node_type=t.object_type,
            category="curated",
            metadata={
                "source": "curated_triple",
                "confidence": float(t.confidence or 0.0),
                "predicate": t.predicate,
            },
        )
        _add_edge(
            graph,
            seen_edges,
            source=t.subject_id,
            target=t.object_id,
            relationship=t.predicate,
            count=max(1, int(round((t.confidence or 0.0) * 10))),
            confidence=float(t.confidence or 0.0),
            edge_kind="semantic",
            extraction_source=_canonical_extraction_source(getattr(t, "extraction_method", "curated")),
        )


def _load_registry_sources() -> Dict[str, Dict[str, Any]]:
    try:
        return get_sources(force_reload=True) or {}
    except Exception as exc:
        logger.warning("Failed to read data registry sources: %s", exc)
        return {}


def _extract_default_cmip6_model_scenario() -> Tuple[Optional[str], Optional[str]]:
    if not yaml or not _CMIP6_CATALOG_PATH.is_file():
        return None, None
    try:
        with open(_CMIP6_CATALOG_PATH, "r", encoding="utf-8") as f:
            payload = yaml.safe_load(f) or {}
        src = (payload.get("sources") or {}).get("nex_gddp_cmip6") or {}
        params = src.get("parameters") or {}
        model = ((params.get("model") or {}).get("default") or "").strip() or None
        scenario = ((params.get("scenario") or {}).get("default") or "").strip() or None
        return model, scenario
    except Exception as exc:
        logger.debug("Unable to parse cmip6 catalog defaults: %s", exc)
        return None, None


def build_dataset_graph(user_id: str = None) -> Dict[str, Any]:
    """Build a live dataset graph from data_registry.yml and cmip6_catalog.yml defaults."""
    graph = _new_graph()
    seen_nodes, seen_edges = set(), set()

    sources = _load_registry_sources()
    if not sources:
        graph["stats"]["message"] = "No dataset registry sources found."
        return _finalize(graph)

    default_model, default_scenario = _extract_default_cmip6_model_scenario()

    for source_id, meta in sources.items():
        dataset_node_id = _slug(source_id)
        label = meta.get("name") or source_id
        description = meta.get("description") or ""
        access_pattern = (meta.get("access_pattern") or "unknown").strip().lower()

        _add_node(
            graph,
            seen_nodes,
            node_id=dataset_node_id,
            label=label,
            node_type="dataset",
            category=access_pattern,
            metadata={
                "description": description,
                "catalog_url": meta.get("catalog_url", ""),
                "base_url": meta.get("base_url", ""),
                "base_url_climate2": meta.get("base_url_climate2", ""),
                "url_template": meta.get("url_template", ""),
                "access_pattern": meta.get("access_pattern", ""),
            },
        )

        variables = meta.get("variables") or []
        for var in variables:
            if isinstance(var, dict):
                var_id = (var.get("id") or "").strip()
                var_desc = (var.get("description") or "").strip()
            else:
                var_id = str(var).strip()
                var_desc = ""

            if not var_id:
                continue

            variable_node_id = _slug(var_id)
            _add_node(
                graph,
                seen_nodes,
                node_id=variable_node_id,
                label=_title_from_var_id(var_id),
                node_type="variable",
                category=_infer_variable_category(var_id, var_desc),
                metadata={
                    "id": var_id,
                    "description": var_desc,
                },
            )
            _add_edge(
                graph,
                seen_edges,
                source=dataset_node_id,
                target=variable_node_id,
                relationship="provides",
                confidence=0.90,
                edge_kind="semantic",
                extraction_source="registry",
            )

        params = meta.get("parameters") or []
        if isinstance(params, list):
            if "model" in params and default_model:
                model_node_id = _slug(default_model)
                _add_node(
                    graph,
                    seen_nodes,
                    node_id=model_node_id,
                    label=default_model,
                    node_type="model",
                    category="climate_model",
                    metadata={"source": "cmip6_catalog_default"},
                )
                _add_edge(
                    graph,
                    seen_edges,
                    source=dataset_node_id,
                    target=model_node_id,
                    relationship="supports",
                    confidence=0.85,
                    edge_kind="semantic",
                    extraction_source="registry",
                )

            if "scenario" in params and default_scenario:
                scenario_node_id = _slug(default_scenario)
                _add_node(
                    graph,
                    seen_nodes,
                    node_id=scenario_node_id,
                    label=default_scenario,
                    node_type="scenario",
                    category="emission",
                    metadata={"source": "cmip6_catalog_default"},
                )
                _add_edge(
                    graph,
                    seen_edges,
                    source=dataset_node_id,
                    target=scenario_node_id,
                    relationship="supports",
                    confidence=0.85,
                    edge_kind="semantic",
                    extraction_source="registry",
                )

    _merge_approved_triples(graph, seen_nodes, seen_edges, user_id=user_id)
    return _finalize(graph)


def _safe_json_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value if x is not None]
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return [str(x) for x in parsed if x is not None]
        except Exception:
            return []
    return []


def _extract_variable_mentions(query: str, known_variables: List[str]) -> List[str]:
    q = (query or "").lower()
    out = []
    for var in known_variables:
        v = var.lower()
        if not v:
            continue
        if re.search(rf"\b{re.escape(v)}\b", q):
            out.append(var)
    return out


def _dataset_variable_index(
    sources: Dict[str, Dict[str, Any]],
) -> Tuple[Dict[str, set], Dict[str, set]]:
    """Build dataset->variables and variable->datasets indexes from registry sources."""
    dataset_to_vars: Dict[str, set] = {}
    variable_to_datasets: Dict[str, set] = defaultdict(set)

    for source_id, meta in sources.items():
        ds_slug = _slug(source_id)
        vars_set = set()
        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                var_id = (var.get("id") or "").strip()
            else:
                var_id = str(var).strip()
            if not var_id:
                continue
            var_slug = _slug(var_id)
            vars_set.add(var_slug)
            variable_to_datasets[var_slug].add(ds_slug)
        dataset_to_vars[ds_slug] = vars_set

    return dataset_to_vars, variable_to_datasets


def _compute_query_pattern_insights(
    events: List[Any],
    known_datasets: Dict[str, str],
    known_variables: List[str],
    dataset_to_vars: Dict[str, set],
    variable_to_datasets: Dict[str, set],
    dataset_counter: Counter,
) -> List[Dict[str, Any]]:
    """Compute high-value task signals for KG-assisted analysis and paper claims."""
    insights: List[Dict[str, Any]] = []
    if not events:
        return insights

    semantic_mismatch_count = 0
    missing_alternative_count = 0

    for event in events:
        query = (getattr(event, "query_text", "") or "").strip()
        dataset_mentions = _safe_json_list(getattr(event, "datasets_mentioned", None))
        if not dataset_mentions:
            for sid, name in known_datasets.items():
                sid_text = sid.replace("_", "-")
                if sid_text in query.lower() or name.lower() in query.lower():
                    dataset_mentions.append(sid)

        dataset_slugs = [_slug(ds) for ds in dataset_mentions if ds]
        variable_mentions = _extract_variable_mentions(query, known_variables)
        variable_slugs = [_slug(v) for v in variable_mentions if v]

        if not dataset_slugs or not variable_slugs:
            continue

        # Semantic mismatch: query variable not represented in selected dataset variable set.
        for ds_slug in dataset_slugs:
            available = dataset_to_vars.get(ds_slug, set())
            for var_slug in variable_slugs:
                if available and var_slug not in available:
                    semantic_mismatch_count += 1
                    break

        # Missing alternatives: variable available in multiple datasets but query flow anchors to one.
        if len(set(dataset_slugs)) == 1:
            for var_slug in set(variable_slugs):
                if len(variable_to_datasets.get(var_slug, set())) > 1:
                    missing_alternative_count += 1
                    break

    if semantic_mismatch_count > 0:
        insights.append(
            {
                "id": "semantic_mismatch",
                "title": "Semantic mismatch signals",
                "severity": "medium" if semantic_mismatch_count < 6 else "high",
                "description": (
                    "Detected query cases where requested variable tokens did not align "
                    "with variables available in the selected dataset."
                ),
                "count": semantic_mismatch_count,
            }
        )

    if dataset_counter:
        total_mentions = sum(dataset_counter.values())
        top_dataset, top_count = dataset_counter.most_common(1)[0]
        share = (float(top_count) / float(total_mentions)) if total_mentions else 0.0
        if share >= 0.65:
            insights.append(
                {
                    "id": "dataset_overreliance",
                    "title": "Dataset over-reliance",
                    "severity": "medium" if share < 0.8 else "high",
                    "description": (
                        "One dataset dominates recent query patterns. Consider presenting "
                        "alternatives to reduce selection bias."
                    ),
                    "dataset": top_dataset,
                    "share": round(share, 2),
                }
            )

    if missing_alternative_count > 0:
        insights.append(
            {
                "id": "missing_alternatives",
                "title": "Missing alternative-model opportunities",
                "severity": "low" if missing_alternative_count < 6 else "medium",
                "description": (
                    "Found single-dataset query flows where the requested variable is available "
                    "in multiple datasets."
                ),
                "count": missing_alternative_count,
            }
        )

    return insights


def build_query_pattern_graph(user_id: str = None) -> Dict[str, Any]:
    """Build query-pattern graph from DataAccessEvent and ChatMessage activity."""
    graph = _new_graph()
    seen_nodes, seen_edges = set(), set()

    # Lazy import so this service can still be imported in contexts without DB init.
    try:
        from models import ChatMessage, DataAccessEvent
    except Exception as exc:  # pragma: no cover
        graph["stats"]["message"] = f"Query activity unavailable: {exc}"
        return _finalize(graph)

    sources = _load_registry_sources()
    known_datasets = {sid: (meta.get("name") or sid) for sid, meta in sources.items()}
    known_variables = []
    for meta in sources.values():
        for var in meta.get("variables") or []:
            if isinstance(var, dict) and var.get("id"):
                known_variables.append(str(var["id"]))
            elif isinstance(var, str):
                known_variables.append(var)

    dataset_to_vars, variable_to_datasets = _dataset_variable_index(sources)

    pair_counter: Counter = Counter()
    dataset_counter: Counter = Counter()
    variable_counter: Counter = Counter()

    try:
        events_qs = DataAccessEvent.objects.order_by("-timestamp")
        if user_id:
            events_qs = events_qs.filter(user_id=str(user_id))
        events = list(events_qs[:120])
    except Exception:
        events = []

    for event in events:
        query = (event.query_text or "").strip()
        dataset_mentions = _safe_json_list(event.datasets_mentioned)
        if not dataset_mentions:
            for sid, name in known_datasets.items():
                if sid.replace("_", "-") in query.lower() or name.lower() in query.lower():
                    dataset_mentions.append(sid)
        variable_mentions = _extract_variable_mentions(query, known_variables)

        for ds in dataset_mentions:
            ds_slug = _slug(ds)
            if ds_slug:
                dataset_counter[ds_slug] += 1
        for var in variable_mentions:
            variable_counter[_slug(var)] += 1
        for ds in dataset_mentions:
            for var in variable_mentions:
                pair_counter[(_slug(var), _slug(ds))] += 1

    if not pair_counter:
        # Fallback to user prompts in chat history when structured access events are sparse.
        try:
            chat_qs = ChatMessage.objects(role="user").order_by("-timestamp")
            chat_rows = list(chat_qs[:120])
        except Exception:
            chat_rows = []

        for row in chat_rows:
            query = (row.content or "").strip()
            dataset_mentions = []
            for sid, name in known_datasets.items():
                sid_text = sid.replace("_", "-")
                if sid_text in query.lower() or name.lower() in query.lower():
                    dataset_mentions.append(sid)
            variable_mentions = _extract_variable_mentions(query, known_variables)
            for ds in dataset_mentions:
                dataset_counter[_slug(ds)] += 1
            for var in variable_mentions:
                variable_counter[_slug(var)] += 1
            for ds in dataset_mentions:
                for var in variable_mentions:
                    pair_counter[(_slug(var), _slug(ds))] += 1

    # Build analytical signals from structured events to support KG-driven review tasks.
    insights = _compute_query_pattern_insights(
        events=events,
        known_datasets=known_datasets,
        known_variables=known_variables,
        dataset_to_vars=dataset_to_vars,
        variable_to_datasets=variable_to_datasets,
        dataset_counter=dataset_counter,
    )

    top_pairs = pair_counter.most_common(30)

    dataset_label_by_slug = {_slug(k): v for k, v in known_datasets.items()}
    variable_label_by_slug = {_slug(v): _title_from_var_id(v) for v in known_variables}

    for (var_slug, ds_slug), count in top_pairs:
        _add_node(
            graph,
            seen_nodes,
            node_id=var_slug,
            label=str(variable_label_by_slug.get(var_slug) or var_slug.replace("_", " ").title()),
            node_type="variable",
            category="query_signal",
            metadata={"mention_count": int(variable_counter.get(var_slug, count))},
        )
        _add_node(
            graph,
            seen_nodes,
            node_id=ds_slug,
            label=dataset_label_by_slug.get(ds_slug, ds_slug.replace("_", " ").title()),
            node_type="dataset",
            category="query_target",
            metadata={"mention_count": int(dataset_counter.get(ds_slug, count))},
        )
        _add_edge(
            graph,
            seen_edges,
            source=var_slug,
            target=ds_slug,
            relationship="queried_with",
            count=int(count),
            confidence=_confidence_from_count(int(count), default=0.55),
            edge_kind="semantic",
            extraction_source="activity",
        )

    # Merge recent extracted query triples so concrete prompts (intent/location/dataset usage)
    # appear directly in query-pattern KG.
    query_triple_count = 0
    try:
        from models import KnowledgeTriple

        q = KnowledgeTriple.objects(source_kind="query", status__ne="rejected")
        if user_id:
            q = q.filter(user_id=str(user_id))
        triples = list(q.order_by("-updated_at")[:240])

        for t in triples:
            subj_type = (t.subject_type or "concept").strip().lower() or "concept"
            obj_type = (t.object_type or "concept").strip().lower() or "concept"
            rel = (t.predicate or "related_to").strip().lower() or "related_to"

            _add_node(
                graph,
                seen_nodes,
                node_id=t.subject_id,
                label=t.subject_label or t.subject_id,
                node_type=subj_type,
                category="query_extracted",
                metadata={
                    "confidence": float(t.confidence or 0.0),
                    "status": t.status,
                    "source": "knowledge_triple",
                },
            )
            _add_node(
                graph,
                seen_nodes,
                node_id=t.object_id,
                label=t.object_label or t.object_id,
                node_type=obj_type,
                category="query_extracted",
                metadata={
                    "confidence": float(t.confidence or 0.0),
                    "status": t.status,
                    "source": "knowledge_triple",
                },
            )
            _add_edge(
                graph,
                seen_edges,
                source=t.subject_id,
                target=t.object_id,
                relationship=rel,
                count=max(1, int(round((t.confidence or 0.0) * 10))),
                confidence=float(t.confidence or 0.0),
                edge_kind="semantic",
                extraction_source=_canonical_extraction_source(getattr(t, "extraction_method", "heuristic")),
            )
            query_triple_count += 1
    except Exception:
        query_triple_count = 0

    if not top_pairs and query_triple_count == 0:
        graph["stats"]["message"] = "Not enough user activity yet to build query patterns."
        return _finalize(graph)

    _merge_approved_triples(graph, seen_nodes, seen_edges, user_id=user_id)

    if insights:
        graph.setdefault("stats", {})
        graph["stats"]["insights"] = insights
    graph.setdefault("stats", {})
    graph["stats"]["query_triples_used"] = int(query_triple_count)

    return _finalize(graph)


def build_variable_graph(user_id: str = None) -> Dict[str, Any]:
    """Build variable-to-dataset graph from data_registry.yml with deduplicated nodes."""
    graph = _new_graph()
    seen_nodes, seen_edges = set(), set()

    sources = _load_registry_sources()
    if not sources:
        graph["stats"]["message"] = "No dataset registry sources found."
        return _finalize(graph)

    variable_to_sources: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"datasets": set(), "desc": ""})

    for source_id, meta in sources.items():
        source_slug = _slug(source_id)
        source_name = meta.get("name") or source_id
        _add_node(
            graph,
            seen_nodes,
            node_id=source_slug,
            label=source_name,
            node_type="dataset",
            category=(meta.get("access_pattern") or "unknown").lower(),
            metadata={"description": meta.get("description", "")},
        )

        for var in meta.get("variables") or []:
            if isinstance(var, dict):
                var_id = (var.get("id") or "").strip()
                var_desc = (var.get("description") or "").strip()
            else:
                var_id = str(var).strip()
                var_desc = ""
            if not var_id:
                continue

            var_slug = _slug(var_id)
            variable_to_sources[var_slug]["datasets"].add(source_name)
            if var_desc and not variable_to_sources[var_slug]["desc"]:
                variable_to_sources[var_slug]["desc"] = var_desc

            _add_edge(
                graph,
                seen_edges,
                source=source_slug,
                target=var_slug,
                relationship="provides",
                confidence=0.90,
                edge_kind="semantic",
                extraction_source="registry",
            )

    for var_slug, payload in variable_to_sources.items():
        datasets = sorted(payload["datasets"])
        desc = payload["desc"]
        display_var_id = var_slug
        _add_node(
            graph,
            seen_nodes,
            node_id=var_slug,
            label=_title_from_var_id(display_var_id),
            node_type="variable",
            category=_infer_variable_category(display_var_id, desc),
            metadata={
                "description": desc,
                "available_in": len(datasets),
                "datasets": datasets,
            },
        )

    _merge_approved_triples(graph, seen_nodes, seen_edges, user_id=user_id)
    return _finalize(graph)


def build_spatial_graph(user_id: str = None) -> Dict[str, Any]:
    """Build dataset-to-spatial-coverage graph using registry metadata/description heuristics."""
    graph = _new_graph()
    seen_nodes, seen_edges = set(), set()

    sources = _load_registry_sources()
    if not sources:
        graph["stats"]["message"] = "No dataset registry sources found."
        return _finalize(graph)

    for source_id, meta in sources.items():
        dataset_slug = _slug(source_id)
        name = meta.get("name") or source_id
        description = (meta.get("description") or "").strip()

        _add_node(
            graph,
            seen_nodes,
            node_id=dataset_slug,
            label=name,
            node_type="dataset",
            category=(meta.get("access_pattern") or "unknown").lower(),
            metadata={"description": description},
        )

        desc_lower = description.lower()
        if "north america" in desc_lower:
            coverage_label = "North America"
        elif "global" in desc_lower:
            coverage_label = "Global"
        elif "regional" in desc_lower:
            coverage_label = "Regional"
        else:
            coverage_label = "Unspecified Coverage"

        coverage_slug = _slug(f"coverage_{coverage_label}")
        _add_node(
            graph,
            seen_nodes,
            node_id=coverage_slug,
            label=coverage_label,
            node_type="scenario",
            category="spatial_coverage",
            metadata={"kind": "coverage"},
        )
        _add_edge(
            graph,
            seen_edges,
            source=dataset_slug,
            target=coverage_slug,
            relationship="covers",
            confidence=0.80,
            edge_kind="semantic",
            extraction_source="registry",
        )

    _merge_approved_triples(graph, seen_nodes, seen_edges, user_id=user_id)
    return _finalize(graph)


def get_graph_data(graph_type: str, user_id: str = None) -> Dict[str, Any]:
    """Get knowledge graph data by type."""
    graph_type = (graph_type or "").strip().lower()
    if graph_type == "datasets":
        return build_dataset_graph(user_id)
    if graph_type == "query-patterns":
        return build_query_pattern_graph(user_id)
    if graph_type == "variables":
        return build_variable_graph(user_id)
    if graph_type == "spatial":
        return build_spatial_graph(user_id)
    return _finalize(_new_graph())
