"""
Token counting and cost estimation for AI prompts and responses.
"""

import tiktoken
import logging
from typing import List, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Azure OpenAI pricing (as of 2024, update as needed)
# Prices are per 1M tokens
PRICING = {
    'gpt-4': {
        'input': 30.0,  # $30 per 1M input tokens
        'output': 60.0   # $60 per 1M output tokens
    },
    'gpt-4-turbo': {
        'input': 10.0,
        'output': 30.0
    },
    'gpt-35-turbo': {
        'input': 0.5,
        'output': 1.5
    },
    'gpt-4o': {
        'input': 5.0,
        'output': 15.0
    },
    'gpt-4o-mini': {
        'input': 0.15,
        'output': 0.6
    },
    'default': {
        'input': 1.0,
        'output': 3.0
    }
}


def count_tokens(text: str, model: str = "gpt-4") -> int:
    """
    Count tokens in a text string.
    
    Args:
        text: Text to count tokens for
        model: Model name (determines encoding)
    
    Returns:
        Number of tokens
    """
    try:
        # Try to get encoding for the model
        # Most Azure OpenAI models use cl100k_base encoding
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(text))
    except Exception as e:
        logger.warning(f"Token counting failed, using approximation: {e}")
        # Fallback: approximate 1 token = 4 characters
        return len(text) // 4


def count_messages_tokens(messages: List[Dict[str, str]], model: str = "gpt-4") -> int:
    """
    Count tokens in a list of messages (conversation format).
    
    Args:
        messages: List of message dicts with 'role' and 'content'
        model: Model name
    
    Returns:
        Total token count
    """
    total = 0
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
        
        # Add overhead for message formatting (approximately 4 tokens per message)
        total += len(messages) * 4
        
        for message in messages:
            role = message.get('role', '')
            content = message.get('content', '')
            
            # Count role tokens
            total += len(encoding.encode(role))
            
            # Count content tokens
            total += len(encoding.encode(content))
            
    except Exception as e:
        logger.warning(f"Token counting failed for messages, using approximation: {e}")
        # Fallback: approximate 1 token = 4 characters
        for message in messages:
            total += len(message.get('role', '')) // 4
            total += len(message.get('content', '')) // 4
        total += len(messages) * 4
        
    return total


def estimate_cost(input_tokens: int, output_tokens: int, model: str = "gpt-4") -> Dict[str, float]:
    """
    Estimate cost for a request.
    
    Args:
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        model: Model name
    
    Returns:
        Dictionary with cost breakdown
    """
    # Normalize model name
    model_lower = model.lower()
    
    # Find pricing (check for partial matches)
    pricing = PRICING.get('default')
    for key in PRICING:
        if key in model_lower or model_lower in key:
            pricing = PRICING[key]
            break
    
    input_cost = (input_tokens / 1_000_000) * pricing['input']
    output_cost = (output_tokens / 1_000_000) * pricing['output']
    total_cost = input_cost + output_cost
    
    return {
        'input_tokens': input_tokens,
        'output_tokens': output_tokens,
        'total_tokens': input_tokens + output_tokens,
        'input_cost_usd': round(input_cost, 6),
        'output_cost_usd': round(output_cost, 6),
        'total_cost_usd': round(total_cost, 6),
        'model': model,
        'pricing_tier': pricing
    }


def track_token_usage(user_id: str, session_id: str, model: str, 
                     input_tokens: int, output_tokens: int,
                     cost_estimate: Optional[Dict] = None, save_to_db: bool = True) -> Dict:
    """
    Track token usage and cost for a request.
    
    Args:
        user_id: User ID
        session_id: Session ID
        model: Model used
        input_tokens: Input token count
        output_tokens: Output token count
        cost_estimate: Optional pre-calculated cost estimate
        save_to_db: Whether to save to database (default True)
    
    Returns:
        Token usage record
    """
    if cost_estimate is None:
        cost_estimate = estimate_cost(input_tokens, output_tokens, model)
    
    usage_record = {
        'user_id': user_id,
        'session_id': session_id,
        'model': model,
        'timestamp': datetime.now().isoformat(),
        **cost_estimate
    }
    
    # Save to database if requested
    if save_to_db:
        try:
            from models import TokenUsage
            token_usage = TokenUsage(
                user_id=user_id,
                session_id=session_id,
                model=model,
                input_tokens=cost_estimate['input_tokens'],
                output_tokens=cost_estimate['output_tokens'],
                total_tokens=cost_estimate['total_tokens'],
                input_cost_usd=cost_estimate['input_cost_usd'],
                output_cost_usd=cost_estimate['output_cost_usd'],
                total_cost_usd=cost_estimate['total_cost_usd']
            )
            token_usage.save()
        except Exception as e:
            logger.error(f"Failed to save token usage to database: {e}")
    
    logger.info(f"Token usage tracked: user={user_id}, model={model}, "
                f"tokens={cost_estimate['total_tokens']}, cost=${cost_estimate['total_cost_usd']:.6f}")
    
    return usage_record


def get_user_token_stats(user_id: str, days: int = 30) -> Dict:
    """
    Get token usage statistics for a user.
    
    Args:
        user_id: User ID
        days: Number of days to look back
    
    Returns:
        Statistics dictionary
    """
    try:
        from models import TokenUsage
        from datetime import datetime, timedelta
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Query token usage from database
        usage_records = TokenUsage.objects(
            user_id=user_id,
            timestamp__gte=cutoff_date
        )
        
        total_requests = usage_records.count()
        total_tokens = sum(record.total_tokens for record in usage_records)
        total_cost = sum(record.total_cost_usd for record in usage_records)
        
        # Calculate average
        avg_tokens = total_tokens / total_requests if total_requests > 0 else 0
        
        # Find most used model
        model_counts = {}
        for record in usage_records:
            model_counts[record.model] = model_counts.get(record.model, 0) + 1
        most_used_model = max(model_counts.items(), key=lambda x: x[1])[0] if model_counts else None
        
        return {
            'user_id': user_id,
            'period_days': days,
            'total_requests': total_requests,
            'total_tokens': total_tokens,
            'total_cost_usd': round(total_cost, 6),
            'average_tokens_per_request': round(avg_tokens, 2),
            'most_used_model': most_used_model,
            'model_breakdown': model_counts
        }
    except Exception as e:
        logger.error(f"Failed to get token stats: {e}")
        # Return empty stats on error
        return {
            'user_id': user_id,
            'period_days': days,
            'total_requests': 0,
            'total_tokens': 0,
            'total_cost_usd': 0.0,
            'average_tokens_per_request': 0,
            'most_used_model': None,
            'model_breakdown': {}
        }
