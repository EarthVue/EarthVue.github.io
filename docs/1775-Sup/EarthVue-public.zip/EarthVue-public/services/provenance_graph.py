"""
Build a unified provenance DAG (nodes + edges) for AI-assisted analysis traces.

Used by the reasoning dashboard to visualize query → evidence → reasoning →
evaluation → uncertainty / bias / data-trust in one navigable structure.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from typing import Any, Dict, List, Optional, Set, Tuple

# Agent tool names bound in langchain_client._get_earthvue_tools (MCP-style plane)
EARTHVUE_AGENT_TOOL_NAMES = frozenset(
    {
        "list_datasets",
        "list_variables",
        "load_dataset",
        "execute_code",
        "statistical_analysis",
        "llm_judge",
        "extract_reasoning_steps",
    }
)


def _safe_json(value: Any, default):
    if value is None:
        return default
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        if not value.strip():
            return default
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return default
    return default


def _truncate(text: str, max_len: int = 72) -> str:
    t = (text or "").replace("\n", " ").strip()
    if len(t) <= max_len:
        return t
    return t[: max_len - 1] + "…"


def _extract_model_name(model_params: Dict[str, Any]) -> str:
    if not isinstance(model_params, dict):
        return ""
    for k in (
        "model",
        "model_name",
        "deployment_name",
        "deployment",
        "llm_model",
        "engine",
    ):
        v = model_params.get(k)
        if v is not None and str(v).strip():
            return str(v).strip()
    nested = model_params.get("model_config")
    if isinstance(nested, dict):
        for k in ("model", "model_name", "deployment_name", "deployment"):
            v = nested.get(k)
            if v is not None and str(v).strip():
                return str(v).strip()
    return ""


def _evidence_label(doc: Any, index: int) -> Tuple[str, str]:
    """Return (short label, longer detail) for a retrieved document entry."""
    if isinstance(doc, dict):
        title = (
            doc.get("title")
            or doc.get("name")
            or doc.get("source")
            or doc.get("id")
            or doc.get("dataset_id")
        )
        snippet = doc.get("content") or doc.get("text") or doc.get("snippet") or ""
        label = _truncate(str(title or f"Evidence {index + 1}"), 56)
        detail = _truncate(str(snippet), 200) if snippet else ""
        return label, detail
    s = str(doc).strip()
    return _truncate(s or f"Evidence {index + 1}", 56), _truncate(s, 200)


def _dataset_logic_summary(logic: Any) -> Tuple[str, str]:
    if not logic:
        return "Dataset selection", ""
    if isinstance(logic, str):
        return "Dataset selection", _truncate(logic, 240)
    if isinstance(logic, dict):
        for key in (
            "summary",
            "rationale",
            "reasoning",
            "primary_dataset",
            "selected_datasets",
        ):
            if key in logic and logic[key]:
                raw = logic[key]
                if isinstance(raw, list):
                    raw = ", ".join(str(x) for x in raw[:5])
                return "Dataset selection", _truncate(str(raw), 240)
        keys = list(logic.keys())[:5]
        return "Dataset selection", _truncate(
            "Factors: " + ", ".join(str(k) for k in keys), 240
        )
    return "Dataset selection", _truncate(str(logic), 240)


def _step_label(step: Any, index: int) -> Tuple[str, str]:
    if isinstance(step, dict):
        stype = step.get("type") or step.get("category") or "step"
        desc = (
            step.get("description")
            or step.get("reasoning")
            or step.get("action")
            or ""
        )
        label = _truncate(str(stype).replace("_", " "), 48)
        detail = _truncate(str(desc), 220)
        return label, detail
    return f"Step {index + 1}", _truncate(str(step), 220)


def _bias_label(b: Any, index: int) -> Tuple[str, str]:
    if isinstance(b, dict):
        t = b.get("type") or b.get("name") or "Bias"
        sev = b.get("severity", "")
        desc = b.get("description") or b.get("detail") or ""
        label = _truncate(f"{t}" + (f" ({sev})" if sev else ""), 52)
        return label, _truncate(str(desc), 180)
    return f"Bias {index + 1}", _truncate(str(b), 180)


def _uncertainty_label(u: Dict[str, Any], index: int) -> Tuple[str, str]:
    t = u.get("type") or "uncertainty"
    src = u.get("source") or u.get("description") or ""
    label = _truncate(f"{t}", 44)
    detail = _truncate(str(src), 200)
    return label, detail


def _kv_table(obj: Any, max_pairs: int = 36) -> List[List[str]]:
    """Flatten mapping to string pairs for inspector tables."""
    out: List[List[str]] = []
    if isinstance(obj, dict):
        for k, v in list(obj.items())[:max_pairs]:
            if isinstance(v, (dict, list)):
                v = _truncate(json.dumps(v, default=str), 600)
            else:
                v = _truncate(str(v), 900)
            out.append([str(k), v])
    return out


def _meta_query(user_query: str) -> Dict[str, Any]:
    return {
        "title": "Analyst question",
        "subtitle": _truncate(user_query, 100),
        "sections": [{"title": "Full query", "body": (user_query or "")[:20000]}],
    }


def _normalize_provenance_entry(raw: Any, index: int) -> Dict[str, Any]:
    """Coerce trace list items to dicts for classification."""
    if isinstance(raw, dict):
        return raw
    return {
        "title": f"Context {index + 1}",
        "content": str(raw),
        "metadata": {"provenance_kind": "context_blob"},
    }


def _is_mcp_tool_doc(d: Dict[str, Any]) -> bool:
    md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
    if md.get("provenance_kind") == "mcp_tool":
        return True
    if md.get("source") == "earthvue_tool_plane":
        return True
    if md.get("tool"):
        return True
    title = (d.get("title") or "").strip()
    if title in EARTHVUE_AGENT_TOOL_NAMES:
        return True
    return False


def _is_rag_or_context_doc(d: Dict[str, Any]) -> bool:
    """Knowledge / retrieval chunks (not agent tool plane)."""
    if _is_mcp_tool_doc(d):
        return False
    md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
    if md.get("provenance_kind") in ("rag_chunk", "retrieval", "azure_search"):
        return True
    if md.get("retrieval_engine") == "azure_ai_search":
        return True
    if str(md.get("source") or "").lower() in ("azure_ai_search", "azure_search"):
        return True
    if d.get("page_content") is not None:
        return True
    if any(
        d.get(k)
        for k in ("content", "text", "snippet", "document", "source_document")
    ):
        return True
    return False


def merge_tools_used_marker_into_provenance(
    retrieved_docs: Optional[List[Any]], raw_response_with_markers: str
) -> List[Any]:
    """
    The chat stream may include <!--TOOLS_USED:["tool",...]--> after tool rounds.
    Merge any tool names not already represented in retrieved_docs so traces still
    list every MCP tool even if the sink was truncated or failed to append.
    """
    out: List[Any] = list(retrieved_docs) if retrieved_docs else []
    if not raw_response_with_markers:
        return out
    m = re.search(r"<!--TOOLS_USED:\s*(\[[\s\S]*?\])\s*-->", raw_response_with_markers)
    if not m:
        return out
    try:
        names = json.loads(m.group(1))
    except (json.JSONDecodeError, TypeError):
        return out
    if not isinstance(names, list):
        return out

    def _existing_tools(docs: List[Any]) -> Set[str]:
        seen: Set[str] = set()
        for d in docs:
            if not isinstance(d, dict):
                continue
            md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
            t = md.get("tool") or d.get("title")
            if t:
                seen.add(str(t))
        return seen

    have = _existing_tools(out)
    for nm in names:
        s = str(nm).strip() if nm is not None else ""
        if not s or s in have:
            continue
        have.add(s)
        out.append(
            {
                "title": s,
                "content": "Tool appears in TOOLS_USED stream marker; detailed I/O may be missing for this trace.",
                "metadata": {
                    "tool": s,
                    "provenance_kind": "mcp_tool",
                    "source": "tools_used_marker",
                },
            }
        )
    return out


def partition_retrieved_documents(
    docs: List[Any],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Split persisted retrieved_documents into MCP tool calls, RAG/knowledge chunks, and other.
    Order within each bucket matches the original list.
    """
    mcp: List[Dict[str, Any]] = []
    rag: List[Dict[str, Any]] = []
    other: List[Dict[str, Any]] = []
    for i, raw in enumerate(docs):
        d = _normalize_provenance_entry(raw, i)
        if _is_mcp_tool_doc(d):
            mcp.append(d)
        elif _is_rag_or_context_doc(d):
            rag.append(d)
        else:
            other.append(d)
    return mcp, rag, other


def _meta_tool_invocation(doc: Dict[str, Any], index: int) -> Dict[str, Any]:
    md = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    name = str(md.get("tool") or doc.get("title") or f"tool_{index + 1}")
    args = md.get("args")
    body = doc.get("content") or ""
    sections: List[Dict[str, Any]] = []
    if args is not None:
        if isinstance(args, dict):
            sections.append({"title": "Tool arguments", "kv": _kv_table(args)})
        else:
            sections.append({"title": "Tool arguments", "body": str(args)[:12000]})
    if body:
        sections.append(
            {
                "title": "Result summary",
                "body": str(body)[:20000],
            }
        )
    plane = md.get("mcp_plane") or md.get("source") or "agent_tools"
    sections.append(
        {
            "title": "Provenance",
            "kv": [
                ["tool", name],
                ["plane", str(plane)],
                ["provenance_kind", str(md.get("provenance_kind") or "mcp_tool")],
            ],
        }
    )
    return {"title": name, "sections": sections}


def _meta_mcp_tools_aggregate(tool_docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    names = []
    for d in tool_docs:
        md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
        names.append(str(md.get("tool") or d.get("title") or "tool"))
    counts = Counter(names)
    subcategories: List[Dict[str, Any]] = []
    per_name: Dict[str, int] = {}
    for i, d in enumerate(tool_docs):
        md = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
        base = str(md.get("tool") or d.get("title") or "tool")
        per_name[base] = per_name.get(base, 0) + 1
        n_dup = counts[base]
        label = base if n_dup <= 1 else f"{base} · {per_name[base]}"
        inner = _meta_tool_invocation(d, i)
        detail = _truncate(
            str(d.get("content") or "") or str(md.get("args") or ""), 160
        )
        subcategories.append(
            {
                "label": label,
                "detail": detail,
                "title": inner.get("title", label),
                "sections": inner.get("sections", []),
            }
        )
    n = len(tool_docs)
    return {
        "title": "MCP & agent tools",
        "subtitle": f"{n} invocation{'s' if n != 1 else ''} (list/load/code/stats/…)",
        "subcategories": subcategories,
        "sections": [],
    }


def _meta_rag_aggregate(rag_docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    subcategories: List[Dict[str, Any]] = []
    for i, doc in enumerate(rag_docs):
        label, detail = _evidence_label(doc, i)
        inner = _meta_evidence(doc, i)
        subcategories.append(
            {
                "label": label,
                "detail": detail,
                "title": inner.get("title", label),
                "sections": inner.get("sections", []),
            }
        )
    n = len(rag_docs)
    return {
        "title": "RAG & retrieved context",
        "subtitle": f"{n} chunk{'s' if n != 1 else ''} / sources",
        "subcategories": subcategories,
        "sections": [],
    }


def _meta_other_sources_aggregate(other_docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    subcategories: List[Dict[str, Any]] = []
    for i, doc in enumerate(other_docs):
        label, detail = _evidence_label(doc, i)
        inner = _meta_evidence(doc, i)
        subcategories.append(
            {
                "label": label or f"Source {i + 1}",
                "detail": detail,
                "title": inner.get("title", label),
                "sections": inner.get("sections", []),
            }
        )
    n = len(other_docs)
    return {
        "title": "Other provenance",
        "subtitle": f"{n} record{'s' if n != 1 else ''} (non-tool, non-RAG shape)",
        "subcategories": subcategories,
        "sections": [],
    }


def _meta_evidence(doc: Any, index: int) -> Dict[str, Any]:
    """Rich inspector payload for RAG chunks or tool-grounding records."""
    if isinstance(doc, dict):
        title = str(
            doc.get("title")
            or doc.get("name")
            or doc.get("id")
            or f"Retrieved {index + 1}"
        )
        body = (
            doc.get("content")
            or doc.get("text")
            or doc.get("snippet")
            or doc.get("page_content")
            or ""
        )
        sections: List[Dict[str, Any]] = []
        if body:
            sections.append(
                {"title": "Content / tool output", "body": str(body)[:20000]}
            )
        md = doc.get("metadata")
        if isinstance(md, dict) and md:
            ds_keys = (
                "dataset_id",
                "dataset_name",
                "data_source",
                "source",
                "filepath",
                "file_path",
                "catalog",
                "index_name",
            )
            ds_rows = [
                [k, str(md[k])]
                for k in ds_keys
                if md.get(k) is not None and str(md.get(k)).strip() != ""
            ]
            if ds_rows:
                sections.append(
                    {"title": "Dataset / source hints (from metadata)", "kv": ds_rows}
                )
            sections.append({"title": "Metadata (structured)", "kv": _kv_table(md)})
        extra_kv: List[List[str]] = []
        for key in sorted(doc.keys()):
            if key in ("content", "text", "snippet", "page_content", "metadata"):
                continue
            v = doc[key]
            if isinstance(v, (dict, list)):
                v = _truncate(json.dumps(v, default=str), 800)
            else:
                v = str(v)[:1200]
            extra_kv.append([str(key), v])
        if extra_kv:
            sections.append({"title": "Additional fields", "kv": extra_kv[:36]})
        return {
            "title": title,
            "subtitle": _truncate(str(body), 110) if body else "",
            "sections": sections,
        }
    s = str(doc)
    return {
        "title": f"Evidence {index + 1}",
        "subtitle": _truncate(s, 110),
        "sections": [{"title": "Raw value", "body": s[:20000]}],
    }


def _meta_dataset_logic(logic: Any) -> Dict[str, Any]:
    sections: List[Dict[str, Any]] = []
    if isinstance(logic, dict):
        sections.append({"title": "Key–value", "kv": _kv_table(logic)})
        sections.append(
            {
                "title": "JSON encoding",
                "body": json.dumps(logic, indent=2, default=str)[:20000],
            }
        )
    elif isinstance(logic, str):
        sections.append({"title": "Rationale text", "body": logic[:20000]})
    else:
        sections.append({"title": "Value", "body": str(logic)[:8000]})
    return {"title": "Dataset selection logic", "sections": sections}


def _meta_reasoning_step(step: Any, index: int) -> Dict[str, Any]:
    sections: List[Dict[str, Any]] = []
    if isinstance(step, dict):
        sections.append(
            {
                "title": "Full step (JSON)",
                "body": json.dumps(step, indent=2, default=str)[:16000],
            }
        )
        if step.get("confidence") is not None:
            sections.append(
                {"title": "Confidence signal", "body": str(step.get("confidence"))}
            )
        iu = step.get("inputs_used")
        if iu:
            sections.append({"title": "Inputs used", "body": str(iu)[:8000]})
    else:
        sections.append({"title": "Step", "body": str(step)[:16000]})
    return {"title": f"Reasoning step {index + 1}", "sections": sections}


def _meta_evaluation(qs: Dict[str, Any]) -> Dict[str, Any]:
    rows: List[List[str]] = []
    for k in (
        "overall",
        "coherence",
        "accuracy",
        "completeness",
        "dataset_appropriateness",
    ):
        if k in qs and qs[k] is not None:
            rows.append([k, str(qs[k])])
    sections: List[Dict[str, Any]] = [{"title": "Scores", "kv": rows}]
    for ek in (
        "coherence_explanation",
        "accuracy_explanation",
        "completeness_explanation",
        "dataset_appropriateness_explanation",
    ):
        if qs.get(ek):
            sections.append(
                {
                    "title": ek.replace("_", " ").title(),
                    "body": str(qs[ek])[:12000],
                }
            )
    return {"title": "Automated evaluation", "sections": sections}


def _meta_uncertainty(u: Dict[str, Any]) -> Dict[str, Any]:
    rows = _kv_table(
        {k: v for k, v in u.items() if v is not None and str(v) != ""},
        max_pairs=20,
    )
    return {
        "title": str(u.get("type") or "Uncertainty"),
        "sections": [{"title": "Fields", "kv": rows}],
    }


def _meta_uncertainties_aggregate(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Single graph node: all uncertainty records as subcategories."""
    subcategories: List[Dict[str, Any]] = []
    for i, u in enumerate(items):
        label, detail = _uncertainty_label(u, i)
        inner = _meta_uncertainty(u)
        subcategories.append(
            {
                "label": label,
                "detail": detail,
                "title": inner.get("title", label),
                "sections": inner.get("sections", []),
            }
        )
    n = len(items)
    return {
        "title": "Uncertainties",
        "subtitle": f"{n} factor{'s' if n != 1 else ''}",
        "subcategories": subcategories,
        "sections": [],
    }


def _meta_bias(b: Any) -> Dict[str, Any]:
    if isinstance(b, dict):
        return {
            "title": str(b.get("type") or "Bias"),
            "sections": [
                {
                    "title": "Full record",
                    "body": json.dumps(b, indent=2, default=str)[:12000],
                },
                {"title": "Fields", "kv": _kv_table(b)},
            ],
        }
    return {"title": "Bias", "sections": [{"title": "Value", "body": str(b)[:8000]}]}


def _meta_biases_aggregate(items: List[Any]) -> Dict[str, Any]:
    """Single graph node: all bias records as subcategories."""
    subcategories: List[Dict[str, Any]] = []
    for i, b in enumerate(items):
        label, detail = _bias_label(b, i)
        inner = _meta_bias(b)
        subcategories.append(
            {
                "label": label,
                "detail": detail,
                "title": inner.get("title", label),
                "sections": inner.get("sections", []),
            }
        )
    n = len(items)
    return {
        "title": "Biases",
        "subtitle": f"{n} flag{'s' if n != 1 else ''}",
        "subcategories": subcategories,
        "sections": [],
    }


def _meta_data_trust(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "title": str(row.get("dataset_name") or "Dataset"),
        "sections": [{"title": "Catalog fields", "kv": _kv_table(row)}],
    }


def merge_uncertainty_records(
    trace_uncertainty_json: Any, db_events: List[Any]
) -> List[Dict[str, Any]]:
    """Combine Mongo AIUncertaintyEvent docs with JSON uncertainty_factors on the trace."""
    out: List[Dict[str, Any]] = []
    seen = set()

    for u in db_events:
        typ = getattr(u, "uncertainty_type", None) or ""
        src = getattr(u, "uncertainty_source", None) or ""
        key = (str(typ), str(src))
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "type": typ,
                "source": src,
                "confidence": float(getattr(u, "confidence_level", 0) or 0),
                "impact": getattr(u, "impact_assessment", "") or "",
                "mitigation": getattr(u, "mitigation_strategy", "") or "",
            }
        )

    raw = _safe_json(trace_uncertainty_json, [])
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, dict):
                typ = str(item.get("type", "unknown"))
                src = str(
                    item.get("description")
                    or item.get("source")
                    or item.get("uncertainty_source", "")
                )
                key = (typ, src)
                if key in seen:
                    continue
                seen.add(key)
                out.append(
                    {
                        "type": typ,
                        "source": src,
                        "confidence": float(item.get("confidence_level", 0) or 0),
                        "impact": str(item.get("impact_assessment", "") or ""),
                        "mitigation": str(item.get("mitigation_strategy", "") or ""),
                    }
                )
            else:
                s = str(item)
                key = ("factor", s)
                if key not in seen:
                    seen.add(key)
                    out.append(
                        {
                            "type": "factor",
                            "source": s,
                            "confidence": 0.0,
                            "impact": "",
                            "mitigation": "",
                        }
                    )

    return out


def build_provenance_graph(
    *,
    session_id: str,
    trace_id: Optional[str],
    user_query: str,
    retrieved_documents: Any,
    dataset_logic: Any,
    reasoning_steps: Any,
    quality_scores: Dict[str, Any],
    uncertainties: List[Dict[str, Any]],
    biases: Any,
    data_provenance_rows: List[Dict[str, Any]],
    model_parameters: Any,
    processing_time_ms: int = 0,
    assistant_response: str = "",
) -> Dict[str, Any]:
    """
    Returns { nodes, edges, legend, has_trace }.
    Each node: id, kind, rank, label, detail (optional).
    Each edge: source, target, kind.
    """
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, str]] = []

    if not trace_id:
        return {
            "has_trace": False,
            "session_id": session_id,
            "trace_id": None,
            "nodes": [],
            "edges": [],
            "legend": [],
        }

    docs = _safe_json(retrieved_documents, [])
    if not isinstance(docs, list):
        docs = []

    steps = _safe_json(reasoning_steps, [])
    if not isinstance(steps, list):
        steps = []

    bias_list = _safe_json(biases, [])
    if not isinstance(bias_list, list):
        bias_list = []

    model_params = _safe_json(model_parameters, {}) or {}

    # --- Nodes by layer (rank) for layout ---
    nodes.append(
        {
            "id": "q",
            "kind": "query",
            "rank": 0,
            "label": "User query",
            "detail": _truncate(user_query, 320),
            "layout_w": 224,
            "layout_h": 64,
            "meta": _meta_query(user_query),
        }
    )

    mcp_docs, rag_docs, other_docs = partition_retrieved_documents(docs)

    evidence_ids: List[str] = []
    if not mcp_docs and not rag_docs and not other_docs:
        nodes.append(
            {
                "id": "e_gap",
                "kind": "evidence_gap",
                "rank": 1,
                "label": "No grounding in trace",
                "detail": "No MCP tool calls, RAG chunks, or context blobs stored for this turn.",
                "layout_w": 212,
                "layout_h": 56,
                "meta": {
                    "title": "Missing grounding",
                    "sections": [
                        {
                            "title": "Why empty?",
                            "body": (
                                "This trace has no persisted provenance list. "
                                "Chat with agent tools records each tool call (datasets, variables, "
                                "load_dataset, execute_code, …) into the trace. "
                                "Retrieval/RAG chunks are shown separately from MCP tools when present. "
                                "Re-run a query to populate the graph."
                            ),
                        }
                    ],
                },
            }
        )
        evidence_ids.append("e_gap")
        edges.append({"source": "q", "target": "e_gap", "kind": "retrieval"})
    else:
        # Rank 1: RAG only (immediately after user query). MCP / other context rank 2.
        if rag_docs:
            eid = "rag"
            evidence_ids.append(eid)
            if len(rag_docs) == 1:
                d0 = rag_docs[0]
                em = _meta_evidence(d0, 0)
                label, detail = _evidence_label(d0, 0)
                nodes.append(
                    {
                        "id": eid,
                        "kind": "rag_context",
                        "rank": 1,
                        "label": label or "RAG / retrieved context",
                        "detail": detail,
                        "subtitle": em.get("subtitle") or "",
                        "layout_w": 236,
                        "layout_h": 108,
                        "meta": em,
                    }
                )
            else:
                agg_r = _meta_rag_aggregate(rag_docs)
                sc0 = agg_r["subcategories"][0] if agg_r.get("subcategories") else {}
                nodes.append(
                    {
                        "id": eid,
                        "kind": "rag_context",
                        "rank": 1,
                        "label": f"RAG & retrieved context ({len(rag_docs)})",
                        "detail": sc0.get("detail", ""),
                        "subtitle": agg_r.get("subtitle", ""),
                        "layout_w": 240,
                        "layout_h": 124,
                        "meta": agg_r,
                    }
                )
            edges.append({"source": "q", "target": eid, "kind": "rag_retrieval"})

        if mcp_docs:
            eid = "mcp"
            evidence_ids.append(eid)
            if len(mcp_docs) == 1:
                d0 = mcp_docs[0]
                tm = _meta_tool_invocation(d0, 0)
                md0 = d0.get("metadata") if isinstance(d0.get("metadata"), dict) else {}
                tname = str(md0.get("tool") or d0.get("title") or "tool")
                nodes.append(
                    {
                        "id": eid,
                        "kind": "mcp_tools",
                        "rank": 2,
                        "label": f"Tool · {tname}",
                        "detail": _truncate(str(d0.get("content") or ""), 200),
                        "subtitle": "MCP / agent tool plane",
                        "layout_w": 228,
                        "layout_h": 104,
                        "meta": tm,
                    }
                )
            else:
                agg_m = _meta_mcp_tools_aggregate(mcp_docs)
                sc0 = agg_m["subcategories"][0] if agg_m.get("subcategories") else {}
                nodes.append(
                    {
                        "id": eid,
                        "kind": "mcp_tools",
                        "rank": 2,
                        "label": f"MCP & agent tools ({len(mcp_docs)})",
                        "detail": sc0.get("detail", ""),
                        "subtitle": agg_m.get("subtitle", ""),
                        "layout_w": 236,
                        "layout_h": 124,
                        "meta": agg_m,
                    }
                )
            edges.append({"source": "q", "target": eid, "kind": "mcp_tool"})

        if other_docs:
            eid = "ctx"
            evidence_ids.append(eid)
            if len(other_docs) == 1:
                d0 = other_docs[0]
                em = _meta_evidence(d0, 0)
                label, detail = _evidence_label(d0, 0)
                nodes.append(
                    {
                        "id": eid,
                        "kind": "context_extra",
                        "rank": 2,
                        "label": label or "Additional context",
                        "detail": detail,
                        "subtitle": em.get("subtitle") or "",
                        "layout_w": 220,
                        "layout_h": 76,
                        "meta": em,
                    }
                )
            else:
                agg_o = _meta_other_sources_aggregate(other_docs)
                sc0 = agg_o["subcategories"][0] if agg_o.get("subcategories") else {}
                nodes.append(
                    {
                        "id": eid,
                        "kind": "context_extra",
                        "rank": 2,
                        "label": f"Other provenance ({len(other_docs)})",
                        "detail": sc0.get("detail", ""),
                        "subtitle": agg_o.get("subtitle", ""),
                        "layout_w": 228,
                        "layout_h": 92,
                        "meta": agg_o,
                    }
                )
            edges.append({"source": "q", "target": eid, "kind": "context"})

    ds_label, ds_detail = _dataset_logic_summary(dataset_logic)
    nodes.append(
        {
            "id": "ds",
            "kind": "dataset_logic",
            "rank": 2,
            "label": ds_label,
            "detail": ds_detail,
            "layout_w": 228,
            "layout_h": 88,
            "meta": _meta_dataset_logic(dataset_logic),
        }
    )
    edges.append({"source": "q", "target": "ds", "kind": "intent"})

    if model_params:
        model_name = _extract_model_name(model_params)
        sections = [
            {
                "title": "Parameters (JSON)",
                "body": json.dumps(model_params, indent=2, default=str)[:12000],
            },
            {"title": "Fields", "kv": _kv_table(model_params)},
        ]
        if model_name:
            sections.insert(0, {"title": "Model name", "body": model_name})
        nodes.append(
            {
                "id": "mp",
                "kind": "model",
                "rank": 2,
                "label": f"Model: {model_name}" if model_name else "Model & parameters",
                "detail": (
                    _truncate(f"Name: {model_name}", 120)
                    if model_name
                    else _truncate(json.dumps(model_params, default=str), 200)
                ),
                "layout_w": 212,
                "layout_h": 80,
                "meta": {
                    "title": "Inference configuration",
                    "sections": sections,
                },
            }
        )
        edges.append({"source": "q", "target": "mp", "kind": "config"})

    step_ids: List[str] = []
    for i, step in enumerate(steps):
        sid = f"s{i}"
        step_ids.append(sid)
        label, detail = _step_label(step, i)
        nodes.append(
            {
                "id": sid,
                "kind": "reasoning_step",
                "rank": 3,
                "label": label,
                "detail": detail,
                "layout_w": 214,
                "layout_h": 76,
                "meta": _meta_reasoning_step(step, i),
            }
        )
        if i > 0:
            edges.append(
                {"source": f"s{i - 1}", "target": sid, "kind": "chain"}
            )

    # Feed evidence + dataset logic into reasoning entry
    if step_ids:
        entry = step_ids[0]
        for eid in evidence_ids:
            edges.append({"source": eid, "target": entry, "kind": "supports"})
        edges.append({"source": "ds", "target": entry, "kind": "informs"})
        if any(n["id"] == "mp" for n in nodes):
            edges.append({"source": "mp", "target": entry, "kind": "settings"})
    else:
        # No explicit steps: bridge layer 1 → evaluation directly
        pass

    overall = quality_scores.get("overall")
    try:
        overall_f = float(overall) if overall is not None else None
    except (TypeError, ValueError):
        overall_f = None
    eval_detail_parts = []
    for key in ("coherence", "accuracy", "completeness", "dataset_appropriateness"):
        v = quality_scores.get(key)
        if v is not None:
            try:
                eval_detail_parts.append(f"{key}: {float(v):.2f}")
            except (TypeError, ValueError):
                eval_detail_parts.append(f"{key}: {v}")
    eval_detail = "; ".join(eval_detail_parts)
    expl = quality_scores.get("accuracy_explanation") or quality_scores.get(
        "coherence_explanation", ""
    )
    if expl:
        eval_detail = (eval_detail + " — " if eval_detail else "") + _truncate(
            str(expl), 160
        )

    nodes.append(
        {
            "id": "ev",
            "kind": "evaluation",
            "rank": 4,
            "label": "LLM evaluation"
            + (f" ({overall_f:.0%})" if overall_f is not None else ""),
            "detail": eval_detail or "Quality rubric scores",
            "layout_w": 236,
            "layout_h": 108,
            "meta": _meta_evaluation(quality_scores),
        }
    )

    if step_ids:
        edges.append({"source": step_ids[-1], "target": "ev", "kind": "judged"})
    else:
        for eid in evidence_ids:
            edges.append({"source": eid, "target": "ev", "kind": "supports"})
        edges.append({"source": "ds", "target": "ev", "kind": "informs"})
        if any(n["id"] == "mp" for n in nodes):
            edges.append({"source": "mp", "target": "ev", "kind": "settings"})

    if uncertainties:
        agg_u = _meta_uncertainties_aggregate(uncertainties)
        first_detail = (
            agg_u["subcategories"][0].get("detail", "")
            if agg_u.get("subcategories")
            else ""
        )
        nodes.append(
            {
                "id": "u",
                "kind": "uncertainty",
                "rank": 5,
                "label": "Uncertainties"
                + (f" ({len(uncertainties)})" if len(uncertainties) != 1 else ""),
                "detail": first_detail,
                "subtitle": agg_u.get("subtitle", ""),
                "layout_w": 232,
                "layout_h": 120,
                "meta": agg_u,
            }
        )
        edges.append({"source": "ev", "target": "u", "kind": "flags"})

    if bias_list:
        agg_b = _meta_biases_aggregate(bias_list)
        first_b = (
            agg_b["subcategories"][0].get("detail", "")
            if agg_b.get("subcategories")
            else ""
        )
        nodes.append(
            {
                "id": "b",
                "kind": "bias",
                "rank": 5,
                "label": "Biases"
                + (f" ({len(bias_list)})" if len(bias_list) != 1 else ""),
                "detail": first_b,
                "subtitle": agg_b.get("subtitle", ""),
                "layout_w": 232,
                "layout_h": 120,
                "meta": agg_b,
            }
        )
        edges.append({"source": "ev", "target": "b", "kind": "flags"})

    ar_clean = re.sub(r"<!--[\s\S]*?-->", "", str(assistant_response or "")).strip()
    if ar_clean:
        nodes.append(
            {
                "id": "ar",
                "kind": "assistant_response",
                "rank": 5,
                "label": "Assistant response",
                "detail": _truncate(ar_clean, 280),
                "layout_w": 248,
                "layout_h": 132,
                "meta": {
                    "title": "Assistant response",
                    "sections": [{"title": "Full text", "body": ar_clean[:50000]}],
                },
            }
        )
        edges.append({"source": "ev", "target": "ar", "kind": "output"})

    for i, row in enumerate(data_provenance_rows):
        pid = f"p{i}"
        name = row.get("dataset_name") or f"Dataset {i + 1}"
        sub = row.get("source_origin") or ""
        conf = row.get("confidence_level")
        conf_s = f"{float(conf):.0%}" if conf is not None else ""
        label = _truncate(str(name), 52)
        detail_parts = [sub, conf_s] if sub else [conf_s]
        detail = _truncate(" · ".join(x for x in detail_parts if x), 200)
        nodes.append(
            {
                "id": pid,
                "kind": "data_trust",
                "rank": 5,
                "label": label,
                "detail": detail,
                "layout_w": 202,
                "layout_h": 54,
                "meta": _meta_data_trust(row),
            }
        )
        edges.append({"source": "ds", "target": pid, "kind": "catalog"})
        edges.append({"source": "ev", "target": pid, "kind": "reviewed"})

    if processing_time_ms:
        nodes.append(
            {
                "id": "lat",
                "kind": "latency",
                "rank": 4,
                "label": f"Latency {processing_time_ms} ms",
                "detail": "Primary response generation time",
                "layout_w": 188,
                "layout_h": 72,
                "meta": {
                    "title": "Timing",
                    "sections": [
                        {
                            "title": "processing_time_ms",
                            "body": str(processing_time_ms),
                        }
                    ],
                },
            }
        )
        src_lat = step_ids[-1] if step_ids else "q"
        edges.append({"source": src_lat, "target": "lat", "kind": "metric"})

    edge_strength_by_kind = {
        "chain": 0.95,
        "output": 0.90,
        "judged": 0.90,
        "supports": 0.85,
        "rag_retrieval": 0.85,
        "mcp_tool": 0.85,
        "informs": 0.80,
        "settings": 0.80,
        "config": 0.75,
        "intent": 0.75,
        "context": 0.70,
        "retrieval": 0.70,
        "catalog": 0.65,
        "reviewed": 0.65,
        "flags": 0.60,
        "metric": 0.60,
    }
    for e in edges:
        strength = float(edge_strength_by_kind.get(str(e.get("kind") or ""), 0.70))
        e["strength"] = strength
        e["weight"] = round(1.0 + 2.0 * strength, 1)

    completeness_checks = [
        {
            "key": "grounding_records",
            "present": bool(mcp_docs or rag_docs or other_docs),
            "detail": f"mcp={len(mcp_docs)} rag={len(rag_docs)} other={len(other_docs)}",
        },
        {
            "key": "dataset_logic",
            "present": bool(dataset_logic),
            "detail": "Dataset-selection rationale persisted",
        },
        {
            "key": "reasoning_steps",
            "present": bool(steps),
            "detail": f"{len(steps)} reasoning step(s)",
        },
        {
            "key": "quality_scores",
            "present": bool(quality_scores),
            "detail": "Automated evaluation payload",
        },
        {
            "key": "uncertainties_or_biases",
            "present": bool(uncertainties or bias_list),
            "detail": f"uncertainties={len(uncertainties)} biases={len(bias_list)}",
        },
        {
            "key": "model_parameters",
            "present": bool(model_params),
            "detail": "Inference configuration persisted",
        },
        {
            "key": "assistant_response",
            "present": bool(ar_clean),
            "detail": "Final assistant text attached to trace",
        },
    ]
    complete_n = sum(1 for c in completeness_checks if c["present"])
    completeness_score = round(complete_n / float(len(completeness_checks)), 2)

    legend = [
        {"kind": "query", "label": "Analyst intent"},
        {"kind": "mcp_tools", "label": "MCP / agent tools"},
        {"kind": "rag_context", "label": "RAG & retrieved context"},
        {"kind": "context_extra", "label": "Other context"},
        {"kind": "evidence_gap", "label": "No grounding"},
        {"kind": "dataset_logic", "label": "Dataset selection logic"},
        {"kind": "model", "label": "Model configuration"},
        {"kind": "reasoning_step", "label": "Reasoning chain"},
        {"kind": "evaluation", "label": "Automated evaluation"},
        {"kind": "uncertainty", "label": "Uncertainties (all factors)"},
        {"kind": "bias", "label": "Biases (all flags)"},
        {"kind": "assistant_response", "label": "Assistant response"},
        {"kind": "data_trust", "label": "Data trust record"},
        {"kind": "latency", "label": "Timing"},
    ]

    return {
        "has_trace": True,
        "session_id": session_id,
        "trace_id": trace_id,
        "nodes": nodes,
        "edges": edges,
        "legend": legend,
        "completeness": {
            "score": completeness_score,
            "checks": completeness_checks,
        },
    }
