"""
Analytics and reasoning helpers shared across routes.
Moved from app.py to reduce app.py size and centralize analytics logic.
"""

import json
import logging
import os
import re
from datetime import datetime
from typing import Optional

import services.classic_assistant as classic_assistant
from models import (
    DataAccessEvent,
    UserExpertiseProfile,
    AIReasoningTrace,
    AIUncertaintyEvent,
    PlainLanguageSummary,
    DataProvenance,
)
from services.langchain_client import get_llm_for, chat_non_streaming


logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# LLM-Based Analytics Helper
# ──────────────────────────────────────────────────────────────────────────────

def analyze_with_llm(
    prompt: str,
    response_format: str = "json",
    system_content: Optional[str] = None,
) -> dict:
    """
    Helper function to call LLM for structured JSON analysis.
    Returns parsed JSON dict or empty dict on error.
    """
    try:
        # Prefer a lightweight, dedicated judge deployment if available.
        judge_deployment = (
            os.getenv("JUDGE_DEPLOYMENT_NAME")
            or os.getenv("DEPLOYMENT_NAME6")  # often a mini / cheaper model
            or None
        )

        default_system = (
            "You are an expert climate data analyst. Always respond with ONLY "
            "valid JSON, no markdown, no extra text, no code blocks. "
            "Start with { or ["
        )
        messages = [
            {
                "role": "system",
                "content": system_content or default_system,
            },
            {"role": "user", "content": prompt},
        ]

        # Use a smaller max_tokens to reduce latency and timeouts.
        response = chat_non_streaming(
            messages,
            temperature=0.1,
            max_tokens=800,
            deployment_name=judge_deployment,
        )

        # Clean up response
        response = response.strip()

        # Remove markdown code blocks
        if response.startswith("```json"):
            response = response[7:]
        if response.startswith("```"):
            response = response[3:]
        if response.endswith("```"):
            response = response[:-3]

        response = response.strip()

        # Find first { or [ and last } or ]
        start_idx = -1
        end_idx = -1

        for i, char in enumerate(response):
            if char in "{[":
                start_idx = i
                break

        if start_idx == -1:
            logger.warning(
                f"No JSON structure found in LLM response: {response[:100]}"
            )
            return {}

        for i in range(len(response) - 1, -1, -1):
            if response[i] in "}]":
                end_idx = i
                break

        if end_idx == -1:
            logger.warning(
                f"Incomplete JSON structure in LLM response: {response[:100]}"
            )
            return {}

        json_str = response[start_idx : end_idx + 1]
        return json.loads(json_str)

    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error in LLM response: {e}")
        return {}
    except Exception as e:
        logger.error(f"LLM analysis error: {e}")
        return {}


# ──────────────────────────────────────────────────────────────────────────────
# Accessibility Analytics Functions
# ──────────────────────────────────────────────────────────────────────────────

def calculate_query_complexity(query_text):
    """Calculate complexity score (1-5) using LLM classifier."""
    return classic_assistant.calculate_query_complexity(None, query_text)


def identify_accessibility_barriers(query_text, datasets_found):
    """Identify accessibility barriers using LLM analysis."""
    return classic_assistant.identify_accessibility_barriers(
        None, query_text, datasets_found
    )


def track_data_access_event(
    user_id,
    session_uuid,
    query_text,
    datasets_found=None,
    success_score=None,
    model=None,
):
    """Track user data access patterns for accessibility research - MongoEngine version."""
    try:
        # Calculate complexity
        complexity = calculate_query_complexity(query_text)

        # Identify barriers
        barriers = identify_accessibility_barriers(query_text, datasets_found or [])

        logger.info(
            f"📊 Tracking data access: user={user_id}, "
            f"query='{query_text[:50]}...', datasets={datasets_found}, "
            f"success={success_score}"
        )

        # Create event in MongoDB
        event = DataAccessEvent(
            user_id=user_id,
            session_uuid=session_uuid,
            query_text=query_text,
            datasets_mentioned=json.dumps(datasets_found)
            if datasets_found
            else "[]",
            model_used=model,
            success_score=success_score or 0.0,
            time_to_insight=0.0,  # Will be updated later
            complexity_level=complexity,
            accessibility_barriers=json.dumps(barriers),
        )
        event.save()
        logger.info(
            f"Saved DataAccessEvent: user={user_id}, "
            f"query='{query_text[:50]}...', datasets={datasets_found}, "
            f"complexity={complexity}"
        )
        return event
    except Exception as e:
        logger.error(f"❌ Error tracking data access: {e}")
        return None


def update_user_expertise(user_id, successful_query=None, dataset_used=None):
    """Update user expertise profile based on successful interactions using LLM assessment."""
    try:
        # Get or create user expertise profile
        profile = UserExpertiseProfile.objects(user_id=user_id).first()

        if not profile:
            profile = UserExpertiseProfile(
                user_id=user_id,
                expertise_level=1.0,
                preferred_datasets=json.dumps([]),
                successful_query_patterns=json.dumps([]),
            )

        # Update expertise level dynamically using LLM
        if successful_query:
            prompt = f"""A user with current climate data expertise level {profile.expertise_level:.1f} (scale 1.0 to 5.0) just successfully executed this query:
"{successful_query}"

Analyze the technical complexity of this query (use of xarray, specific climate variables, spatial/temporal logic).
Determine their new expertise level. It should gradually increase if the query demonstrates advanced knowledge, or stay the same if it's basic.

Return JSON:
{{
    "new_expertise_level": <float 1.0 to 5.0>,
    "reasoning": "brief explanation"
}}"""
            result = analyze_with_llm(prompt)
            new_level = result.get("new_expertise_level")
            if isinstance(new_level, (int, float)) and 1.0 <= new_level <= 5.0:
                profile.expertise_level = float(new_level)
                logger.info(f"LLM updated expertise to {profile.expertise_level} for user {user_id}. Reason: {result.get('reasoning')}")

        # Add to preferred datasets
        if dataset_used:
            datasets = json.loads(profile.preferred_datasets or "[]")
            if dataset_used not in datasets:
                datasets.append(dataset_used)
            profile.preferred_datasets = json.dumps(datasets[:10])  # Keep top 10

        # Add successful query pattern
        if successful_query:
            patterns = json.loads(profile.successful_query_patterns or "[]")
            patterns.append(successful_query[:100])  # Truncate
            profile.successful_query_patterns = json.dumps(patterns[-20:])  # Keep last 20

        profile.last_updated = datetime.now()
        profile.save()

        logger.info(f"User expertise updated for user {user_id}")
        return profile
    except Exception as e:
        logger.error(f"Error updating user expertise: {e}")
        return None


# ──────────────────────────────────────────────────────────────────────────────
# AI Reasoning & Uncertainty Tracking Functions
# ──────────────────────────────────────────────────────────────────────────────

_CODE_VIZ_QUERY = re.compile(
    r"\b(code|script|python|matplotlib|plot|chart|graph|visuali[sz]e|figure|heatmap|"
    r"cartopy|xarray|geopandas|notebook|snippet|jupyter|write\s+(me\s+)?code|"
    r"example\s+code|show\s+me\s+(how|the))\b",
    re.I,
)
_CODE_VIZ_RESPONSE = re.compile(
    r"```|import\s+[\w.]+|matplotlib|pyplot|plt\.|xarray|cartopy|seaborn|plot\(|\.savefig|"
    r"Dataset\.|xr\.open",
    re.I,
)


def _is_code_or_viz_task(user_query: Optional[str], response_content: Optional[str]) -> bool:
    u = (user_query or "").strip()
    r = response_content or ""
    if _CODE_VIZ_QUERY.search(u):
        return True
    if r.count("```") >= 2:
        return True
    if len(r) > 350 and _CODE_VIZ_RESPONSE.search(r):
        return True
    return False


def _excerpt_for_confidence_judge(response_content: Optional[str], code_viz: bool) -> str:
    """Avoid truncating long code answers at 1500 chars."""
    r = response_content or ""
    limit = 7000 if code_viz else 4000
    return r[:limit]


def _neutral_confidence_metrics(reason: str, overall: Optional[float] = None) -> dict:
    """Fallback when the judge fails or is unavailable."""
    o = 0.0 if overall is None else max(0.0, min(1.0, overall))
    base = o
    return {
        "coherence": base,
        "accuracy": base,
        "completeness": base,
        "dataset_appropriateness": base,
        "overall": o,
        "coherence_explanation": reason,
        "accuracy_explanation": reason,
        "completeness_explanation": reason,
        "dataset_appropriateness_explanation": reason,
    }


def _clamp01(x) -> float:
    try:
        return max(0.0, min(1.0, float(x)))
    except (TypeError, ValueError):
        return 0.0


def _merge_confidence_dict(raw: dict, code_viz: bool) -> dict:
    """Fill missing keys with 0; recompute overall if absent."""
    d = {
        "coherence": 0.0,
        "accuracy": 0.0,
        "completeness": 0.0,
        "dataset_appropriateness": 0.0,
        "overall": 0.0,
        "coherence_explanation": "",
        "accuracy_explanation": "",
        "completeness_explanation": "",
        "dataset_appropriateness_explanation": "",
    }
    for k in ("coherence", "accuracy", "completeness", "dataset_appropriateness"):
        if k in raw and raw[k] is not None:
            d[k] = _clamp01(raw[k])
    if raw.get("overall") is not None:
        d["overall"] = _clamp01(raw["overall"])
    else:
        d["overall"] = (
            d["coherence"] + d["accuracy"] + d["completeness"] + d["dataset_appropriateness"]
        ) / 4.0
    for ek in (
        "coherence_explanation",
        "accuracy_explanation",
        "completeness_explanation",
        "dataset_appropriateness_explanation",
    ):
        if raw.get(ek):
            d[ek] = str(raw[ek])
    # Code/viz: avoid collapsing overall if dataset dim was scored as N/A low
    if code_viz and d["dataset_appropriateness"] < 0.35 and d["coherence"] > 0.55:
        d["overall"] = max(
            d["overall"],
            (d["coherence"] + d["accuracy"] + d["completeness"]) / 3.0 * 0.90,
        )
        d["overall"] = min(1.0, d["overall"])
    return d


def calculate_response_confidence(
    response_content,
    retrieved_docs,
    conversation_history=None,
    user_query=None,
):
    """Calculate detailed quality metrics for response with explanations."""
    code_viz = _is_code_or_viz_task(user_query, response_content)
    excerpt = _excerpt_for_confidence_judge(response_content, code_viz)

    judge_system_code_viz = (
        "You are an expert evaluator of software, data visualization, and climate-related "
        "technical answers. Always respond with ONLY valid JSON, no markdown, no extra text, "
        "no code blocks. Start with {"
    )

    try:
        history_summary = ""
        if conversation_history and len(conversation_history) > 1:
            recent_exchanges = (
                conversation_history[-3:]
                if len(conversation_history) > 3
                else conversation_history
            )
            history_summary = "\nPrior context:\n"
            for msg in recent_exchanges:
                if isinstance(msg, dict):
                    role = msg.get("role", "user")
                    content = msg.get("content", "")[:200]
                    history_summary += f"- {role}: {content}\n"

        n_docs = len(retrieved_docs) if retrieved_docs else 0
        if code_viz:
            docs_info = (
                f"{n_docs} reference documents were retrieved (RAG). "
                "If the user asked only for code or a plot, missing RAG is normal — "
                "do NOT penalize accuracy or overall solely because few or no documents were retrieved."
            )
        else:
            docs_info = (
                f"{n_docs} documents retrieved"
                if retrieved_docs
                else "No documents retrieved"
            )

        user_q = (user_query or "").strip()
        query_line = f"User request: {user_q[:500]}\n\n" if user_q else ""

        if code_viz:
            prompt = f"""Assess quality for this assistant reply to a code, plotting, or visualization request.

{query_line}{history_summary}
Assistant response (may include code):
{excerpt}

Context: {docs_info}

Scoring rules:
- coherence: structure and clarity of explanation + code.
- accuracy: technical plausibility of libraries/APIs and climate-related statements (not encyclopedic fact-checking of every line).
- completeness: whether the answer addresses what the user asked (e.g. runnable sketch, plot pipeline, key steps).
- dataset_appropriateness: if a specific climate dataset/catalog is required, how well the answer matches; if the task does NOT require naming a dataset, score HIGH (around 0.8–1.0) when libraries/placeholders are appropriate; do NOT mark low only because no catalog was cited.
- overall: holistic usefulness for the user's request.

Return JSON:
{{
  "coherence": <0-1>,
  "accuracy": <0-1>,
  "completeness": <0-1>,
  "dataset_appropriateness": <0-1>,
  "overall": <0-1>,
  "coherence_explanation": "...",
  "accuracy_explanation": "...",
  "completeness_explanation": "...",
  "dataset_appropriateness_explanation": "..."
}}"""
            result = analyze_with_llm(prompt, system_content=judge_system_code_viz)
        else:
            prompt = f"""Assess quality metrics for this climate AI response.

{query_line}{history_summary}

Current Response: {excerpt}

Retrieved Context: {docs_info}

Return JSON with coherence, accuracy, completeness, dataset_appropriateness, and overall (each 0-1 float), and explanation:
{{
  "coherence": <0-1 logical flow and structure quality>,
  "accuracy": <0-1 factual correctness and specificity>,
  "completeness": <0-1 coverage of query aspects>,
  "dataset_appropriateness": <0-1 appropriateness of the selected dataset for this query>,
  "overall": <0-1 overall success and quality of the response>,
  "coherence_explanation": "...",
  "accuracy_explanation": "...",
  "completeness_explanation": "...",
  "dataset_appropriateness_explanation": "..."
}}"""
            result = analyze_with_llm(prompt)

        if result and isinstance(result, dict):
            if all(key in result for key in ["coherence", "accuracy", "completeness"]):
                merged = _merge_confidence_dict(result, code_viz)
                return merged
            # Partial JSON: merge what we have
            if any(
                k in result
                for k in ("coherence", "accuracy", "completeness", "overall")
            ):
                return _merge_confidence_dict(result, code_viz)
    except Exception as e:
        logger.warning(f"LLM confidence calculation failed: {e}")

    return _neutral_confidence_metrics("LLM judge unavailable or returned incomplete JSON")


def extract_reasoning_steps(user_query, response_content, conversation_history=None):
    """Extract a structured reasoning process using LLM analysis with conversation context."""
    try:
        # Build history context
        history_summary = ""
        if conversation_history and len(conversation_history) > 1:
            recent = conversation_history[-2:]
            history_summary = "\nPrior discussion:\n"
            for msg in recent:
                if isinstance(msg, dict):
                    history_summary += (
                        f"- {msg.get('role', 'unknown')}: "
                        f"{msg.get('content', '')[:150]}\n"
                    )

        prompt = f"""Extract reasoning steps from this climate AI response, considering conversation context.

{history_summary}
Current Query: {user_query[:300]}
Current Response: {response_content[:1500]}

Return JSON array with 3-5 steps. Each: {{"step": <int>, "type": <string>, "action": <string>, "description": <string>, "confidence": <float 0-1>, "depends_on": <optional list of earlier step numbers this step builds on; omit for a simple linear chain>}}

Step types: query_understanding, data_retrieval, analysis, reasoning, validation"""

        result = analyze_with_llm(prompt)
        if isinstance(result, list) and len(result) > 0:
            valid_steps = []
            for s in result:
                if isinstance(s, dict) and "step" in s and "action" in s:
                    valid_steps.append(s)
            if valid_steps:
                return valid_steps
    except Exception as e:
        logger.warning(f"Reasoning steps extraction failed: {e}")

    # Fallback if LLM unavailable
    return [
        {
            "step": 1,
            "type": "processing",
            "action": "Generate Response",
            "description": "LLM extraction failed or unavailable",
            "confidence": 0.0,
        }
    ]


def analyze_dataset_selection(user_query, response_content, retrieved_docs):
    """Analyze the logic behind dataset selection using LLM with weighted factors."""
    try:
        docs_summary = (
            f"{len(retrieved_docs)} documents retrieved"
            if retrieved_docs
            else "No documents retrieved"
        )

        prompt = f"""Analyze dataset selection in this climate AI response.

Query: {user_query[:300]}
Response: {response_content[:1500]}

Return JSON with:
- selected_datasets: array of {{"name", "rationale", "confidence"}}
- primary_factors: array of {{"factor": <string>, "value": <string or array>, "weight": <0-1 importance>}}
- constraints_considered: array of strings
- alternatives_evaluated: array of strings

Example primary_factors: [{{"factor": "Geographic Scope", "value": "Global", "weight": 0.4}}, {{"factor": "Temporal Range", "value": ["2020-2100"], "weight": 0.3}}]"""

        result = analyze_with_llm(prompt)
        if result and isinstance(result, dict):
            if "selected_datasets" in result or "primary_factors" in result:
                # Ensure primary_factors have proper structure
                if "primary_factors" in result and isinstance(
                    result["primary_factors"], list
                ):
                    for factor in result["primary_factors"]:
                        if isinstance(factor, dict) and "weight" not in factor:
                            factor["weight"] = 0.0  # Default weight
                return result
    except Exception as e:
        logger.warning(f"Dataset selection analysis failed: {e}")

    # Fallback with safe generic structure if LLM unavailable
    return {
        "selected_datasets": [],
        "primary_factors": [],
        "constraints_considered": [],
        "alternatives_evaluated": [],
    }


def extract_uncertainties(user_query, response_content, retrieved_docs):
    """Extract and categorize uncertainties using LLM analysis."""
    try:
        prompt = f"""Identify uncertainties in this climate AI response.

Query: {user_query[:300]}
Response: {response_content[:1500]}

Return JSON array of uncertainties. Each: {{"type": <string>, "source": <string>, "description": <string>, "impact": <string>, "confidence": <float 0-1>}}

Uncertainty types: model_uncertainty, data_quality, temporal_future, spatial_resolution, natural_variability, knowledge_gap, scenario_dependency, compound_effects"""

        result = analyze_with_llm(prompt)
        if isinstance(result, list) and len(result) > 0:
            # Validate uncertainty objects
            valid_uncertainties = []
            for u in result:
                if isinstance(u, dict) and "type" in u and "impact" in u:
                    valid_uncertainties.append(u)
            return valid_uncertainties
    except Exception as e:
        logger.warning(f"Uncertainty extraction failed: {e}")

    # Fallback
    return []


def detect_comprehensive_biases(user_query, response_content, retrieved_docs):
    """Detect potential biases using LLM analysis."""
    try:
        prompt = f"""Identify biases in this climate AI response.

Query: {user_query[:300]}
Response: {response_content[:1500]}

Return JSON array of biases. Each: {{"type": <string>, "severity": <string>, "description": <string>, "recommendation": <string>}}

Bias types: variable_focus, geographic, temporal, dataset_selection, accessibility, actionability, model_bias, resolution_bias, scenario_bias

If no biases found, return empty array []"""

        result = analyze_with_llm(prompt)
        if isinstance(result, list):
            # Validate bias objects
            valid_biases = []
            for b in result:
                if isinstance(b, dict) and "type" in b and "severity" in b:
                    valid_biases.append(b)
            return valid_biases
    except Exception as e:
        logger.warning(f"Bias detection failed: {e}")

    # Fallback
    return []


def track_ai_reasoning(
    user_id,
    session_uuid,
    user_query,
    response_content,
    retrieved_docs=None,
    processing_time_ms=0,
    conversation_history=None,
    model_name=None,
):
    """Capture comprehensive AI reasoning trace - MongoEngine version."""
    try:
        # Calculate detailed quality scores
        quality_metrics = calculate_response_confidence(
            response_content,
            retrieved_docs or [],
            conversation_history,
            user_query=user_query,
        )

        # Extract reasoning steps from response
        reasoning_steps = extract_reasoning_steps(
            user_query, response_content, conversation_history
        )

        # Analyze dataset selection logic
        dataset_logic = analyze_dataset_selection(
            user_query, response_content, retrieved_docs
        )

        # Comprehensive bias detection
        biases = detect_comprehensive_biases(
            user_query, response_content, retrieved_docs
        )

        # Extract uncertainties
        uncertainties = extract_uncertainties(
            user_query, response_content, retrieved_docs
        )

        model_params: dict = {"temperature": 0.7}
        if model_name is not None and str(model_name).strip():
            mn = str(model_name).strip()
            model_params["model_name"] = mn
            model_params["deployment_name"] = mn

        # Create reasoning trace in MongoDB
        reasoning_trace = AIReasoningTrace(
            session_uuid=session_uuid,
            user_id=user_id,
            user_query=user_query,
            assistant_response=response_content or "",
            reasoning_steps=json.dumps(reasoning_steps),
            dataset_selection_logic=json.dumps(dataset_logic),
            confidence_scores=json.dumps(quality_metrics),
            uncertainty_factors=json.dumps(uncertainties),
            retrieved_documents=json.dumps(retrieved_docs) if retrieved_docs else "[]",
            model_parameters=json.dumps(model_params),
            processing_time_ms=processing_time_ms,
            response_coherence_score=max(
                0.0, min(1.0, quality_metrics.get("coherence", 0.7))
            ),
            factual_accuracy_score=max(
                0.0, min(1.0, quality_metrics.get("accuracy", 0.7))
            ),
            completeness_score=max(
                0.0, min(1.0, quality_metrics.get("completeness", 0.7))
            ),
            dataset_appropriateness_score=max(
                0.0, min(1.0, quality_metrics.get("dataset_appropriateness", 0.7))
            ),
            bias_indicators=json.dumps(biases),
        )
        reasoning_trace.save()
        logger.info(
            f" Saved AIReasoningTrace: user={user_id}, session={session_uuid}, "
            f"query='{user_query[:50]}...', steps={len(reasoning_steps)}, "
            f"biases={len(biases)}"
        )
        return reasoning_trace
    except Exception as e:
        logger.error(f"Error tracking AI reasoning: {e}")
        return None

