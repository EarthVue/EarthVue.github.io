"""
Error handling utilities with retry logic and user-friendly error messages.
"""

import logging
import time
from functools import wraps
from typing import Callable, Any, Optional, TypeVar, Tuple
from flask import jsonify, request

logger = logging.getLogger(__name__)

T = TypeVar('T')


class AppError(Exception):
    """Base application error with user-friendly message"""
    def __init__(self, message: str, status_code: int = 500, user_message: Optional[str] = None):
        self.message = message
        self.status_code = status_code
        self.user_message = user_message or "An error occurred. Please try again later."
        super().__init__(self.message)


class ValidationError(AppError):
    """Input validation error"""
    def __init__(self, message: str, user_message: Optional[str] = None):
        super().__init__(message, status_code=400, user_message=user_message or f"Invalid input: {message}")


class NotFoundError(AppError):
    """Resource not found error"""
    def __init__(self, resource: str, user_message: Optional[str] = None):
        super().__init__(
            f"{resource} not found",
            status_code=404,
            user_message=user_message or f"The requested {resource} could not be found."
        )


class UnauthorizedError(AppError):
    """Unauthorized access error"""
    def __init__(self, user_message: Optional[str] = None):
        super().__init__(
            "Unauthorized",
            status_code=401,
            user_message=user_message or "You must be logged in to access this resource."
        )


class RateLimitError(AppError):
    """Rate limit exceeded error"""
    def __init__(self, user_message: Optional[str] = None):
        super().__init__(
            "Rate limit exceeded",
            status_code=429,
            user_message=user_message or "Too many requests. Please try again later."
        )


def retry_with_backoff(
    func: Callable[..., T],
    max_retries: int = 3,
    initial_delay: float = 1.0,
    backoff_factor: float = 2.0,
    exceptions: Tuple[type, ...] = (Exception,),
    logger_instance: Optional[logging.Logger] = None
) -> T:
    """
    Retry a function with exponential backoff.
    
    Args:
        func: Function to retry
        max_retries: Maximum number of retry attempts
        initial_delay: Initial delay in seconds
        backoff_factor: Multiplier for delay after each retry
        exceptions: Tuple of exceptions to catch and retry on
        logger_instance: Optional logger instance
    
    Returns:
        Result of the function call
    
    Raises:
        Last exception if all retries fail
    """
    log = logger_instance or logger
    delay = initial_delay
    
    for attempt in range(max_retries):
        try:
            return func()
        except exceptions as e:
            if attempt == max_retries - 1:
                log.error(f"Function {func.__name__} failed after {max_retries} attempts: {e}")
                raise
            
            log.warning(f"Function {func.__name__} failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {delay}s...")
            time.sleep(delay)
            delay *= backoff_factor
    
    raise Exception("Retry logic failed unexpectedly")


def handle_api_errors(f: Callable) -> Callable:
    """Decorator to handle API errors and return JSON responses"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except AppError as e:
            logger.error(f"Application error in {f.__name__}: {e.message}", exc_info=True)
            return jsonify({
                'error': e.user_message,
                'code': e.status_code,
                'details': e.message if logger.level <= logging.DEBUG else None
            }), e.status_code
        except Exception as e:
            logger.exception(f"Unexpected error in {f.__name__}: {e}")
            return jsonify({
                'error': 'An unexpected error occurred. Please try again later.',
                'code': 500
            }), 500
    return decorated_function


def format_user_friendly_error(error: Exception, context: Optional[dict] = None) -> str:
    """
    Format an error into a user-friendly message.
    
    Args:
        error: The exception that occurred
        context: Optional context dictionary with user_id, session_id, etc.
    
    Returns:
        User-friendly error message
    """
    if isinstance(error, AppError):
        return error.user_message
    
    error_type = type(error).__name__
    error_msg = str(error)
    
    # Map common errors to user-friendly messages
    error_mappings = {
        'ConnectionError': 'Unable to connect to the service. Please check your internet connection.',
        'TimeoutError': 'The request took too long. Please try again.',
        'ValueError': 'Invalid input provided. Please check your request.',
        'KeyError': 'Missing required information. Please check your request.',
        'AttributeError': 'An internal error occurred. Please try again.',
        'JSONDecodeError': 'Invalid data format. Please check your request.',
    }
    
    if error_type in error_mappings:
        return error_mappings[error_type]
    
    # For unknown errors, return generic message
    if context:
        logger.error(f"Error in context {context}: {error_type}: {error_msg}")
    else:
        logger.error(f"Error: {error_type}: {error_msg}")
    
    return "An error occurred while processing your request. Please try again."


def log_error_with_context(error: Exception, user_id: Optional[str] = None, 
                          session_id: Optional[str] = None, 
                          additional_context: Optional[dict] = None):
    """
    Log an error with context information.
    
    Args:
        error: The exception that occurred
        user_id: Optional user ID
        session_id: Optional session ID
        additional_context: Optional additional context dictionary
    """
    context = {
        'user_id': user_id,
        'session_id': session_id,
        'endpoint': request.path if request else None,
        'method': request.method if request else None,
    }
    
    if additional_context:
        context.update(additional_context)
    
    logger.error(
        f"Error occurred: {type(error).__name__}: {str(error)}",
        extra={'context': context},
        exc_info=True
    )
