from __future__ import annotations

from typing import Any, Dict, List, Optional

from services.evaluation import ClimateDataEvaluator


def _keyword_coverage(expected: List[str], response: str) -> Dict[str, Any]:
    matched = [kw for kw in expected if kw.lower() in response.lower()]
    missing = [kw for kw in expected if kw.lower() not in response.lower()]
    score = len(matched) / len(expected) if expected else 0.0
    return {
        "score": score,
        "matched": matched,
        "missing": missing,
    }


def _step_order_score(steps: List[str], response: str) -> float:
    """
    Score whether key operations appear in the intended order.

    We look for the first occurrence index of each step phrase in the response
    (case-insensitive) and count inversions among the steps that are present.
    """
    if not steps:
        return 0.0

    lower_resp = response.lower()
    positions: List[Optional[int]] = []
    for s in steps:
        idx = lower_resp.find(s.lower())
        positions.append(idx if idx != -1 else None)

    present_positions = [p for p in positions if p is not None]
    if len(present_positions) < 2:
        return 0.0

    inversions = sum(
        1
        for i in range(len(present_positions) - 1)
        if present_positions[i] > present_positions[i + 1]
    )
    max_inversions = len(present_positions) - 1
    if max_inversions <= 0:
        return 1.0
    return 1.0 - inversions / max_inversions


def _pitfall_flags(patterns: List[str], response: str) -> Dict[str, Any]:
    lower_resp = response.lower()
    hits = [p for p in patterns if p.lower() in lower_resp]
    return {
        "violations": hits,
        "has_pitfall": bool(hits),
        "score": 0.0 if hits else 1.0,
    }


def _norm_score(x: Any) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    if v > 1.0:
        v = v / 100.0
    if v < 0.0:
        v = 0.0
    if v > 1.0:
        v = 1.0
    return v


def evaluate_text_task(
    task: Dict[str, Any],
    response: str,
    retrieved_docs: Optional[List[str]],
    latency_ms: int,
    evaluator: ClimateDataEvaluator,
) -> Dict[str, Any]:
    """
    Evaluate a text-mode task (explanations / pseudo-code / reasoning).

    Signals:
    - keyword_coverage: presence of essential operations
    - step_order_score: whether key operations appear in correct order
    - pitfall_check: whether common pitfalls appear (wrong scenario/period/units)
    - semantic_score: LLM-as-judge quality / correctness proxy
    - quality_accuracy / quality_completeness: from evaluator.quality_scores
    - quality_average: mean of (accuracy, completeness) in [0, 1]
    - composite_score: blended overall score in [0, 1]
    """
    expected_keywords = task.get("expected_keywords", []) or []
    expected_step_order = task.get("expected_step_order", []) or []
    forbidden_patterns = task.get("forbidden_patterns", []) or []

    kw_metrics = _keyword_coverage(expected_keywords, response)
    step_score = _step_order_score(expected_step_order, response)
    pitfall = _pitfall_flags(forbidden_patterns, response)

    # LLM-as-judge evaluation for deeper quality signals
    eval_result = evaluator.evaluate_response(
        user_query=task.get("query", ""),
        response_content=response,
        retrieved_docs=retrieved_docs or [],
        processing_time_ms=latency_ms,
    )
    quality = eval_result.quality_scores or {}
    confidence_overall = eval_result.confidence_scores.get("overall", 0.0)

    accuracy = _norm_score(quality.get("accuracy", 0.0))
    completeness = _norm_score(quality.get("completeness", 0.0))
    semantic_components = [
        _norm_score(confidence_overall),
        accuracy,
        completeness,
        _norm_score(quality.get("coherence", 0.0)),
    ]
    semantic_score = (
        sum(semantic_components) / len(semantic_components)
        if semantic_components
        else 0.0
    )

    quality_average = 0.5 * (accuracy + completeness)

    composite_score = (
        0.4 * kw_metrics["score"]
        + 0.3 * step_score
        + 0.1 * pitfall["score"]
        + 0.2 * semantic_score
    )

    return {
        "evaluation_type": "text",
        "keyword_coverage": kw_metrics,
        "step_order_score": step_score,
        "pitfall_check": pitfall,
        "semantic_score": semantic_score,
        "quality_accuracy": accuracy,
        "quality_completeness": completeness,
        "quality_average": quality_average,
        "composite_score": composite_score,
        "evaluator_scores": {
            "confidence": eval_result.confidence_scores,
            "quality": quality,
        },
    }

