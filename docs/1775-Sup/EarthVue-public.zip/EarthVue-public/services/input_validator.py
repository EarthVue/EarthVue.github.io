"""
Input validation and sanitization utilities.
"""

import re
import html
from typing import Any, Optional, List, Dict, Callable
from flask import request
from services.error_handler import ValidationError


def sanitize_string(value: Any, max_length: Optional[int] = None, 
                   allow_html: bool = False) -> str:
    """
    Sanitize a string input.
    
    Args:
        value: Input value to sanitize
        max_length: Maximum allowed length
        allow_html: Whether to allow HTML tags (default: False, strips HTML)
    
    Returns:
        Sanitized string
    
    Raises:
        ValidationError: If validation fails
    """
    if value is None:
        raise ValidationError("Value cannot be None")
    
    # Convert to string
    str_value = str(value).strip()
    
    # Check length
    if max_length and len(str_value) > max_length:
        raise ValidationError(f"Value exceeds maximum length of {max_length} characters")
    
    # Remove HTML if not allowed
    if not allow_html:
        str_value = html.escape(str_value)
    
    return str_value


def validate_email(email: str) -> str:
    """
    Validate and sanitize an email address.
    
    Args:
        email: Email address to validate
    
    Returns:
        Sanitized email address
    
    Raises:
        ValidationError: If email is invalid
    """
    email = sanitize_string(email, max_length=255).lower()
    
    # Basic email regex
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    if not re.match(email_pattern, email):
        raise ValidationError("Invalid email format")
    
    return email


def validate_username(username: str) -> str:
    """
    Validate and sanitize a username.
    
    Args:
        username: Username to validate
    
    Returns:
        Sanitized username
    
    Raises:
        ValidationError: If username is invalid
    """
    username = sanitize_string(username, max_length=80).lower()
    
    # Username should be alphanumeric with underscores and hyphens
    if not re.match(r'^[a-z0-9_-]+$', username):
        raise ValidationError("Username can only contain letters, numbers, underscores, and hyphens")
    
    if len(username) < 3:
        raise ValidationError("Username must be at least 3 characters long")
    
    return username


def validate_uuid(uuid_str: str) -> str:
    """
    Validate a UUID string.
    
    Args:
        uuid_str: UUID string to validate
    
    Returns:
        Validated UUID string
    
    Raises:
        ValidationError: If UUID is invalid
    """
    uuid_str = sanitize_string(uuid_str, max_length=36)
    
    uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    
    if not re.match(uuid_pattern, uuid_str, re.IGNORECASE):
        raise ValidationError("Invalid UUID format")
    
    return uuid_str.lower()


def validate_session_id(session_id: str) -> str:
    """
    Validate a session ID (UUID format).
    
    Args:
        session_id: Session ID to validate
    
    Returns:
        Validated session ID
    """
    return validate_uuid(session_id)


def validate_query_text(query: str, max_length: int = 5000) -> str:
    """
    Validate and sanitize a user query.
    
    Args:
        query: Query text to validate
        max_length: Maximum query length
    
    Returns:
        Sanitized query text
    
    Raises:
        ValidationError: If query is invalid
    """
    query = sanitize_string(query, max_length=max_length, allow_html=False)
    
    if len(query) < 1:
        raise ValidationError("Query cannot be empty")
    
    return query


def validate_json_input(data: Dict[str, Any], required_fields: List[str], 
                       field_validators: Optional[Dict[str, Callable]] = None) -> Dict[str, Any]:
    """
    Validate JSON input data.
    
    Args:
        data: JSON data to validate
        required_fields: List of required field names
        field_validators: Optional dict mapping field names to validator functions
    
    Returns:
        Validated data dictionary
    
    Raises:
        ValidationError: If validation fails
    """
    if not isinstance(data, dict):
        raise ValidationError("Input must be a JSON object")
    
    # Check required fields
    missing_fields = [field for field in required_fields if field not in data]
    if missing_fields:
        raise ValidationError(f"Missing required fields: {', '.join(missing_fields)}")
    
    # Apply field validators
    if field_validators:
        for field, validator in field_validators.items():
            if field in data:
                try:
                    data[field] = validator(data[field])
                except ValidationError:
                    raise
                except Exception as e:
                    raise ValidationError(f"Invalid value for field '{field}': {str(e)}")
    
    return data


def sanitize_file_upload(filename: str, allowed_extensions: List[str] = None) -> str:
    """
    Sanitize a file upload filename.
    
    Args:
        filename: Original filename
        allowed_extensions: List of allowed file extensions (e.g., ['jpg', 'png', 'pdf'])
    
    Returns:
        Sanitized filename
    
    Raises:
        ValidationError: If filename is invalid
    """
    if not filename:
        raise ValidationError("Filename cannot be empty")
    
    # Remove path components
    filename = filename.split('/')[-1].split('\\')[-1]
    
    # Remove dangerous characters
    filename = re.sub(r'[^a-zA-Z0-9._-]', '', filename)
    
    # Check extension
    if allowed_extensions:
        ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
        if ext not in allowed_extensions:
            raise ValidationError(f"File type not allowed. Allowed types: {', '.join(allowed_extensions)}")
    
    return filename


def validate_pagination_params(page: Optional[int] = None, per_page: Optional[int] = None,
                              max_per_page: int = 100) -> tuple[int, int]:
    """
    Validate pagination parameters.
    
    Args:
        page: Page number (1-indexed)
        per_page: Items per page
        max_per_page: Maximum items per page
    
    Returns:
        Tuple of (page, per_page)
    
    Raises:
        ValidationError: If parameters are invalid
    """
    page = page or 1
    per_page = per_page or 20
    
    if page < 1:
        raise ValidationError("Page number must be at least 1")
    
    if per_page < 1:
        raise ValidationError("Items per page must be at least 1")
    
    if per_page > max_per_page:
        raise ValidationError(f"Items per page cannot exceed {max_per_page}")
    
    return page, per_page
