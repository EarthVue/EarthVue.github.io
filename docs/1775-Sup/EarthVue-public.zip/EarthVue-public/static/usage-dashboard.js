// Usage Dashboard JavaScript

let tokenChart, costChart, modelChart;
let currentDays = 7;

function escapeHtml(value) {
  return String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function heatCellColor(value, maxValue) {
  if (!maxValue || value <= 0) {
    return 'hsl(210, 40%, 97%)';
  }
  const ratio = Math.max(0, Math.min(1, value / maxValue));
  const lightness = 95 - Math.round(ratio * 45);
  return `hsl(201, 70%, ${lightness}%)`;
}

// Initialize charts
function initCharts() {
  const tokenCtx = document.getElementById('token-chart').getContext('2d');
  tokenChart = new Chart(tokenCtx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Tokens',
        data: [],
        borderColor: '#2563eb',
        backgroundColor: 'rgba(37,99,235,0.1)',
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      }
    }
  });
  
  const costCtx = document.getElementById('cost-chart').getContext('2d');
  costChart = new Chart(costCtx, {
    type: 'bar',
    data: {
      labels: [],
      datasets: [{
        label: 'Cost ($)',
        data: [],
        backgroundColor: '#10b981'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      }
    }
  });
  
  const modelCtx = document.getElementById('model-chart').getContext('2d');
  modelChart = new Chart(modelCtx, {
    type: 'doughnut',
    data: {
      labels: [],
      datasets: [{
        data: [],
        backgroundColor: [
          '#2563eb',
          '#10b981',
          '#f59e0b',
          '#8b5cf6',
          '#ef4444'
        ]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });
}

// Load usage data
async function loadUsageData(days = 7) {
  try {
    const [usageResponse, retrievalResponse] = await Promise.all([
      fetch(`/api/token_usage?days=${days}`),
      fetch(`/api/retrieval_coverage?days=${days}`)
    ]);

    const usageData = await usageResponse.json();
    const retrievalData = await retrievalResponse.json();

    updateStats(usageData);
    updateCharts(usageData);
    updateRetrievalCoverage(retrievalData);
  } catch (error) {
    console.error('Failed to load usage data:', error);
    document.querySelector('.usage-main').innerHTML = `
      <div class="loading">
        <p>Failed to load usage data. Please try again later.</p>
      </div>
    `;
  }
}

function updateRetrievalCoverage(data) {
  const summaryEl = document.getElementById('retrieval-summary');
  const gridHost = document.getElementById('retrieval-coverage-grid');

  if (!summaryEl || !gridHost) return;

  const traceCount = Number(data.trace_count || 0);
  const queryCount = Number(data.query_count || 0);
  const docCount = Number(data.retrieval_doc_count || 0);
  summaryEl.textContent = `${docCount.toLocaleString()} retrieval chunks from ${traceCount.toLocaleString()} traces (${queryCount.toLocaleString()} queries) in this window.`;

  const matrix = data.coverage_matrix || {};
  const intents = Array.isArray(matrix.intents) ? matrix.intents : [];
  const sources = Array.isArray(matrix.sources) ? matrix.sources : [];
  const values = Array.isArray(matrix.values) ? matrix.values : [];

  if (!intents.length || !sources.length || !values.length) {
    gridHost.innerHTML = '<div style="padding: 14px; color: var(--muted);">No retrieval coverage data yet. Ask a few RAG-backed questions first.</div>';
  } else {
    let maxValue = 0;
    values.forEach(row => {
      (Array.isArray(row) ? row : []).forEach(v => {
        maxValue = Math.max(maxValue, Number(v || 0));
      });
    });

    const headerCells = ['<th>Intent \\ Source</th>']
      .concat(sources.map(src => `<th title="${escapeHtml(src)}">${escapeHtml(src)}</th>`))
      .join('');

    const rows = intents.map((intent, rowIndex) => {
      const rowVals = Array.isArray(values[rowIndex]) ? values[rowIndex] : [];
      const cells = ['<td><strong>' + escapeHtml(intent) + '</strong></td>'];
      for (let i = 0; i < sources.length; i += 1) {
        const v = Number(rowVals[i] || 0);
        const color = heatCellColor(v, maxValue);
        cells.push(`<td style="background:${color};">${v}</td>`);
      }
      return '<tr>' + cells.join('') + '</tr>';
    }).join('');

    gridHost.innerHTML = `
      <table class="coverage-grid">
        <thead><tr>${headerCells}</tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

}

// Update statistics
function updateStats(data) {
  document.getElementById('total-requests').textContent = data.total_requests || 0;
  document.getElementById('total-tokens').textContent = (data.total_tokens || 0).toLocaleString();
  document.getElementById('total-cost').textContent = `$${(data.total_cost_usd || 0).toFixed(2)}`;
  document.getElementById('avg-tokens').textContent = data.average_tokens_per_request || 0;
}

// Update charts
function updateCharts(data) {
  // Token usage chart - show daily breakdown if available
  if (data.daily_breakdown && data.daily_breakdown.length > 0) {
    tokenChart.data.labels = data.daily_breakdown.map(d => d.date);
    tokenChart.data.datasets[0].data = data.daily_breakdown.map(d => d.tokens);
  } else {
    // Fallback: show total as single bar
    tokenChart.data.labels = ['Total'];
    tokenChart.data.datasets[0].data = [data.total_tokens || 0];
  }
  tokenChart.update();
  
  // Cost chart - breakdown by input/output
  const inputCost = data.total_cost_usd * 0.6 || 0;
  const outputCost = data.total_cost_usd * 0.4 || 0;
  costChart.data.labels = ['Input Cost', 'Output Cost'];
  costChart.data.datasets[0].data = [inputCost, outputCost];
  costChart.update();
  
  // Model breakdown
  if (data.model_breakdown && Object.keys(data.model_breakdown).length > 0) {
    const models = Object.keys(data.model_breakdown);
    const counts = Object.values(data.model_breakdown);
    modelChart.data.labels = models;
    modelChart.data.datasets[0].data = counts;
  } else {
    // Fallback
    modelChart.data.labels = ['No data'];
    modelChart.data.datasets[0].data = [1];
  }
  modelChart.update();
}

// Time filter buttons
document.querySelectorAll('.time-filter button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.time-filter button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentDays = parseInt(btn.dataset.days);
    loadUsageData(currentDays);
  });
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initCharts();
  loadUsageData(currentDays);
});
