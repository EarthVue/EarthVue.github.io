// Chat Interface Enhancements
// Token counter, health status, query suggestions

let tokenCount = 0;
let estimatedCost = 0;

// Add token counter to header
function addTokenCounter() {
  const headerActions = document.querySelector('.header-actions');
  if (!headerActions) return;
  
  // Check if already exists
  if (document.getElementById('token-counter')) return;
  
  const tokenBadge = document.createElement('div');
  tokenBadge.id = 'token-counter';
  tokenBadge.style.cssText = `
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 12px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    font-size: 0.85rem;
    color: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    cursor: help;
  `;
  tokenBadge.title = "Token Usage & Cost Estimator";
  tokenBadge.innerHTML = `
    <div style="position:relative; width: 40px; height: 20px; margin-top:4px;">
      <!-- Background arc -->
      <svg viewBox="0 0 100 50" style="width:100%; height:100%; overflow:visible;">
        <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="12" stroke-linecap="round" />
        <!-- Foreground arc -->
        <!-- length of arc is pi * r = 3.14159 * 40 = 125.66 -->
        <path id="token-gauge-arc" d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="#10b981" stroke-width="12" stroke-linecap="round" stroke-dasharray="125.66" stroke-dashoffset="125.66" style="transition: stroke-dashoffset 0.5s ease, stroke 0.5s ease;" />
      </svg>
    </div>
    <div style="display:flex; flex-direction:column; justify-content:center; line-height:1.2;">
      <span style="font-weight:600; font-size:0.8rem;" id="token-count-formatted">0 tokens</span>
      <span style="opacity: 0.7; font-size: 0.7rem;" id="token-cost">$0.00</span>
    </div>
  `;
  
  headerActions.insertBefore(tokenBadge, headerActions.firstChild);
}

// Health status is now on landing page only - removed from chat footer

// Check system health
async function checkHealth() {
  try {
    const response = await fetch('/api/health');
    const data = await response.json();
    
    const dot = document.querySelector('.health-dot');
    const text = document.querySelector('#health-indicator span:last-child');
    
    if (data.status === 'healthy') {
      dot.style.background = '#10b981';
      text.textContent = 'System OK';
    } else {
      dot.style.background = '#f59e0b';
      text.textContent = 'Degraded';
    }
  } catch (error) {
    const dot = document.querySelector('.health-dot');
    const text = document.querySelector('#health-indicator span:last-child');
    dot.style.background = '#ef4444';
    text.textContent = 'Error';
  }
}

// Add query suggestions to input
function addQuerySuggestions() {
  const chatInput = document.getElementById('chat-input');
  if (!chatInput) return;
  
  const suggestionsWrapper = document.createElement('div');
  suggestionsWrapper.id = 'query-suggestions-wrapper';
  suggestionsWrapper.style.cssText = `
    position: absolute;
    bottom: 100%;
    left: 0;
    right: 0;
    background: var(--sidebar-bg);
    border: 1px solid var(--stroke);
    border-radius: 8px;
    margin-bottom: 8px;
    max-height: 200px;
    overflow-y: auto;
    display: none;
    z-index: 1000;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  `;
  
  const footer = document.querySelector('.chat-footer');
  footer.style.position = 'relative';
  footer.appendChild(suggestionsWrapper);
  
  let suggestionsTimeout;
  
  chatInput.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    
    clearTimeout(suggestionsTimeout);
    
    if (query.length > 2) {
      suggestionsTimeout = setTimeout(() => {
        fetchQuerySuggestions(query);
      }, 300);
    } else {
      suggestionsWrapper.style.display = 'none';
    }
  });
  
  chatInput.addEventListener('focus', () => {
    if (chatInput.value.trim().length > 2) {
      fetchQuerySuggestions(chatInput.value.trim());
    }
  });
  
  // Close suggestions when clicking outside
  document.addEventListener('click', (e) => {
    if (!chatInput.contains(e.target) && !suggestionsWrapper.contains(e.target)) {
      suggestionsWrapper.style.display = 'none';
    }
  });
}

// Fetch query suggestions
async function fetchQuerySuggestions(partialQuery) {
  try {
    const response = await fetch('/api/query_builder/suggest', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ partial_query: partialQuery })
    });
    
    const data = await response.json();
    const suggestions = data.suggestions || [];
    
    if (suggestions.length > 0) {
      displaySuggestions(suggestions);
    } else {
      document.getElementById('query-suggestions-wrapper').style.display = 'none';
    }
  } catch (error) {
    console.error('Failed to fetch suggestions:', error);
  }
}

// Display suggestions
function displaySuggestions(suggestions) {
  const wrapper = document.getElementById('query-suggestions-wrapper');
  wrapper.innerHTML = '';
  
  suggestions.slice(0, 5).forEach(suggestion => {
    const item = document.createElement('div');
    item.style.cssText = `
      padding: 10px 16px;
      cursor: pointer;
      border-bottom: 1px solid var(--stroke);
      transition: background 0.2s;
    `;
    item.textContent = suggestion;
    item.addEventListener('mouseenter', () => {
      item.style.background = 'rgba(0,0,0,0.05)';
    });
    item.addEventListener('mouseleave', () => {
      item.style.background = 'transparent';
    });
    item.addEventListener('click', () => {
      document.getElementById('chat-input').value = suggestion;
      wrapper.style.display = 'none';
    });
    wrapper.appendChild(item);
  });
  
  wrapper.style.display = 'block';
}

// Load token usage for a specific session
async function loadSessionTokenUsage(sessionId) {
  if (!sessionId) {
    tokenCount = 0;
    estimatedCost = 0;
    updateTokenDisplay();
    return;
  }
  
  try {
    const response = await fetch(`/api/token_usage/${sessionId}`);
    if (!response.ok) {
      tokenCount = 0;
      estimatedCost = 0;
      updateTokenDisplay();
      return;
    }
    
    const data = await response.json();
    
    tokenCount = data.total_tokens || 0;
    estimatedCost = data.total_cost_usd || 0;
    
    // Update display
    updateTokenDisplay();
    
    // Save to localStorage for this session
    saveSessionTokenUsageToStorage(sessionId);
  } catch (error) {
    console.warn('Failed to load session token usage:', error);
    // Try loading from localStorage as fallback
    loadSessionTokenUsageFromStorage(sessionId);
  }
}

// Load token usage from localStorage for a specific session (fallback)
function loadSessionTokenUsageFromStorage(sessionId) {
  if (!sessionId) return;
  try {
    const saved = localStorage.getItem(`tokenUsage_${sessionId}`);
    if (saved) {
      const data = JSON.parse(saved);
      tokenCount = data.tokens || 0;
      estimatedCost = data.cost || 0;
      updateTokenDisplay();
    } else {
      tokenCount = 0;
      estimatedCost = 0;
      updateTokenDisplay();
    }
  } catch (e) {
    tokenCount = 0;
    estimatedCost = 0;
    updateTokenDisplay();
  }
}

// Save token usage to localStorage for a specific session
function saveSessionTokenUsageToStorage(sessionId) {
  if (!sessionId) return;
  try {
    localStorage.setItem(`tokenUsage_${sessionId}`, JSON.stringify({
      tokens: tokenCount,
      cost: estimatedCost,
      timestamp: Date.now()
    }));
  } catch (e) {
    // Ignore errors
  }
}

// Update token display (separate from update function)
function updateTokenDisplay() {
  const tokenFormattedEl = document.getElementById('token-count-formatted');
  const tokenCostEl = document.getElementById('token-cost');
  const gaugeArc = document.getElementById('token-gauge-arc');
  
  if (tokenFormattedEl) {
    if (tokenCount > 1000) {
      tokenFormattedEl.textContent = (tokenCount / 1000).toFixed(1) + 'k tokens';
    } else {
      tokenFormattedEl.textContent = tokenCount.toLocaleString() + ' tokens';
    }
  }
  
  if (tokenCostEl) {
    tokenCostEl.textContent = `$${estimatedCost.toFixed(4)}`;
  }
  
  if (gaugeArc) {
    // Assuming max context window or warning limit is 128,000 for visual scale
    const MAX_TOKENS = 128000;
    const ratio = Math.min(tokenCount / MAX_TOKENS, 1.0);
    
    // length of arc is 125.66
    const arcLength = 125.66;
    const offset = arcLength - (arcLength * ratio);
    gaugeArc.style.strokeDashoffset = offset;
    
    // Color gradient based on ratio
    if (ratio > 0.8) {
      gaugeArc.style.stroke = '#ef4444'; // Red
    } else if (ratio > 0.5) {
      gaugeArc.style.stroke = '#f59e0b'; // Yellow
    } else {
      gaugeArc.style.stroke = '#10b981'; // Green
    }
  }
  
  // Make sure counter is visible
  const counter = document.getElementById('token-counter');
  if (counter && tokenCount > 0) {
    counter.style.display = 'flex';
  }
}

// Update token counter (called after each message)
function updateTokenCounter(tokens, cost, sessionId) {
  const t = Number(tokens);
  if (Number.isFinite(t)) tokenCount += t;
  const c = Number(cost);
  if (Number.isFinite(c)) estimatedCost += c;
  
  // Update display
  updateTokenDisplay();
  
  // Save to localStorage for current session
  if (sessionId) {
    saveSessionTokenUsageToStorage(sessionId);
  }
}

// Initialize enhancements
document.addEventListener('DOMContentLoaded', () => {
  addTokenCounter();
  // addQuerySuggestions();
  // Token usage will be loaded when a chat is selected
});

// Export for use in main chat script
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { updateTokenCounter };
}

// Make functions globally available
window.updateTokenCounter = updateTokenCounter;
window.loadSessionTokenUsage = loadSessionTokenUsage;