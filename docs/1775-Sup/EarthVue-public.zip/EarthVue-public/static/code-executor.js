// Code Executor JavaScript

let editor;

const CODE_EXEC_LONG_RUN_MS = 120000;
const CODE_EXEC_LONG_RUN_REPEAT_MS = 300000;
const CODE_EXEC_TEN_MIN_MS = 600000;
const CODE_EXEC_SERVER_TIMEOUT_SEC = 3600;

function formatElapsedMs(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, '0')}`;
}

// Code templates
const CODE_TEMPLATES = {
  basic_plot: `import matplotlib.pyplot as plt
import numpy as np

# Generate sample data
x = np.linspace(0, 10, 100)
y = np.sin(x)

# Create plot
plt.figure(figsize=(10, 6))
plt.plot(x, y, label='sin(x)')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Sample Plot')
plt.legend()
plt.grid(True)
plt.show()`,

  temperature_trend: `import matplotlib.pyplot as plt
import numpy as np

# Simulate temperature data
years = np.arange(2020, 2051)
temperature = 15 + 0.02 * (years - 2020) + np.random.normal(0, 0.5, len(years))

plt.figure(figsize=(12, 6))
plt.plot(years, temperature, marker='o', linewidth=2)
plt.xlabel('Year')
plt.ylabel('Temperature (°C)')
plt.title('Temperature Trend (2020-2050)')
plt.grid(True, alpha=0.3)
plt.show()`,

  data_exploration: `import numpy as np
import matplotlib.pyplot as plt

# Generate sample climate data
data = np.random.normal(20, 5, 1000)

print(f"Mean: {np.mean(data):.2f}")
print(f"Std Dev: {np.std(data):.2f}")
print(f"Min: {np.min(data):.2f}")
print(f"Max: {np.max(data):.2f}")

plt.figure(figsize=(10, 6))
plt.hist(data, bins=30, edgecolor='black', alpha=0.7)
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.title('Data Distribution')
plt.show()`,

  statistical_analysis: `import numpy as np
import matplotlib.pyplot as plt

# Sample data
x = np.linspace(0, 10, 50)
y = 2 * x + 1 + np.random.normal(0, 1, 50)

# Calculate correlation
correlation = np.corrcoef(x, y)[0, 1]
print(f"Correlation: {correlation:.3f}")

# Plot
plt.figure(figsize=(10, 6))
plt.scatter(x, y, alpha=0.6)
plt.plot(x, 2*x + 1, 'r--', label='Trend')
plt.xlabel('X')
plt.ylabel('Y')
plt.title(f'Scatter Plot (r={correlation:.3f})')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()`
};

// Initialize CodeMirror editor
function initEditor() {
  editor = CodeMirror.fromTextArea(document.getElementById('code-input'), {
    mode: 'python',
    theme: 'monokai',
    lineNumbers: true,
    indentUnit: 4,
    indentWithTabs: false,
    lineWrapping: true,
    autofocus: true
  });
  
  // Set default code
  editor.setValue(`import matplotlib.pyplot as plt
import numpy as np

# Your code here
print("Hello, World!")`);
}

// Load template
document.getElementById('code-template').addEventListener('change', (e) => {
  const template = e.target.value;
  if (template && CODE_TEMPLATES[template]) {
    editor.setValue(CODE_TEMPLATES[template]);
  }
});

// Execute code
document.getElementById('execute-btn').addEventListener('click', async () => {
  const code = editor.getValue();
  if (!code.trim()) {
    alert('Please enter some code to execute');
    return;
  }

  const executeBtn = document.getElementById('execute-btn');
  const stopExecBtn = document.getElementById('stop-exec-btn');
  const longRunNotice = document.getElementById('long-run-notice');
  const longRunContinue = document.getElementById('long-run-continue');
  const longRunHalt = document.getElementById('long-run-halt');
  const executionTimeEl = document.getElementById('execution-time');

  const originalText = executeBtn.textContent;
  executeBtn.disabled = true;
  executeBtn.innerHTML = '<span class="loading"></span> Code is Running...';
  if (stopExecBtn) {
    stopExecBtn.hidden = false;
    stopExecBtn.disabled = false;
  }
  if (longRunNotice) longRunNotice.hidden = true;

  const outputContent = document.getElementById('output-content');
  outputContent.innerHTML = '<div style="text-align: center; padding: 20px;"><span class="loading"></span> Executing code...</div>';

  const startTime = Date.now();
  let nextLongRunPromptAt = CODE_EXEC_LONG_RUN_MS;
  let tenMinPromptShown = false;
  const abortController = new AbortController();

  const setStandardLongRunCopy = (elapsed) => {
    if (!longRunNotice) return;
    const copy = longRunNotice.querySelector('.long-run-copy');
    const fe = formatElapsedMs(elapsed);
    if (copy) {
      copy.innerHTML = 'Still running after <strong class="long-run-notice-time">' + fe + '</strong>. Keep waiting or stop execution.';
    }
  };
  const setTenMinLongRunCopy = (elapsed) => {
    if (!longRunNotice) return;
    const copy = longRunNotice.querySelector('.long-run-copy');
    const fe = formatElapsedMs(elapsed);
    if (copy) {
      copy.innerHTML = 'Over 10 minutes of runtime (<strong class="long-run-notice-time">' + fe + '</strong>). You can keep waiting or stop anytime.';
    }
  };

  const tick = () => {
    const elapsed = Date.now() - startTime;
    if (executionTimeEl) {
      executionTimeEl.textContent = `Running… ${formatElapsedMs(elapsed)}`;
    }
    if (!longRunNotice) return;

    if (!longRunNotice.hidden) {
      const te = longRunNotice.querySelector('.long-run-notice-time');
      if (te) te.textContent = formatElapsedMs(elapsed);
      if (!tenMinPromptShown && elapsed >= CODE_EXEC_TEN_MIN_MS) {
        tenMinPromptShown = true;
        setTenMinLongRunCopy(elapsed);
      }
      return;
    }
    if (!tenMinPromptShown && elapsed >= CODE_EXEC_TEN_MIN_MS) {
      tenMinPromptShown = true;
      longRunNotice.hidden = false;
      setTenMinLongRunCopy(elapsed);
      nextLongRunPromptAt = Infinity;
      return;
    }
    if (elapsed >= nextLongRunPromptAt) {
      longRunNotice.hidden = false;
      setStandardLongRunCopy(elapsed);
      nextLongRunPromptAt = Infinity;
    }
  };
  const timerId = setInterval(tick, 1000);
  tick();

  const onContinue = () => {
    if (longRunNotice) longRunNotice.hidden = true;
    const elapsed = Date.now() - startTime;
    nextLongRunPromptAt = elapsed + CODE_EXEC_LONG_RUN_REPEAT_MS;
  };
  const onHalt = () => abortController.abort();

  if (longRunContinue) longRunContinue.onclick = onContinue;
  if (longRunHalt) longRunHalt.onclick = onHalt;
  if (stopExecBtn) stopExecBtn.onclick = onHalt;

  try {
    const response = await fetch('/api/execute_code', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        code,
        timeout: CODE_EXEC_SERVER_TIMEOUT_SEC
      }),
      signal: abortController.signal
    });

    const result = await response.json();
    const wallSec = ((Date.now() - startTime) / 1000).toFixed(2);
    const serverSec = typeof result.execution_time === 'number'
      ? result.execution_time.toFixed(2)
      : wallSec;

    if (executionTimeEl) {
      executionTimeEl.textContent =
        typeof result.execution_time === 'number'
          ? `Completed in ${serverSec}s (wall ${wallSec}s)`
          : `Finished after ${wallSec}s`;
    }

    if (result.success) {
      displayOutput(result);
    } else {
      displayError(result.error || 'Execution failed');
    }
  } catch (error) {
    const elapsed = Date.now() - startTime;
    const elapsedStr = formatElapsedMs(elapsed);
    if (error.name === 'AbortError') {
      displayError(`Execution stopped after ${elapsedStr}.`);
      if (executionTimeEl) executionTimeEl.textContent = `Stopped after ${elapsedStr}`;
    } else {
      displayError(`Error: ${error.message}`);
      if (executionTimeEl) executionTimeEl.textContent = '';
    }
  } finally {
    clearInterval(timerId);
    if (longRunNotice) longRunNotice.hidden = true;
    if (longRunContinue) longRunContinue.onclick = null;
    if (longRunHalt) longRunHalt.onclick = null;
    if (stopExecBtn) {
      stopExecBtn.hidden = true;
      stopExecBtn.onclick = null;
    }
    executeBtn.disabled = false;
    executeBtn.textContent = originalText;
  }
});

// Display output
function displayOutput(result) {
  const outputContent = document.getElementById('output-content');
  let html = '';
  
  // Stdout
  if (result.output) {
    html += `
      <div class="output-section">
        <h4>Output</h4>
        <div class="output-stdout">${escapeHtml(result.output)}</div>
      </div>
    `;
  }
  
  // Stderr
  if (result.error) {
    html += `
      <div class="output-section">
        <h4>Error</h4>
        <div class="output-stderr">${escapeHtml(result.error)}</div>
      </div>
    `;
  }
  
  // Images
  if (result.images && result.images.length > 0) {
    html += `
      <div class="output-section">
        <h4>Visualizations (${result.images.length})</h4>
        <div class="output-images">
    `;
    result.images.forEach((imgData, idx) => {
      html += `
        <div class="output-image">
          <img src="data:image/png;base64,${imgData}" alt="Plot ${idx + 1}" />
        </div>
      `;
    });
    html += '</div></div>';
  }

  // Plotly interactive charts
  if (result.plotly_html && result.plotly_html.length > 0) {
    html += `
      <div class="output-section">
        <h4>Interactive Visualizations (${result.plotly_html.length})</h4>
        <div class="output-images">
    `;
    result.plotly_html.forEach((plotlyFragment, idx) => {
      const iframeDoc = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1" /><style>html,body{margin:0;padding:0;background:#fff;}body{font-family:sans-serif;} .js-plotly-plot{width:100% !important;}</style></head><body>${plotlyFragment}</body></html>`;
      html += `
        <div class="output-image">
          <iframe
            title="Interactive Plot ${idx + 1}"
            sandbox="allow-scripts allow-same-origin"
            loading="lazy"
            style="width:100%; height:520px; border:0; display:block;"
            srcdoc="${escapeHtmlAttr(iframeDoc)}"></iframe>
        </div>
      `;
    });
    html += '</div></div>';
  }
  
  // Variables
  if (result.variables && Object.keys(result.variables).length > 0) {
    html += `
      <div class="output-section">
        <h4>Variables</h4>
        <div class="output-variables">
    `;
    for (const [name, value] of Object.entries(result.variables)) {
      html += `
        <div class="variable-item">
          <span class="variable-name">${escapeHtml(name)}</span> = ${escapeHtml(String(value))}
        </div>
      `;
    }
    html += '</div></div>';
  }
  
  if (!html) {
    html = '<div style="text-align: center; padding: 40px; color: var(--muted);"><p>No output generated</p></div>';
  }
  
  outputContent.innerHTML = html;
}

// Display error
function displayError(error) {
  const outputContent = document.getElementById('output-content');
  outputContent.innerHTML = `
    <div class="output-section">
      <h4>Error</h4>
      <div class="output-stderr">${escapeHtml(error)}</div>
    </div>
  `;
}

// Clear editor
document.getElementById('clear-btn').addEventListener('click', () => {
  if (confirm('Clear all code?')) {
    editor.setValue('');
    document.getElementById('output-content').innerHTML = '<div style="text-align: center; padding: 40px; color: var(--muted);"><p>Output will appear here after running code</p></div>';
    document.getElementById('execution-time').textContent = '';
  }
});

// Save code (download as .py file)
document.getElementById('save-btn').addEventListener('click', () => {
  const code = editor.getValue();
  const blob = new Blob([code], { type: 'text/python' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'code.py';
  a.click();
  URL.revokeObjectURL(url);
});

// Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function escapeHtmlAttr(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  initEditor();
  const params = new URLSearchParams(window.location.search);
  const codeParam = params.get('code');
  if (codeParam) {
    editor.setValue(codeParam);
    editor.focus();
    editor.setCursor(editor.lineCount(), 0);
  }
});
