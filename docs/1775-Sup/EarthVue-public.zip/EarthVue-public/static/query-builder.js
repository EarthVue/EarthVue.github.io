// Query Builder JavaScript

let suggestionsTimeout;
let currentQuery = '';

// Initialize tabs
document.querySelectorAll('.builder-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const tabName = tab.dataset.tab;
    
    // Update tabs
    document.querySelectorAll('.builder-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    
    // Update content
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.getElementById(`${tabName}-tab`).classList.add('active');
  });
});

// Load templates
async function loadTemplates() {
  try {
    const response = await fetch('/api/query_builder/templates');
    const data = await response.json();
    const templates = data.templates || {};
    
    const grid = document.getElementById('template-grid');
    grid.innerHTML = '';
    
    for (const [key, template] of Object.entries(templates)) {
      const card = document.createElement('div');
      card.className = 'template-card';
      card.innerHTML = `
        <h3>${template.name}</h3>
        <p>${template.description}</p>
        <div class="example">${escapeHtml(template.example)}</div>
      `;
      card.addEventListener('click', () => {
        document.getElementById('query-input').value = template.example;
        document.querySelector('[data-tab="natural"]').click();
        validateQuery();
      });
      grid.appendChild(card);
    }
  } catch (error) {
    console.error('Failed to load templates:', error);
  }
}

// Query input with suggestions
const queryInput = document.getElementById('query-input');
const suggestionsDropdown = document.getElementById('suggestions-dropdown');

queryInput.addEventListener('input', (e) => {
  currentQuery = e.target.value;
  
  clearTimeout(suggestionsTimeout);
  
  if (currentQuery.length > 2) {
    suggestionsTimeout = setTimeout(() => {
      fetchSuggestions(currentQuery);
    }, 300);
  } else {
    suggestionsDropdown.classList.remove('show');
  }
});

queryInput.addEventListener('focus', () => {
  if (currentQuery.length > 2) {
    fetchSuggestions(currentQuery);
  }
});

// Close suggestions when clicking outside
document.addEventListener('click', (e) => {
  if (!queryInput.contains(e.target) && !suggestionsDropdown.contains(e.target)) {
    suggestionsDropdown.classList.remove('show');
  }
});

// Fetch query suggestions
async function fetchSuggestions(partialQuery) {
  try {
    const response = await fetch('/api/query_builder/suggest', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ partial_query: partialQuery })
    });
    
    const data = await response.json();
    const suggestions = data.suggestions || [];
    
    if (suggestions.length > 0) {
      displaySuggestions(suggestions);
    } else {
      suggestionsDropdown.classList.remove('show');
    }
  } catch (error) {
    console.error('Failed to fetch suggestions:', error);
  }
}

// Display suggestions
function displaySuggestions(suggestions) {
  suggestionsDropdown.innerHTML = '';
  
  suggestions.forEach(suggestion => {
    const item = document.createElement('div');
    item.className = 'suggestion-item';
    item.textContent = suggestion;
    item.addEventListener('click', () => {
      queryInput.value = suggestion;
      suggestionsDropdown.classList.remove('show');
      validateQuery();
    });
    suggestionsDropdown.appendChild(item);
  });
  
  suggestionsDropdown.classList.add('show');
}

// Validate query
document.getElementById('validate-btn').addEventListener('click', validateQuery);

async function validateQuery() {
  const query = queryInput.value.trim();
  if (!query) {
    alert('Please enter a query');
    return;
  }
  
  try {
    const response = await fetch('/api/query_builder/validate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ query: query })
    });
    
    const result = await response.json();
    displayValidation(result);
  } catch (error) {
    console.error('Validation failed:', error);
  }
}

// Display validation feedback
function displayValidation(result) {
  const feedback = document.getElementById('validation-feedback');
  feedback.className = `validation-feedback ${result.valid ? 'valid' : 'invalid'} show`;
  
  let html = '';
  if (result.valid) {
    html = '✓ Query is valid';
  } else {
    html = '✗ Query has issues:<ul>';
    if (result.issues) {
      result.issues.forEach(issue => {
        html += `<li>${issue}</li>`;
      });
    }
    html += '</ul>';
    if (result.suggestions && result.suggestions.length > 0) {
      html += '<strong>Suggestions:</strong><ul>';
      result.suggestions.forEach(suggestion => {
        html += `<li>${suggestion}</li>`;
      });
      html += '</ul>';
    }
  }
  
  feedback.innerHTML = html;
}

// Structure query
document.getElementById('structure-btn').addEventListener('click', async () => {
  const query = queryInput.value.trim();
  if (!query) {
    alert('Please enter a query');
    return;
  }
  
  const preview = document.getElementById('structured-preview');
  const generatingIndicator = document.getElementById('generating-indicator');
  const structureBtn = document.getElementById('structure-btn');
  
  // Show generating indicator
  preview.style.display = 'none';
  generatingIndicator.classList.add('show');
  structureBtn.disabled = true;
  structureBtn.textContent = 'Generating...';
  
  try {
    const response = await fetch('/api/query_builder/structure', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ query: query })
    });
    
    const result = await response.json();
    displayStructure(result);
  } catch (error) {
    console.error('Structuring failed:', error);
    generatingIndicator.classList.remove('show');
    alert('Failed to generate structured query. Please try again.');
  } finally {
    generatingIndicator.classList.remove('show');
    structureBtn.disabled = false;
    structureBtn.textContent = 'Show Structure';
  }
});

// Display structured query
function displayStructure(structured) {
  const preview = document.getElementById('structured-preview');
  const json = document.getElementById('structured-json');
  const generatingIndicator = document.getElementById('generating-indicator');
  
  generatingIndicator.classList.remove('show');
  json.textContent = JSON.stringify(structured, null, 2);
  preview.style.display = 'block';
}

// Generate query from structured form
document.getElementById('generate-query-btn').addEventListener('click', async () => {
  const params = {
    intent: document.getElementById('query-intent').value,
    variables: document.getElementById('variables').value.split(',').map(s => s.trim()).filter(Boolean),
    models: document.getElementById('models').value.split(',').map(s => s.trim()).filter(Boolean),
    scenarios: document.getElementById('scenarios').value.split(',').map(s => s.trim()).filter(Boolean),
    temporal_range: document.getElementById('temporal-range').value,
    spatial_region: document.getElementById('spatial-region').value
  };
  
  // Switch to natural language tab and populate
  document.querySelector('[data-tab="natural"]').click();
  queryInput.value = `Analyze ${params.variables.join(', ')} data for ${params.spatial_region || 'global'} region using ${params.models.join(', ')} models`;
  validateQuery();
});

// Send to chat - start new chat and submit query
document.getElementById('send-to-chat-btn').addEventListener('click', async () => {
  const query = queryInput.value.trim();
  if (!query) {
    alert('Please enter a query');
    return;
  }
  
  try {
    // Navigate to chat page
    window.location.href = `/chat?new_chat=true&query=${encodeURIComponent(query)}`;
  } catch (error) {
    console.error('Failed to send to chat:', error);
    alert('Failed to open chat. Please try again.');
  }
});

document.getElementById('send-structured-btn').addEventListener('click', async () => {
  const params = {
    intent: document.getElementById('query-intent').value,
    variables: document.getElementById('variables').value,
    models: document.getElementById('models').value,
    spatial_region: document.getElementById('spatial-region').value
  };
  
  const query = `Analyze ${params.variables || 'climate data'} for ${params.spatial_region || 'global region'} using ${params.models || 'available models'}`;
  window.location.href = `/chat?new_chat=true&query=${encodeURIComponent(query)}`;
});

// Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadTemplates();
});
