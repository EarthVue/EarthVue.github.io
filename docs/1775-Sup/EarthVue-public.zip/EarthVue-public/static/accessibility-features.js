/**
 * Accessibility Features for Climate AI Assistant
 * Provides Plain Language Summaries, Data Provenance, and Climate Glossary
 */

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PLAIN LANGUAGE SUMMARIES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async function generatePlainLanguageSummary(reasoningTraceId) {
  try {
    const response = await fetch("/api/plain_language_summary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reasoning_trace_id: reasoningTraceId })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error generating plain language summary:", error);
    return null;
  }
}

function displayPlainLanguageSummary(summary) {
  if (!summary) return;
  
  const container = document.getElementById("plain-language-summary");
  if (!container) return;
  
  const html = `
    <div class="summary-container">
      <h4>📖 Beginner-Friendly Summary</h4>
      <p class="beginner-summary">${escapeHtml(summary.beginner_summary)}</p>
      
      ${summary.key_concepts && summary.key_concepts.length > 0 ? `
        <h5>Key Concepts:</h5>
        <ul class="key-concepts-list">
          ${summary.key_concepts.map(concept => 
            `<li>${escapeHtml(concept)}</li>`
          ).join('')}
        </ul>
      ` : ''}
      
      ${summary.data_meaning ? `
        <h5>What This Data Means:</h5>
        <p class="data-meaning">${escapeHtml(summary.data_meaning)}</p>
      ` : ''}
    </div>
  `;
  
  container.innerHTML = html;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DATA PROVENANCE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async function getDataProvenance(reasoningTraceId) {
  try {
    const response = await fetch(`/api/data_provenance/${reasoningTraceId}`);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    const data = await response.json();
    return data.provenance || [];
  } catch (error) {
    console.error("Error fetching data provenance:", error);
    return [];
  }
}

function displayDataProvenance(provenanceList) {
  if (!provenanceList || provenanceList.length === 0) return;
  
  const container = document.getElementById("data-provenance");
  if (!container) return;
  
  const html = `
    <div class="provenance-container">
      <h4><span class="app-icon">📊</span> Data Provenance & Trust Information</h4>
      ${provenanceList.map(prov => `
        <div class="provenance-item">
          <h5>${escapeHtml(prov.dataset_name)}</h5>
          
          <div class="provenance-detail">
            <strong>Source:</strong> ${prov.source_origin ? escapeHtml(prov.source_origin) : 'Unknown'}
          </div>
          
          <div class="provenance-detail">
            <strong>Last Updated:</strong> ${prov.last_updated || 'Not specified'}
          </div>
          
          <div class="confidence-section">
            <strong>Confidence Level:</strong>
            <div class="confidence-bar-provenance">
              <div class="confidence-fill-provenance" style="width: ${(prov.confidence_level || 0) * 100}%"></div>
            </div>
            <span class="confidence-text">${Math.round((prov.confidence_level || 0) * 100)}%</span>
          </div>
          
          ${prov.usage_rights ? `
            <div class="provenance-detail">
              <strong>Usage Rights:</strong> ${escapeHtml(prov.usage_rights)}
            </div>
          ` : ''}
          
          ${prov.data_quality_metrics && Object.keys(prov.data_quality_metrics).length > 0 ? `
            <details class="quality-metrics">
              <summary>Data Quality Metrics</summary>
              <ul>
                ${Object.entries(prov.data_quality_metrics).map(([key, value]) => 
                  `<li>${key}: ${value}</li>`
                ).join('')}
              </ul>
            </details>
          ` : ''}
        </div>
      `).join('')}
    </div>
  `;
  
  container.innerHTML = html;
}

async function addProvenance(reasoningTraceId, datasetInfo) {
  try {
    const response = await fetch("/api/add_provenance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        reasoning_trace_id: reasoningTraceId,
        ...datasetInfo
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error adding provenance:", error);
    return null;
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CLIMATE GLOSSARY
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Glossary data - can be expanded
const CLIMATE_GLOSSARY = {
  "anomaly": {
    definition: "A difference from normal or average conditions, often used to show temperature or precipitation departures from a baseline period.",
    technical_definition: "A statistically significant deviation from a reference value or mean, typically expressed as the difference between a value and its climatological mean.",
    examples: ["Temperature anomaly of +2°C", "Precipitation anomaly during El Niño"],
    related_terms: ["baseline", "climatology", "deviation"]
  },
  "ensemble mean": {
    definition: "The average result from running multiple climate model simulations with slightly different starting conditions to show a typical outcome.",
    technical_definition: "The arithmetic mean of outputs from an ensemble of model realizations, used to represent the most probable climate scenario.",
    examples: ["CMIP6 ensemble mean temperature", "Multi-model ensemble projection"],
    related_terms: ["model ensemble", "spread", "uncertainty"]
  },
  "rcp scenarios": {
    definition: "Representative Concentration Pathways - different possible future greenhouse gas emission levels used to project climate change.",
    technical_definition: "Standardized emission scenarios (RCP 2.6, 4.5, 6.0, 8.5) representing different levels of radiative forcing in W/m².",
    examples: ["RCP 4.5 (intermediate scenario)", "RCP 8.5 (high emissions scenario)"],
    related_terms: ["emissions", "scenarios", "radiative forcing", "SSP"]
  },
  "ssp": {
    definition: "Shared Socioeconomic Pathways - modern scenarios that combine climate models with socioeconomic factors like population and economic growth.",
    technical_definition: "Five narratives (SSP1-5) describing different plausible development pathways paired with emissions to 2100.",
    examples: ["SSP1-1.9 (sustainability)", "SSP5-8.5 (high growth)"],
    related_terms: ["RCP", "scenarios", "socioeconomic"]
  },
  "climatology": {
    definition: "The typical or average climate conditions over a long period (usually 30+ years), used as a reference.",
    technical_definition: "The study of climate statistics and the calculation of mean values of meteorological variables over specific time periods.",
    examples: ["30-year climatology", "Climate normal period 1991-2020"],
    related_terms: ["baseline", "normal", "climate"]
  },
  "trend": {
    definition: "A gradual, long-term change in climate data over decades or centuries (e.g., warming or precipitation change).",
    technical_definition: "A monotonic or systematic change in a time series, often estimated using linear regression or Mann-Kendall statistics.",
    examples: ["Arctic warming trend", "Sea level rise trend"],
    related_terms: ["change", "signal", "variability"]
  },
  "model bias": {
    definition: "A systematic error where a climate model consistently predicts values that are too high or too low compared to observations.",
    technical_definition: "A persistent deviation of model output from observational data, arising from model approximations and parameterizations.",
    examples: ["Cold bias in winter temperatures", "Wet bias in precipitation"],
    related_terms: ["error", "skill", "validation"]
  },
  "uncertainty": {
    definition: "The range of possible outcomes due to natural climate variability, model limitations, and incomplete knowledge.",
    technical_definition: "Quantification of confidence intervals or ranges in climate projections, combining parametric and structural uncertainties.",
    examples: ["Uncertainty in 2°C warming date", "Range of temperature projections"],
    related_terms: ["confidence interval", "range", "spread"]
  },
  "temporal resolution": {
    definition: "How frequently climate data is sampled (daily, monthly, yearly) - finer resolution means more details.",
    technical_definition: "The time interval between successive measurements or model outputs in a climate dataset.",
    examples: ["Daily temperature data", "Monthly precipitation records"],
    related_terms: ["spatial resolution", "data frequency"]
  },
  "spatial resolution": {
    definition: "The geographic detail of climate data - higher resolution means smaller grid boxes and more detail.",
    technical_definition: "The geographic distance or grid cell size representing climate variables, often expressed in degrees or kilometers.",
    examples: ["0.25° resolution (~25 km)", "1° resolution (~110 km)"],
    related_terms: ["temporal resolution", "grid", "downscaling"]
  }
};

async function loadGlossary() {
  try {
    const response = await fetch("/api/glossary");
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    const data = await response.json();
    return data.glossary || [];
  } catch (error) {
    console.error("Error loading glossary from server:", error);
    // Fall back to local glossary
    return Object.entries(CLIMATE_GLOSSARY).map(([term, info]) => ({
      term,
      ...info
    }));
  }
}

function initializeGlossaryHovers(glossaryData) {
  // Find all elements with data-glossary-term attribute
  const glossaryTerms = document.querySelectorAll("[data-glossary-term]");
  
  glossaryTerms.forEach(element => {
    const term = element.getAttribute("data-glossary-term").toLowerCase();
    const termData = glossaryData.find(t => t.term.toLowerCase() === term);
    
    if (termData) {
      element.style.cursor = "help";
      element.title = termData.definition;
      element.addEventListener("mouseenter", (e) => {
        showGlossaryTooltip(e, termData);
      });
    }
  });
}

function showGlossaryTooltip(event, termData) {
  // Remove existing tooltip
  const existing = document.querySelector(".glossary-tooltip");
  if (existing) existing.remove();
  
  const tooltip = document.createElement("div");
  tooltip.className = "glossary-tooltip";
  tooltip.innerHTML = `
    <div class="glossary-tooltip-content">
      <h4>${escapeHtml(termData.term.toUpperCase())}</h4>
      <p class="glossary-definition">${escapeHtml(termData.definition)}</p>
      
      ${termData.examples && termData.examples.length > 0 ? `
        <p><strong>Examples:</strong></p>
        <ul>
          ${termData.examples.slice(0, 2).map(ex => 
            `<li>${escapeHtml(ex)}</li>`
          ).join('')}
        </ul>
      ` : ''}
      
      ${termData.related_terms && termData.related_terms.length > 0 ? `
        <p><strong>Related:</strong> ${termData.related_terms.join(', ')}</p>
      ` : ''}
    </div>
  `;
  
  document.body.appendChild(tooltip);
  
  // Position tooltip near mouse
  const rect = event.target.getBoundingClientRect();
  tooltip.style.left = (rect.left + window.scrollX) + "px";
  tooltip.style.top = (rect.bottom + window.scrollY + 5) + "px";
  
  // Remove tooltip on mouse leave
  event.target.addEventListener("mouseleave", () => {
    tooltip.remove();
  });
}

async function initializeGlossaryFeature() {
  const glossaryData = await loadGlossary();
  initializeGlossaryHovers(glossaryData);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UTILITY FUNCTIONS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function escapeHtml(text) {
  if (!text) return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// Auto-initialize glossary when DOM is ready
document.addEventListener("DOMContentLoaded", initializeGlossaryFeature);

// Export for use in other scripts
window.AccessibilityFeatures = {
  generatePlainLanguageSummary,
  displayPlainLanguageSummary,
  getDataProvenance,
  displayDataProvenance,
  addProvenance,
  loadGlossary,
  initializeGlossaryHovers,
  showGlossaryTooltip
};
