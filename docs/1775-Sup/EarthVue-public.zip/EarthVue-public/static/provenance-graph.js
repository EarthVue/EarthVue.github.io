/**
 * Unified provenance DAG — rich cards, hover inspector, edge highlighting.
 */
(function (global) {
  'use strict';

  const COLORS = {
    query: { fill: 'rgba(99, 102, 241, 0.2)', stroke: '#6366f1', text: '#312e81' },
    evidence: { fill: 'rgba(14, 165, 233, 0.2)', stroke: '#0284c7', text: '#0c4a6e' },
    mcp_tools: { fill: 'rgba(59, 130, 246, 0.2)', stroke: '#2563eb', text: '#1e3a8a' },
    rag_context: { fill: 'rgba(14, 165, 233, 0.2)', stroke: '#0891b2', text: '#164e63' },
    context_extra: { fill: 'rgba(148, 163, 184, 0.3)', stroke: '#64748b', text: '#334155' },
    evidence_gap: { fill: 'rgba(148, 163, 184, 0.3)', stroke: '#64748b', text: '#334155' },
    dataset_logic: { fill: 'rgba(20, 184, 166, 0.2)', stroke: '#0d9488', text: '#134e4a' },
    model: { fill: 'rgba(167, 139, 250, 0.2)', stroke: '#7c3aed', text: '#4c1d95' },
    reasoning_step: { fill: 'rgba(245, 158, 11, 0.2)', stroke: '#d97706', text: '#78350f' },
    evaluation: { fill: 'rgba(34, 197, 94, 0.2)', stroke: '#16a34a', text: '#14532d' },
    uncertainty: { fill: 'rgba(234, 179, 8, 0.2)', stroke: '#ca8a04', text: '#713f12' },
    bias: { fill: 'rgba(249, 115, 22, 0.2)', stroke: '#ea580c', text: '#7c2d12' },
    assistant_response: {
      fill: 'rgba(99, 102, 241, 0.15)',
      stroke: '#6366f1',
      text: '#3730a3',
    },
    data_trust: { fill: 'rgba(236, 72, 153, 0.2)', stroke: '#db2777', text: '#831843' },
    latency: { fill: 'rgba(148, 163, 184, 0.25)', stroke: '#64748b', text: '#334155' },
  };

  /** Vertical gap between stacked nodes in the same rank column */
  const V_GAP = 26;
  const PAD = 40;
  const LAYER_GAP = 36;
  /** Extra px below measured bbox so descenders / borders never clip */
  const MEASURE_Y_PAD = 20;
  /** Wheel / toolbar zoom multiplier per step (matches wheel behavior) */
  const PG_ZOOM_STEP = 1.1;

  function defaultSize(kind) {
    const m = {
      query: [224, 64],
      evidence: [236, 96],
      mcp_tools: [248, 120],
      rag_context: [252, 120],
      context_extra: [236, 104],
      evidence_gap: [220, 64],
      dataset_logic: [228, 88],
      model: [212, 80],
      reasoning_step: [220, 100],
      evaluation: [236, 104],
      uncertainty: [232, 118],
      bias: [232, 118],
      assistant_response: [252, 132],
      data_trust: [210, 72],
      latency: [188, 64],
    };
    return m[kind] || [180, 88];
  }

  function escapeHtml(s) {
    if (s === undefined || s === null) return '';
    const d = document.createElement('div');
    d.textContent = String(s);
    return d.innerHTML;
  }

  function formatSubcategoryInspector(meta) {
    if (!meta.subcategories || !meta.subcategories.length) return '';
    let panels = '';
    for (let i = 0; i < meta.subcategories.length; i++) {
      const sc = meta.subcategories[i];
      const display = i === 0 ? 'block' : 'none';
      panels +=
        '<div class="pg-subcat-panel" data-idx="' +
        i +
        '" style="display:' +
        display +
        '">';
      panels +=
        '<h5 class="pg-meta-sec-title">' +
        escapeHtml(sc.title || sc.label || 'Item') +
        '</h5>';
      if (sc.detail) {
        panels +=
          '<p class="pg-subcat-detail">' + escapeHtml(sc.detail) + '</p>';
      }
      panels += formatMetaSections({ sections: sc.sections || [] });
      panels += '</div>';
    }
    let opts = '';
    for (let j = 0; j < meta.subcategories.length; j++) {
      opts +=
        '<option value="' +
        j +
        '">' +
        escapeHtml(meta.subcategories[j].label || 'Item ' + (j + 1)) +
        '</option>';
    }
    return (
      '<div class="pg-inspector-subcat">' +
      '<label class="pg-subcat-label">Subcategory</label>' +
      '<select class="pg-inspector-subcat-select" aria-label="Choose subcategory">' +
      opts +
      '</select>' +
      '<div class="pg-subcat-panels">' +
      panels +
      '</div></div>'
    );
  }

  function bindInspectorSubcatSelect(container) {
    const sel = container.querySelector('.pg-inspector-subcat-select');
    if (!sel) return;
    sel.onchange = function () {
      const v = String(sel.value);
      container.querySelectorAll('.pg-subcat-panel').forEach(function (el) {
        el.style.display = el.getAttribute('data-idx') === v ? 'block' : 'none';
      });
    };
  }

  function formatMetaSections(meta) {
    if (!meta || !meta.sections || !meta.sections.length) return '';
    let html = '';
    for (let i = 0; i < meta.sections.length; i++) {
      const sec = meta.sections[i];
      html += '<section class="pg-meta-sec">';
      html += '<h5 class="pg-meta-sec-title">' + escapeHtml(sec.title || '') + '</h5>';
      if (sec.body) {
        html +=
          '<pre class="pg-meta-pre">' + escapeHtml(sec.body) + '</pre>';
      }
      if (sec.kv && sec.kv.length) {
        html += '<table class="pg-meta-kv">';
        for (let j = 0; j < sec.kv.length; j++) {
          const row = sec.kv[j];
          if (!row || row.length < 2) continue;
          html +=
            '<tr><th>' +
            escapeHtml(row[0]) +
            '</th><td>' +
            escapeHtml(row[1]) +
            '</td></tr>';
        }
        html += '</table>';
      }
      html += '</section>';
    }
    return html;
  }

  function inspectorHtml(n) {
    const c = COLORS[n.kind] || COLORS.evidence;
    const head =
      '<span class="pg-detail-kind" style="border-color:' +
      c.stroke +
      ';color:' +
      c.text +
      '">' +
      escapeHtml(String(n.kind || '').replace(/_/g, ' ')) +
      '</span>';
    if (n.meta && n.meta.subcategories && n.meta.subcategories.length) {
      return (
        '<div class="provenance-graph-detail-inner pg-detail-rich">' +
        head +
        '<h4 class="pg-detail-title">' +
        escapeHtml(n.meta.title || n.label || '') +
        '</h4>' +
        (n.meta.subtitle
          ? '<p class="pg-detail-sub">' + escapeHtml(n.meta.subtitle) + '</p>'
          : '') +
        formatSubcategoryInspector(n.meta) +
        '</div>'
      );
    }
    if (n.meta && n.meta.sections && n.meta.sections.length) {
      return (
        '<div class="provenance-graph-detail-inner pg-detail-rich">' +
        head +
        '<h4 class="pg-detail-title">' +
        escapeHtml(n.meta.title || n.label || '') +
        '</h4>' +
        formatMetaSections(n.meta) +
        '</div>'
      );
    }
    return (
      '<div class="provenance-graph-detail-inner">' +
      head +
      '<h4 class="pg-detail-title">' +
      escapeHtml(n.label || '') +
      '</h4>' +
      (n.detail ? '<p class="pg-detail-body">' + escapeHtml(n.detail) + '</p>' : '') +
      '</div>'
    );
  }

  function completenessBannerHtml(c) {
    if (!c || typeof c.score !== 'number') return '';
    const pct = Math.round(c.score * 100);
    let missing = [];
    if (Array.isArray(c.checks)) {
      missing = c.checks.filter(function (x) {
        return !x.present;
      });
    }
    const missLabel = missing.length
      ? 'Missing: ' + missing.map(function (m) { return m.key; }).join(', ')
      : 'All core provenance checks are present.';
    return (
      '<div class="provenance-graph-detail-inner pg-detail-rich" style="margin-bottom:10px;">' +
      '<span class="pg-detail-kind" style="border-color:#0d9488;color:#134e4a">trace completeness</span>' +
      '<h4 class="pg-detail-title">Completeness ' + pct + '%</h4>' +
      '<p class="pg-detail-sub">' + escapeHtml(missLabel) + '</p>' +
      '</div>'
    );
  }

  function computeLayout(nodes, edges) {
    const byRank = new Map();
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      const r = n.rank ?? 0;
      if (!byRank.has(r)) byRank.set(r, []);
      byRank.get(r).push(n);
    }
    const ranks = [...byRank.keys()].sort(function (a, b) {
      return a - b;
    });

    const pos = {};
    let xCursor = PAD;
    let canvasBottom = PAD;

    for (let ri = 0; ri < ranks.length; ri++) {
      const r = ranks[ri];
      const col = byRank.get(r);
      let maxW = 0;
      let y = PAD;
      for (let i = 0; i < col.length; i++) {
        const n = col[i];
        const ds = defaultSize(n.kind);
        const w = n.layout_w != null ? n.layout_w : ds[0];
        const h = n.layout_h != null ? n.layout_h : ds[1];
        maxW = Math.max(maxW, w);
        pos[n.id] = { x: xCursor, y: y, w: w, h: h };
        canvasBottom = Math.max(canvasBottom, y + h);
        y += h + V_GAP;
      }
      xCursor += maxW + LAYER_GAP;
    }

    const width = Math.max(760, xCursor + PAD);
    const height = Math.max(280, canvasBottom + PAD);
    return { pos, width, height };
  }

  function edgePath(x1, y1, x2, y2) {
    const mid = (x1 + x2) / 2;
    return 'M ' + x1 + ' ' + y1 + ' C ' + mid + ' ' + y1 + ', ' + mid + ' ' + y2 + ', ' + x2 + ' ' + y2;
  }

  let hostEl = null;
  let selectionEl = null;
  let legendEl = null;
  let svgEl = null;
  let rootG = null;
  let edgeG = null;
  let tooltipEl = null;
  /** Pan/zoom via SVG viewBox (user space), not a mismatched transform matrix */
  let vb = {
    x: 0,
    y: 0,
    w: 800,
    h: 600,
    layoutW: 800,
    layoutH: 600,
  };
  let panState = {
    dragging: false,
    startX: 0,
    startY: 0,
    startVbX: 0,
    startVbY: 0,
  };
  let lastLayoutInfo = null;
  let disposePanZoom = null;

  function adjustEdgeAnchorsToNodes(pos, edges) {
    if (!rootG || !edgeG) return;
    for (let i = 0; i < edges.length; i++) {
      const e = edges[i];
      const a = pos[e.source];
      const b = pos[e.target];
      if (!a || !b) continue;
      const ga = rootG.querySelector('[data-pg-node="' + e.source + '"]');
      const gb = rootG.querySelector('[data-pg-node="' + e.target + '"]');
      let ha = a.h;
      let hb = b.h;
      if (ga) {
        try {
          const ba = ga.getBBox();
          if (ba && ba.height > 4) ha = ba.height;
        } catch (err) {}
      }
      if (gb) {
        try {
          const bb = gb.getBBox();
          if (bb && bb.height > 4) hb = bb.height;
        } catch (err) {}
      }
      const path = edgeG.querySelector(
        '.provenance-edge[data-source="' +
          e.source +
          '"][data-target="' +
          e.target +
          '"]'
      );
      if (!path) continue;
      const x1 = a.x + a.w;
      const y1 = a.y + ha / 2;
      const x2 = b.x;
      const y2 = b.y + hb / 2;
      path.setAttribute('d', edgePath(x1, y1, x2, y2));
    }
  }

  /**
   * Re-stack nodes within each rank column using real rendered heights.
   * Fixes overlap when card HTML is taller than layout_h / defaultSize.
   */
  function reflowLayoutByMeasurement(nodes, pos) {
    if (!rootG) return null;
    const byRank = new Map();
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      const r = n.rank ?? 0;
      if (!byRank.has(r)) byRank.set(r, []);
      byRank.get(r).push(n);
    }
    const rankKeys = [...byRank.keys()].sort(function (a, b) {
      return a - b;
    });
    let maxRight = PAD;
    let maxBottom = PAD;

    for (let ri = 0; ri < rankKeys.length; ri++) {
      const col = byRank.get(rankKeys[ri]).slice();
      col.sort(function (a, b) {
        const pa = pos[a.id];
        const pb = pos[b.id];
        if (!pa || !pb) return 0;
        if (pa.y !== pb.y) return pa.y - pb.y;
        return String(a.id).localeCompare(String(b.id));
      });

      let yRun = PAD;
      for (let ci = 0; ci < col.length; ci++) {
        const n = col[ci];
        const p = pos[n.id];
        if (!p) continue;
        const g = rootG.querySelector('[data-pg-node="' + n.id + '"]');
        if (!g) {
          p.y = yRun;
          yRun += p.h + V_GAP;
          maxRight = Math.max(maxRight, p.x + p.w);
          maxBottom = Math.max(maxBottom, p.y + p.h);
          continue;
        }
        let cellH = p.h;
        const wrap = g.querySelector('.pg-node-card');
        const card = g.querySelector('.pg-node-card-inner');
        const fromWrap = wrap && wrap.scrollHeight ? wrap.scrollHeight : 0;
        const fromInner = card && card.scrollHeight ? card.scrollHeight : 0;
        const domH = Math.max(fromWrap, fromInner);
        if (domH) {
          cellH = Math.max(cellH, Math.ceil(domH + MEASURE_Y_PAD));
        }
        try {
          const bb = g.getBBox();
          if (bb && bb.height > 4) {
            cellH = Math.max(cellH, Math.ceil(bb.height + MEASURE_Y_PAD));
          }
        } catch (err) {}
        cellH = Math.max(cellH, p.h, 48);
        p.y = yRun;
        p.h = cellH;
        g.setAttribute('transform', 'translate(' + p.x + ',' + p.y + ')');
        const fo = g.querySelector('foreignObject');
        if (fo) {
          fo.setAttribute('height', String(cellH));
        }
        yRun += cellH + V_GAP;
        maxRight = Math.max(maxRight, p.x + p.w);
        maxBottom = Math.max(maxBottom, p.y + cellH);
      }
    }

    const width = Math.max(760, maxRight + PAD);
    const height = Math.max(320, maxBottom + PAD);
    return { width: width, height: height };
  }

  function applyViewBox() {
    if (!svgEl) return;
    svgEl.setAttribute('viewBox', vb.x + ' ' + vb.y + ' ' + vb.w + ' ' + vb.h);
  }

  function clientToSvgPoint(svg, clientX, clientY) {
    const rect = svg.getBoundingClientRect();
    const x = vb.x + ((clientX - rect.left) / Math.max(rect.width, 1)) * vb.w;
    const y = vb.y + ((clientY - rect.top) / Math.max(rect.height, 1)) * vb.h;
    return { x: x, y: y };
  }

  /**
   * Zoom viewBox toward (clientX, clientY) in viewport pixels, or graph center if omitted.
   */
  function zoomViewBox(svg, factor, clientX, clientY) {
    if (!svg || vb.w <= 0 || vb.h <= 0) return;
    const minW = Math.max(80, vb.layoutW * 0.05);
    const maxW = vb.layoutW * 6;
    const nw = Math.min(maxW, Math.max(minW, vb.w * factor));
    const nh = (nw * vb.h) / vb.w;
    let pt;
    if (typeof clientX === 'number' && typeof clientY === 'number') {
      pt = clientToSvgPoint(svg, clientX, clientY);
    } else {
      const rect = svg.getBoundingClientRect();
      pt = clientToSvgPoint(
        svg,
        rect.left + rect.width / 2,
        rect.top + rect.height / 2
      );
    }
    const rx = (pt.x - vb.x) / vb.w;
    const ry = (pt.y - vb.y) / vb.h;
    vb.x = pt.x - rx * nw;
    vb.y = pt.y - ry * nh;
    vb.w = nw;
    vb.h = nh;
    applyViewBox();
  }

  function isInteractiveGraphTarget(target) {
    if (!target || !target.closest) return false;
    return !!target.closest('.pg-node-card');
  }

  function ensureTooltip() {
    if (tooltipEl) return tooltipEl;
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'pg-floating-tooltip';
    tooltipEl.setAttribute('role', 'tooltip');
    tooltipEl.style.display = 'none';
    document.body.appendChild(tooltipEl);
    return tooltipEl;
  }

  function showTooltip(html, clientX, clientY) {
    const el = ensureTooltip();
    el.innerHTML = html;
    el.style.display = 'block';
    const pad = 12;
    const tw = Math.min(440, window.innerWidth - 24);
    el.style.maxWidth = tw + 'px';
    let left = clientX + pad;
    let top = clientY + pad;
    el.style.left = left + 'px';
    el.style.top = top + 'px';
    requestAnimationFrame(function () {
      const r = el.getBoundingClientRect();
      if (r.right > window.innerWidth - 8) {
        left = Math.max(8, clientX - r.width - pad);
        el.style.left = left + 'px';
      }
      if (r.bottom > window.innerHeight - 8) {
        top = Math.max(8, clientY - r.height - pad);
        el.style.top = top + 'px';
      }
    });
  }

  function hideTooltip() {
    if (tooltipEl) tooltipEl.style.display = 'none';
  }

  function highlightEdges(nodeId) {
    if (!edgeG) return;
    const paths = edgeG.querySelectorAll('.provenance-edge');
    for (let i = 0; i < paths.length; i++) {
      const p = paths[i];
      const s = p.getAttribute('data-source');
      const t = p.getAttribute('data-target');
      if (s === nodeId || t === nodeId) {
        p.classList.add('provenance-edge--active');
        p.setAttribute('marker-end', 'url(#pg-arrow-hi)');
      } else {
        p.classList.remove('provenance-edge--active');
        p.setAttribute('marker-end', 'url(#pg-arrow)');
      }
    }
  }

  function clearEdgeHighlight() {
    if (!edgeG) return;
    edgeG.querySelectorAll('.provenance-edge').forEach(function (p) {
      p.classList.remove('provenance-edge--active');
      p.setAttribute('marker-end', 'url(#pg-arrow)');
    });
  }

  function fitViewBox(layoutInfo) {
    if (!svgEl) return;
    const lw = layoutInfo ? layoutInfo.width : vb.layoutW;
    const lh = layoutInfo ? layoutInfo.height : vb.layoutH;
    vb.layoutW = lw;
    vb.layoutH = lh;
    vb.x = 0;
    vb.y = 0;
    vb.w = lw;
    vb.h = lh;
    applyViewBox();
  }

  function bindPanZoom(svg) {
    function onWheel(e) {
      e.preventDefault();
      const factor = e.deltaY > 0 ? PG_ZOOM_STEP : 1 / PG_ZOOM_STEP;
      zoomViewBox(svg, factor, e.clientX, e.clientY);
    }

    function onMouseDown(e) {
      if (e.button !== 0) return;
      if (isInteractiveGraphTarget(e.target)) return;
      panState.dragging = true;
      hideTooltip();
      panState.startX = e.clientX;
      panState.startY = e.clientY;
      panState.startVbX = vb.x;
      panState.startVbY = vb.y;
      svg.style.cursor = 'grabbing';
    }

    function onMouseMove(e) {
      if (!panState.dragging || !svgEl) return;
      const rect = svgEl.getBoundingClientRect();
      const dxPx = e.clientX - panState.startX;
      const dyPx = e.clientY - panState.startY;
      const dxSvg = (dxPx / Math.max(rect.width, 1)) * vb.w;
      const dySvg = (dyPx / Math.max(rect.height, 1)) * vb.h;
      vb.x = panState.startVbX - dxSvg;
      vb.y = panState.startVbY - dySvg;
      applyViewBox();
    }

    function onMouseUp() {
      panState.dragging = false;
      if (svg) svg.style.cursor = 'grab';
    }

    svg.addEventListener('wheel', onWheel, { passive: false });
    svg.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return function dispose() {
      svg.removeEventListener('wheel', onWheel);
      svg.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }

  /**
   * Tear down the SVG. If idleHost is true, show the “no session” hint; if false,
   * leave the host empty so the graph can use the full area (no placeholder flash).
   */
  function teardownGraph(idleHost) {
    if (disposePanZoom) {
      disposePanZoom();
      disposePanZoom = null;
    }
    hideTooltip();
    if (hostEl) {
      hostEl.innerHTML = idleHost
        ? '<p class="empty-state pg-host-idle" style="padding:32px 16px;text-align:center;">Pick a chat session above to load the provenance graph.</p>'
        : '';
      hostEl.classList.remove('provenance-graph-host--ready');
    }
    if (selectionEl) {
      selectionEl.innerHTML =
        '<p class="provenance-graph-detail-placeholder">Hover or click a node to inspect metadata, tool output, encodings, and reasoning.</p>';
    }
    if (legendEl) legendEl.innerHTML = '';
    svgEl = null;
    rootG = null;
    edgeG = null;
  }

  function tooltipHtml(n) {
    const c = COLORS[n.kind] || COLORS.evidence;
    const kind = String(n.kind || '').replace(/_/g, ' ');
    let inner = '';
    if (n.meta && n.meta.subcategories && n.meta.subcategories.length) {
      const sc0 = n.meta.subcategories[0];
      inner =
        '<div class="pg-tip-head" style="border-color:' +
        c.stroke +
        '">' +
        '<strong>' +
        escapeHtml(n.meta.title || n.label || '') +
        '</strong>' +
        '<span class="pg-tip-kind">' +
        escapeHtml(kind) +
        '</span></div>' +
        '<p class="pg-tip-one">' +
        escapeHtml(n.meta.subtitle || '') +
        '</p>' +
        '<p class="pg-tip-one pg-tip-muted">Example: ' +
        escapeHtml(sc0.label || '') +
        ' — ' +
        escapeHtml((sc0.detail || '').slice(0, 140)) +
        '</p>';
    } else if (n.meta && n.meta.sections && n.meta.sections.length) {
      inner =
        '<div class="pg-tip-head" style="border-color:' +
        c.stroke +
        '">' +
        '<strong>' +
        escapeHtml(n.meta.title || n.label || '') +
        '</strong>' +
        '<span class="pg-tip-kind">' +
        escapeHtml(kind) +
        '</span></div>' +
        '<div class="pg-tip-body">' +
        formatMetaSections(n.meta) +
        '</div>';
    } else {
      inner =
        '<div class="pg-tip-head" style="border-color:' +
        c.stroke +
        '">' +
        '<strong>' +
        escapeHtml(n.label || '') +
        '</strong>' +
        '<span class="pg-tip-kind">' +
        escapeHtml(kind) +
        '</span></div>' +
        (n.detail
          ? '<p class="pg-tip-one">' + escapeHtml(n.detail) + '</p>'
          : '');
    }
    return '<div class="pg-tip-inner">' + inner + '</div>';
  }

  function render(data) {
    if (!hostEl) return;
    teardownGraph(false);
    if (!data || data.error) {
      hostEl.innerHTML =
        '<p class="empty-state">' +
        escapeHtml(data && data.error ? data.error : 'No graph data') +
        '</p>';
      return;
    }
    if (!data.has_trace || !data.nodes || data.nodes.length === 0) {
      hostEl.innerHTML =
        '<p class="empty-state">' +
        escapeHtml(
          data.message ||
            'No provenance graph for this session yet. Use chat to generate a trace.'
        ) +
        '</p>';
      return;
    }
    if (selectionEl) {
      selectionEl.innerHTML =
        completenessBannerHtml(data.completeness) +
        '<div class="provenance-graph-detail-inner">' +
        '<p class="provenance-graph-detail-placeholder">Hover or click a node to inspect metadata, tool output, encodings, and reasoning.</p>' +
        '</div>';
    }

    const layout = computeLayout(data.nodes, data.edges || []);
    const pos = layout.pos;
    const width = layout.width;
    const height = layout.height;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.setAttribute('class', 'provenance-graph-svg');
    svg.style.cursor = 'grab';

    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML =
      '<marker id="pg-arrow" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">' +
      '<path d="M0,0 L9,4.5 L0,9 z" fill="rgba(100,116,139,0.4)" />' +
      '</marker>' +
      '<marker id="pg-arrow-hi" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">' +
      '<path d="M0,0 L9,4.5 L0,9 z" fill="rgba(99,102,241,0.9)" />' +
      '</marker>' +
      '<linearGradient id="pg-bg" x1="0%" y1="0%" x2="100%" y2="100%">' +
      '<stop offset="0%" style="stop-color:rgba(99,102,241,0.05)"/>' +
      '<stop offset="100%" style="stop-color:rgba(14,165,233,0.05)"/>' +
      '</linearGradient>';
    svg.appendChild(defs);

    rootG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    rootG.setAttribute('class', 'provenance-graph-root');
    rootG.setAttribute('transform', 'translate(0,0)');

    const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    bg.setAttribute('x', '0');
    bg.setAttribute('y', '0');
    bg.setAttribute('width', String(width));
    bg.setAttribute('height', String(height));
    bg.setAttribute('fill', 'url(#pg-bg)');
    bg.setAttribute('rx', '14');
    rootG.appendChild(bg);

    edgeG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    edgeG.setAttribute('class', 'provenance-edges');
    for (let i = 0; i < (data.edges || []).length; i++) {
      const e = data.edges[i];
      const a = pos[e.source];
      const b = pos[e.target];
      if (!a || !b) continue;
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      const x1 = a.x + a.w;
      const y1 = a.y + a.h / 2;
      const x2 = b.x;
      const y2 = b.y + b.h / 2;
      path.setAttribute('d', edgePath(x1, y1, x2, y2));
      path.setAttribute('fill', 'none');
      const alpha = Math.max(0.2, Math.min(0.75, Number(e.strength || 0.5)));
      path.setAttribute('stroke', 'rgba(71,85,105,' + alpha + ')');
      path.setAttribute('stroke-width', '1.5');
      path.setAttribute('marker-end', 'url(#pg-arrow)');
      path.setAttribute('class', 'provenance-edge');
      path.setAttribute('data-source', e.source);
      path.setAttribute('data-target', e.target);
      path.setAttribute('data-kind', e.kind || '');
      path.setAttribute('data-strength', String(e.strength || ''));
      edgeG.appendChild(path);
    }
    rootG.appendChild(edgeG);

    const nodeById = {};
    for (let i = 0; i < data.nodes.length; i++) {
      nodeById[data.nodes[i].id] = data.nodes[i];
    }

    function selectNode(n) {
      if (!selectionEl || !n) return;
      selectionEl.innerHTML = inspectorHtml(n);
      bindInspectorSubcatSelect(selectionEl);
      rootG.querySelectorAll('.pg-node-card').forEach(function (el) {
        el.classList.remove('pg-node-card--active');
      });
      const active = rootG.querySelector(
        '.pg-node-card[data-node-id="' + n.id + '"]'
      );
      if (active) active.classList.add('pg-node-card--active');
      highlightEdges(n.id);
    }

    for (let ni = 0; ni < data.nodes.length; ni++) {
      const n = data.nodes[ni];
      const p = pos[n.id];
      if (!p) continue;
      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      g.setAttribute('transform', 'translate(' + p.x + ',' + p.y + ')');
      g.setAttribute('data-pg-node', n.id);

      const fo = document.createElementNS('http://www.w3.org/2000/svg', 'foreignObject');
      fo.setAttribute('width', String(p.w));
      fo.setAttribute('height', String(p.h));
      fo.setAttribute('overflow', 'hidden');
      fo.setAttribute('data-node-id', n.id);

      const c = COLORS[n.kind] || COLORS.evidence;
      let sub =
        n.subtitle ||
        (n.meta && n.meta.subtitle) ||
        (n.detail ? String(n.detail).slice(0, 120) : '');
      const title = n.label || (n.meta && n.meta.title) || n.id;
      const kindLabel = String(n.kind || '').replace(/_/g, ' ');

      let subcatBlock = '';
      if (n.meta && n.meta.subcategories && n.meta.subcategories.length) {
        const first = n.meta.subcategories[0];
        const previewText = first.detail || first.label || '';
        let opts = '';
        for (let si = 0; si < n.meta.subcategories.length; si++) {
          opts +=
            '<option value="' +
            si +
            '">' +
            escapeHtml(n.meta.subcategories[si].label || 'Item ' + (si + 1)) +
            '</option>';
        }
        subcatBlock =
          '<label class="pg-node-subcat-label">Subcategory</label>' +
          '<select class="pg-node-subcat-select" aria-label="Subcategory">' +
          opts +
          '</select>' +
          '<div class="pg-node-sub pg-subcat-preview">' +
          escapeHtml(previewText.slice(0, 200)) +
          '</div>';
        sub = '';
      }

      const inner = document.createElement('div');
      inner.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
      inner.className = 'pg-node-card';
      inner.setAttribute('data-node-id', n.id);
      inner.innerHTML =
        '<div class="pg-node-card-inner" style="border-color:' +
        c.stroke +
        ';background:' +
        c.fill +
        '">' +
        '<span class="pg-node-kind" style="color:' +
        c.text +
        '">' +
        escapeHtml(kindLabel) +
        '</span>' +
        '<div class="pg-node-title">' +
        escapeHtml(title) +
        '</div>' +
        subcatBlock +
        (sub
          ? '<div class="pg-node-sub">' + escapeHtml(sub) + '</div>'
          : '') +
        '</div>';

      const nodeSel = inner.querySelector('.pg-node-subcat-select');
      const nodePrev = inner.querySelector('.pg-subcat-preview');
      if (nodeSel && nodePrev && n.meta && n.meta.subcategories) {
        nodeSel.addEventListener('click', function (ev) {
          ev.stopPropagation();
        });
        nodeSel.addEventListener('mousedown', function (ev) {
          ev.stopPropagation();
        });
        nodeSel.addEventListener('change', function (ev) {
          ev.stopPropagation();
          const ix = parseInt(nodeSel.value, 10);
          const sc = n.meta.subcategories[ix];
          if (sc) {
            nodePrev.textContent = (sc.detail || sc.label || '').slice(0, 500);
          }
          // Re-measure this column after preview text changes so bottoms don't clip.
          requestAnimationFrame(function () {
            requestAnimationFrame(function () {
              const dims = reflowLayoutByMeasurement(data.nodes, pos);
              if (dims && bg && svgEl) {
                bg.setAttribute('width', String(dims.width));
                bg.setAttribute('height', String(dims.height));
                svgEl.setAttribute('viewBox', '0 0 ' + dims.width + ' ' + dims.height);
                lastLayoutInfo = dims;
                vb.layoutW = dims.width;
                vb.layoutH = dims.height;
                vb.w = dims.width;
                vb.h = dims.height;
                applyViewBox();
              }
              adjustEdgeAnchorsToNodes(pos, data.edges || []);
            });
          });
        });
      }

      inner.addEventListener('mousedown', function (ev) {
        ev.stopPropagation();
      });

      inner.onmouseenter = function (ev) {
        if (panState.dragging) return;
        showTooltip(tooltipHtml(n), ev.clientX, ev.clientY);
        highlightEdges(n.id);
      };
      inner.onmousemove = function (ev) {
        if (panState.dragging) return;
        showTooltip(tooltipHtml(n), ev.clientX, ev.clientY);
      };
      inner.onmouseleave = function () {
        hideTooltip();
        clearEdgeHighlight();
      };
      inner.onclick = function (ev) {
        ev.stopPropagation();
        selectNode(n);
      };

      fo.appendChild(inner);
      g.appendChild(fo);
      rootG.appendChild(g);
    }

    svg.appendChild(rootG);
    hostEl.appendChild(svg);

    const zoomBar = document.createElement('div');
    zoomBar.className = 'pg-zoom-controls';
    zoomBar.setAttribute('role', 'toolbar');
    zoomBar.setAttribute('aria-label', 'Graph zoom');

    const btnIn = document.createElement('button');
    btnIn.type = 'button';
    btnIn.className = 'pg-zoom-btn';
    btnIn.setAttribute('title', 'Zoom in');
    btnIn.setAttribute('aria-label', 'Zoom in');
    btnIn.appendChild(document.createTextNode('+'));
    btnIn.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      zoomViewBox(svg, 1 / PG_ZOOM_STEP, null, null);
    });

    const btnOut = document.createElement('button');
    btnOut.type = 'button';
    btnOut.className = 'pg-zoom-btn';
    btnOut.setAttribute('title', 'Zoom out');
    btnOut.setAttribute('aria-label', 'Zoom out');
    btnOut.appendChild(document.createTextNode('\u2212'));
    btnOut.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      zoomViewBox(svg, PG_ZOOM_STEP, null, null);
    });

    zoomBar.appendChild(btnIn);
    zoomBar.appendChild(btnOut);
    hostEl.appendChild(zoomBar);

    hostEl.classList.add('provenance-graph-host--ready');
    svgEl = svg;

    svg.addEventListener(
      'mouseleave',
      function () {
        hideTooltip();
        clearEdgeHighlight();
      },
      true
    );

    const layoutInfo = { width: width, height: height };
    lastLayoutInfo = layoutInfo;
    vb.layoutW = width;
    vb.layoutH = height;
    vb.x = 0;
    vb.y = 0;
    vb.w = width;
    vb.h = height;
    panState.dragging = false;
    applyViewBox();

    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        function applyDims(dims) {
          if (!dims || !bg) return;
          bg.setAttribute('width', String(dims.width));
          bg.setAttribute('height', String(dims.height));
          svg.setAttribute('viewBox', '0 0 ' + dims.width + ' ' + dims.height);
          lastLayoutInfo = dims;
          vb.layoutW = dims.width;
          vb.layoutH = dims.height;
          vb.x = 0;
          vb.y = 0;
          vb.w = dims.width;
          vb.h = dims.height;
          applyViewBox();
        }
        let dims = reflowLayoutByMeasurement(data.nodes, pos);
        applyDims(dims);
        requestAnimationFrame(function () {
          dims = reflowLayoutByMeasurement(data.nodes, pos);
          applyDims(dims);
          adjustEdgeAnchorsToNodes(pos, data.edges || []);
          fitViewBox(lastLayoutInfo || layoutInfo);
          disposePanZoom = bindPanZoom(svg);
        });
      });
    });

    if (data.legend && data.legend.length && legendEl) {
      legendEl.innerHTML =
        '<span class="provenance-legend-title">Legend</span>' +
        data.legend
          .map(function (L) {
            const cc = COLORS[L.kind] || COLORS.evidence;
            return (
              '<span class="provenance-legend-item"><i style="background:' +
              cc.stroke +
              '"></i>' +
              escapeHtml(L.label) +
              '</span>'
            );
          })
          .join('');
    }

    const q = nodeById.q;
    if (q) selectNode(q);
  }

  global.ProvenanceGraph = {
    mount(hostId, selectionId, legendId) {
      hostEl = document.getElementById(hostId);
      selectionEl = document.getElementById(selectionId);
      legendEl = legendId ? document.getElementById(legendId) : null;
    },
    render(data) {
      render(data);
    },
    clear() {
      teardownGraph(true);
    },
    resetView() {
      if (svgEl && rootG) {
        fitViewBox(lastLayoutInfo || { width: vb.layoutW, height: vb.layoutH });
      }
    },
    zoomIn() {
      if (svgEl) zoomViewBox(svgEl, 1 / PG_ZOOM_STEP, null, null);
    },
    zoomOut() {
      if (svgEl) zoomViewBox(svgEl, PG_ZOOM_STEP, null, null);
    },
  };
})(window);
