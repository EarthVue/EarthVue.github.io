// Workspaces JavaScript

let currentWorkspaceId = null;

// Load workspaces
async function loadWorkspaces() {
  try {
    const response = await fetch('/api/workspaces');
    const data = await response.json();
    const workspaces = data.workspaces || [];
    
    const grid = document.getElementById('workspace-grid');
    grid.innerHTML = '';
    
    if (workspaces.length === 0) {
      grid.innerHTML = '<p style="text-align: center; color: var(--muted); padding: 40px;">No workspaces yet. Create one to get started!</p>';
      return;
    }
    
    workspaces.forEach(ws => {
      const card = document.createElement('div');
      card.className = 'workspace-card';
      
      const memberEmails = ws.member_emails || [];
      const isOwner = ws.owner_id === getCurrentUserId();
      
      card.innerHTML = `
        ${isOwner ? `
          <div class="workspace-actions">
            <button class="workspace-action-btn delete" onclick="deleteWorkspace('${ws.id}', '${escapeHtml(ws.name)}')" title="Delete workspace"><span class="app-icon">🗑</span></button>
          </div>
        ` : ''}
        <div class="owner-badge">${isOwner ? '<span class="app-icon">👑</span> Owner' : '<span class="app-icon">👥</span> Member'}</div>
        <h3>${escapeHtml(ws.name)}</h3>
        <p>${escapeHtml(ws.description || 'No description')}</p>
        <div class="workspace-members">
          <div class="member-list">
            ${memberEmails.map(email => `
              <span class="member-badge">
                ${escapeHtml(email)}
                ${isOwner ? `<button class="remove-btn" onclick="removeMember('${ws.id}', '${escapeHtml(email)}')">×</button>` : ''}
              </span>
            `).join('')}
          </div>
          ${isOwner ? `
            <div class="add-member-form">
              <input type="email" id="add-email-${ws.id}" placeholder="Add member by email">
              <button class="primary-btn" onclick="addMemberToWorkspace('${ws.id}')">Add</button>
            </div>
          ` : ''}
        </div>
        <div class="workspace-sessions" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--stroke);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <h4 style="margin: 0; font-size: 0.9rem; color: var(--muted);">Sessions in this workspace:</h4>
            <button class="muted-btn" style="padding: 4px 8px; font-size: 0.8rem;" onclick="showProvenanceTree('${ws.id}', '${escapeHtml(ws.name).replace(/'/g, "\\'")}')"><span class="app-icon">🌿</span> Visual Tree</button>
          </div>
          <div id="sessions-${ws.id}" class="session-list" style="font-size: 0.85rem; color: var(--muted);">
            Loading...
          </div>
        </div>
      `;
      grid.appendChild(card);
      
      // Load sessions for this workspace
      loadWorkspaceSessions(ws.id);
    });
  } catch (error) {
    console.error('Failed to load workspaces:', error);
  }
}

// Get current user ID (you may need to pass this from backend or get from session)
function getCurrentUserId() {
  // This is a placeholder - you might need to get this from a global variable or API
  return window.currentUserId || null;
}

// Add member to workspace
async function addMemberToWorkspace(workspaceId) {
  const input = document.getElementById(`add-email-${workspaceId}`);
  const email = input.value.trim().toLowerCase();
  
  if (!email) {
    alert('Please enter an email address');
    return;
  }
  
  try {
    const response = await fetch(`/api/workspaces/${workspaceId}/members`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: email })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      input.value = '';
      loadWorkspaces(); // Reload to show new member
      alert(data.message || 'Member added successfully');
    } else {
      alert(data.error || 'Failed to add member');
    }
  } catch (error) {
    console.error('Failed to add member:', error);
    alert('Failed to add member');
  }
}

// Remove member from workspace
async function removeMember(workspaceId, email) {
  if (!confirm(`Remove ${email} from this workspace?`)) {
    return;
  }
  
  try {
    const response = await fetch(`/api/workspaces/${workspaceId}/members`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: email })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      loadWorkspaces(); // Reload to update member list
      alert(data.message || 'Member removed successfully');
    } else {
      alert(data.error || 'Failed to remove member');
    }
  } catch (error) {
    console.error('Failed to remove member:', error);
    alert('Failed to remove member');
  }
}

// Delete workspace
async function deleteWorkspace(workspaceId, workspaceName) {
  if (!confirm(`Are you sure you want to delete "${workspaceName}"? This action cannot be undone.`)) {
    return;
  }
  
  try {
    const response = await fetch(`/api/workspaces/${workspaceId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      loadWorkspaces(); // Reload to update workspace list
      alert(data.message || 'Workspace deleted successfully');
    } else {
      alert(data.error || 'Failed to delete workspace');
    }
  } catch (error) {
    console.error('Failed to delete workspace:', error);
    alert('Failed to delete workspace');
  }
}

// Create workspace
async function createWorkspace() {
  const name = document.getElementById('workspace-name').value.trim();
  const description = document.getElementById('workspace-description').value.trim();
  
  if (!name) {
    alert('Workspace name is required');
    return;
  }
  
  try {
    const response = await fetch('/api/workspaces', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: name,
        description: description
      })
    });
    
    if (response.ok) {
      closeModal('new-workspace-modal');
      document.getElementById('workspace-name').value = '';
      document.getElementById('workspace-description').value = '';
      loadWorkspaces();
    } else {
      const error = await response.json();
      alert(error.error || 'Failed to create workspace');
    }
  } catch (error) {
    console.error('Failed to create workspace:', error);
    alert('Failed to create workspace');
  }
}

// Modal functions
function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('show');
}

document.getElementById('new-workspace-btn').addEventListener('click', () => {
  document.getElementById('new-workspace-modal').classList.add('show');
});

// Close modal when clicking outside
document.querySelectorAll('.modal').forEach(modal => {
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('show');
    }
  });
});

// Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Load sessions for a workspace
async function loadWorkspaceSessions(workspaceId) {
  try {
    const response = await fetch('/sessions');
    const sessions = await response.json();
    
    const workspaceSessions = sessions.filter(s => s.workspace_id === workspaceId);
    const container = document.getElementById(`sessions-${workspaceId}`);
    
    if (!container) return;
    
    if (workspaceSessions.length === 0) {
      container.innerHTML = '<span style="color: var(--muted);">No sessions assigned yet</span>';
      return;
    }
    
    container.innerHTML = workspaceSessions.map(s => `
      <div style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
        <a href="/chat?session=${s.session_uuid}" style="color: var(--accent); text-decoration: none;">
          ${escapeHtml(s.title || 'Untitled')}
        </a>
        ${s.is_shared ? '<span style="font-size: 0.75rem; opacity: 0.7;">(Shared)</span>' : ''}
      </div>
    `).join('');
  } catch (error) {
    console.error('Failed to load workspace sessions:', error);
    const container = document.getElementById(`sessions-${workspaceId}`);
    if (container) {
      container.innerHTML = '<span style="color: var(--muted);">Failed to load sessions</span>';
    }
  }
}

// Show Provenance Tree (Git-like branching of sessions)
async function showProvenanceTree(workspaceId, workspaceName) {
  try {
    const response = await fetch('/sessions');
    const sessions = await response.json();
    
    const workspaceSessions = sessions.filter(s => s.workspace_id === workspaceId);
    
    if (workspaceSessions.length === 0) {
      alert("No sessions in this workspace to visualize.");
      return;
    }
    
    // Sort sessions by creation/modification roughly
    workspaceSessions.sort((a,b) => new Date(a.last_modified) - new Date(b.last_modified));
    
    let mermaidCode = 'gitGraph\n';
    let safeName = workspaceName.replace(/"/g, '').substring(0, 15);
    mermaidCode += `  commit id: "Init" msg: "${safeName}"\n`;
    
    // Max 10 sessions to prevent too much complexity
    const displaySessions = workspaceSessions.slice(0, 10);
    
    displaySessions.forEach((s, idx) => {
      let branchName = `sess_${idx}`;
      let title = (s.title || "Untitled").replace(/"/g, "'").replace(/:/g, "-").substring(0, 20);
      mermaidCode += `  branch ${branchName}\n`;
      mermaidCode += `  checkout ${branchName}\n`;
      mermaidCode += `  commit id: "s${idx}" msg: "${title}"\n`;
      
      if (s.is_shared) {
         mermaidCode += `  commit id: "s${idx}_shared" msg: "Shared"\n`;
      }
      
      mermaidCode += `  checkout main\n`;
      // sometimes merge back to show collaboration
      if (idx > 0 && idx % 2 === 0) {
        mermaidCode += `  merge ${branchName}\n`;
      }
    });

    const graphContainer = document.getElementById('provenance-graph');
    graphContainer.removeAttribute('data-processed');
    graphContainer.innerHTML = mermaidCode;
    
    document.getElementById('provenance-modal').classList.add('show');
    
    // initialize mermaid if needed
    if (window.mermaid) {
      mermaid.initialize({ startOnLoad: false, theme: 'default' });
      mermaid.init(undefined, document.getElementById('provenance-graph'));
    }
    
  } catch (error) {
    console.error("Failed to generate provenance tree", error);
    alert("Failed to load provenance tree");
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadWorkspaces();
});
